# vault-operators-lab

## Table of Contents

<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Workflow](#workflow)
<!-- AUTO-GENERATED-CONTENT:END -->

## Overview

This repo contains sample snippets for starting up `Vault` server and
experimenting with various secret engines.

## Prerequisites

- Either `docker` or `vault` binary in Shell's `PATH`.

## Workflow

- Start up `Vault` server locally.Refer to [`Server Setup`](server-setup/README.md) for instructions.
- Form a list of all secret engines that you need.
- Define Policies based on secret engines that you are planning on using.
- Enable Auth Methods. Look into the corresponding auth method `README` file for more information.
- Define Auth method roles; map those roles to Vault policies.
- Enable and configure target secret engines
- Define roles for secret engines as required

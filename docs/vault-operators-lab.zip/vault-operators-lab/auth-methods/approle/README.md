# UserPass auth method
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Enable the Auth method](#enable-the-auth-method)
- [Create a new role](#create-a-new-role)
- [Get Role ID and Secret ID to hand it to user ( Application / Machine )](#get-role-id-and-secret-id-to-hand-it-to-user--application--machine-)
- [Authenticate](#authenticate)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

`approle` auth method enables Vault users to authenticate with two values :
`Role ID` (Not Secret) and `Secret ID` ( semi-ephermal Secret Value ). It is
primarily used with machine authentication as `secret ID` in auth method roles
is usually configured to expire after certain amount of time or uses. 

An example usage is in CI/CD pipeline:

- `Role ID` is configured in job variables
- `Secret ID` is configured to expire after 1 use.
- users set `Secret ID` in pipeline's environment variables before each run

## Enable the Auth method

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-enable.sh -->
```bash
# bash scripts/bash/cli/00-enable.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

AUTH_MOUNT_PATH="approle"

vault auth enable \
  -path="${AUTH_MOUNT_PATH}" \
  approle
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/00-enable.sh&src=scripts/bash/api/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/00-enable.sh -->
```bash
# bash scripts/bash/api/00-enable.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="approle"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "approle"}' \
  "${VAULT_ADDR}/v1/sys/auth/${AUTH_MOUNT_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\00-enable.ps1&src=scripts/powershell/cli/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/00-enable.ps1 -->
```powershell
# scripts\powershell\cli\00-enable.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$AUTH_MOUNT_PATH="approle" ;

vault auth enable `
  -path="$AUTH_MOUNT_PATH" `
  approle ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\00-enable.ps1&src=scripts/powershell/api/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/00-enable.ps1 -->
```powershell
# scripts\powershell\api\00-enable.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";

$REQUEST_BODY = @{
 "type" = "approle";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/sys/auth/$AUTH_MOUNT_PATH"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

## Create a new role

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-create-role.sh&src=scripts/bash/cli/01-create-role.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-create-role.sh -->
```bash
# bash scripts/bash/cli/01-create-role.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

AUTH_MOUNT_PATH="approle"
ROLE_NAME="approle-cli-role"
POLICIES="default"

vault write "/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}" \
  token_policies="${POLICIES}" \
  secret_id_ttl=10m \
  token_num_uses=10 \
  token_ttl=20m \
  token_max_ttl=30m \
  secret_id_num_uses=40
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/01-create-role.sh&src=scripts/bash/api/01-create-role.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/01-create-role.sh -->
```bash
# bash scripts/bash/api/01-create-role.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="approle"
ROLE_NAME="approle-api-role"
POLICIES="default"
PAYLOAD="$(jq -n \
  --arg password "${PASSWORD}" \
  --argjson policies "[${POLICIES}]" \
  '{
  "token_policies":$policies,
  "secret_id_ttl":"10m",
  "token_num_uses":"10",
  "token_ttl":"20m",
  "token_max_ttl":"30m",
  "secret_id_num_uses":"40"
}')"

curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\01-create-role.ps1&src=scripts/powershell/cli/01-create-role.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/01-create-role.ps1 -->
```powershell
# scripts\powershell\cli\01-create-role.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$AUTH_MOUNT_PATH="approle"
$ROLE_NAME="approle-cli-role";
$POLICIES="default";

vault write "/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME" `
  token_policies="$POLICIES" `
  secret_id_ttl="10m" `
  token_num_uses="10" `
  token_ttl="20m" `
  token_max_ttl="30m" `
  secret_id_num_uses="40";
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\01-create-role.ps1&src=scripts/powershell/api/01-create-role.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/01-create-role.ps1 -->
```powershell
# scripts\powershell\api\01-create-role.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";
$ROLE_NAME="approle-api-role";
$POLICIES=New-Object Collections.Generic.List[String];
$POLICIES.add("default");
$REQUEST_BODY = @{
  "token_policies"=$POLICIES;
  "secret_id_ttl"="10m";
  "token_num_uses"="10";
  "token_ttl"="20m";
  "token_max_ttl"="30m";
  "secret_id_num_uses"="40";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Get Role ID and Secret ID to hand it to user ( Application / Machine )

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-get-auth-parameters.sh&src=scripts/bash/cli/02-get-auth-parameters.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-get-auth-parameters.sh -->
```bash
# bash scripts/bash/cli/02-get-auth-parameters.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

ROLE_NAME="approle-cli-role"
AUTH_MOUNT_PATH="approle"

export ROLE_ID="$(vault read \
  -field=role_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id)"
echo "Role ID:"
echo "${ROLE_ID}"
export SECRET_ID="$(vault write -f \
  -field=secret_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id)"
echo "Secret ID:"
echo "${SECRET_ID}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/02-get-auth-parameters.sh&src=scripts/bash/api/02-get-auth-parameters.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/02-get-auth-parameters.sh -->
```bash
# bash scripts/bash/api/02-get-auth-parameters.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

ROLE_NAME="approle-api-role"
AUTH_MOUNT_PATH="approle"
export ROLE_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request GET \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id" | jq -r '.data.role_id')"
echo "Role ID:"
echo "${ROLE_ID}"
export SECRET_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id" | jq -r '.data.secret_id')"
echo "Secret ID:"
echo "${SECRET_ID}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\02-get-auth-parameters.ps1&src=scripts/powershell/cli/02-get-auth-parameters.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/02-get-auth-parameters.ps1 -->
```powershell
# scripts\powershell\cli\02-get-auth-parameters.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$ROLE_NAME="approle-cli-role";
$AUTH_MOUNT_PATH="approle";

$ROLE_ID="$(vault read -field=role_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id)";
Write-Host "Role ID:";
Write-Host "$ROLE_ID";
$SECRET_ID="$(vault write -f -field=secret_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id)";
Write-Host "Secret ID:";
Write-Host "$SECRET_ID";
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\02-get-auth-parameters.ps1&src=scripts/powershell/api/02-get-auth-parameters.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/02-get-auth-parameters.ps1 -->
```powershell
# scripts\powershell\api\02-get-auth-parameters.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";
$ROLE_NAME="approle-api-role";

$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method GET `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $ROLE_ID=$jsonObj.data.role_id
  Write-Host "Role ID:";
  Write-Host "$ROLE_ID";
}


$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $SECRET_ID=$jsonObj.data.secret_id
  Write-Host "Secret ID:";
  Write-Host "$SECRET_ID";
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

## Authenticate

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-authenticate.sh&src=scripts/bash/cli/03-authenticate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-authenticate.sh -->
```bash
# bash scripts/bash/cli/03-authenticate.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

ROLE_NAME="approle-cli-role"
AUTH_MOUNT_PATH="approle"

ROLE_ID="$(vault read \
  -field=role_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id)"
SECRET_ID="$(vault write -f \
  -field=secret_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id)"

vault write "auth/${AUTH_MOUNT_PATH}/login" \
  role_id="${ROLE_ID}" \
  secret_id="${SECRET_ID}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/03-authenticate.sh&src=scripts/bash/api/03-authenticate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/03-authenticate.sh -->
```bash
# bash scripts/bash/api/03-authenticate.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

ROLE_NAME="approle-api-role"
AUTH_MOUNT_PATH="approle"

ROLE_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request GET \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id" | jq -r '.data.role_id')"
SECRET_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id" | jq -r '.data.secret_id')"

curl \
  --silent \
  --request POST \
  --data "{\
  \"role_id\": \"${ROLE_ID}\",\
  \"secret_id\":\"${SECRET_ID}\"\
}" "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/login" |
  jq -r '.auth.client_token'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\03-authenticate.ps1&src=scripts/powershell/cli/03-authenticate.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/03-authenticate.ps1 -->
```powershell
# scripts\powershell\cli\03-authenticate.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$ROLE_NAME="approle-cli-role";
$AUTH_MOUNT_PATH="approle";

$ROLE_ID="$(vault read -field=role_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id)";
$SECRET_ID="$(vault write -f -field=secret_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id)";

vault write "auth/$AUTH_MOUNT_PATH/login" `
  role_id="$ROLE_ID" `
  secret_id="$SECRET_ID" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\03-authenticate.ps1&src=scripts/powershell/api/03-authenticate.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/03-authenticate.ps1 -->
```powershell
# scripts\powershell\api\03-authenticate.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";
$ROLE_NAME="approle-api-role";

$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method GET `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $ROLE_ID=$jsonObj.data.role_id
}


$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $SECRET_ID=$jsonObj.data.secret_id
}

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/login"
$REQUEST_BODY = @{
  "role_id"="$ROLE_ID";
  "secret_id"="$SECRET_ID";
}
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $jsonObj.auth.client_token
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="approle"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "approle"}' \
  "${VAULT_ADDR}/v1/sys/auth/${AUTH_MOUNT_PATH}"

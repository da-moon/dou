VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="approle"
ROLE_NAME="approle-api-role"
POLICIES="default"
PAYLOAD="$(jq -n \
  --arg password "${PASSWORD}" \
  --argjson policies "[${POLICIES}]" \
  '{
  "token_policies":$policies,
  "secret_id_ttl":"10m",
  "token_num_uses":"10",
  "token_ttl":"20m",
  "token_max_ttl":"30m",
  "secret_id_num_uses":"40"
}')"

curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}"

VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

ROLE_NAME="approle-api-role"
AUTH_MOUNT_PATH="approle"
export ROLE_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request GET \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id" | jq -r '.data.role_id')"
echo "Role ID:"
echo "${ROLE_ID}"
export SECRET_ID="$(curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id" | jq -r '.data.secret_id')"
echo "Secret ID:"
echo "${SECRET_ID}"

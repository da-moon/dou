export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

ROLE_NAME="approle-cli-role"
AUTH_MOUNT_PATH="approle"

export ROLE_ID="$(vault read \
  -field=role_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id)"
echo "Role ID:"
echo "${ROLE_ID}"
export SECRET_ID="$(vault write -f \
  -field=secret_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id)"
echo "Secret ID:"
echo "${SECRET_ID}"

export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

ROLE_NAME="approle-cli-role"
AUTH_MOUNT_PATH="approle"

ROLE_ID="$(vault read \
  -field=role_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id)"
SECRET_ID="$(vault write -f \
  -field=secret_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id)"

vault write "auth/${AUTH_MOUNT_PATH}/login" \
  role_id="${ROLE_ID}" \
  secret_id="${SECRET_ID}"

$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";

$REQUEST_BODY = @{
 "type" = "approle";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/sys/auth/$AUTH_MOUNT_PATH"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}

$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="approle";
$ROLE_NAME="approle-api-role";

$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method GET `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $ROLE_ID=$jsonObj.data.role_id
}


$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $SECRET_ID=$jsonObj.data.secret_id
}

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/login"
$REQUEST_BODY = @{
  "role_id"="$ROLE_ID";
  "secret_id"="$SECRET_ID";
}
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $jsonObj.auth.client_token
}

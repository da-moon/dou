$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$AUTH_MOUNT_PATH="approle" ;

vault auth enable `
  -path="$AUTH_MOUNT_PATH" `
  approle ;


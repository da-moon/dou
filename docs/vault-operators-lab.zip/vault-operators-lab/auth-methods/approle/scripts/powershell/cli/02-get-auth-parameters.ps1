$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$ROLE_NAME="approle-cli-role";
$AUTH_MOUNT_PATH="approle";

$ROLE_ID="$(vault read -field=role_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/role-id)";
Write-Host "Role ID:";
Write-Host "$ROLE_ID";
$SECRET_ID="$(vault write -f -field=secret_id auth/$AUTH_MOUNT_PATH/role/$ROLE_NAME/secret-id)";
Write-Host "Secret ID:";
Write-Host "$SECRET_ID";


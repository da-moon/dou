AUTH_MOUNT_PATH="azure"

export VAULT_TOKEN="root"
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  echo >&2 "[ ERROR ] 'VAULT_ADDR' environment variable is required"
  exit 1
fi

vault auth enable \
  -path="${AUTH_MOUNT_PATH}" \
  azure

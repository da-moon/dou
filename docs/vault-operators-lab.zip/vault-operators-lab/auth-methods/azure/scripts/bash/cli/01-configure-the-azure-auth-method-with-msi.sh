AUTH_MOUNT_PATH="azure"
export VAULT_TOKEN="root"
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  echo >&2 "[ ERROR ] 'VAULT_ADDR' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_TENANT_ID+x}" ] || [ -z "${AZURE_TENANT_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_TENANT_ID' environment variable is required"
  exit 1
fi
vault write "auth/${AUTH_MOUNT_PATH}/config" \
  tenant_id="${AZURE_TENANT_ID}" \
  resource="https://management.azure.com/"

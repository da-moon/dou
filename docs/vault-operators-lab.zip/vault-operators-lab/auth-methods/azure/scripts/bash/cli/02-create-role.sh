AUTH_MOUNT_PATH="azure"
ROLE_NAME="example"
POLICIES="default,kv-azure-policy"

export VAULT_TOKEN="root"
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  echo >&2 "[ ERROR ] 'VAULT_ADDR' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
vault write \
  "auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}" \
  policies="${POLICIES}" \
  bound_subscription_ids="${AZURE_SUBSCRIPTION_ID}" \
  bound_resource_groups="${AZURE_RESOURCE_GROUP}"

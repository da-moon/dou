AUTH_MOUNT_PATH="azure"
ROLE_NAME="example"
VM_NAME="hashicorp-vault-dev-azure-auth"

export VAULT_TOKEN="root"
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  echo >&2 "[ ERROR ] 'VAULT_ADDR' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
az vm run-command invoke \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}" \
  --command-id "RunShellScript" \
  --scripts '
  export VAULT_TOKEN="root";
  export VAULT_ADDR="http://127.0.0.1:8200";
  vault write auth/'${AUTH_MOUNT_PATH}'/login role='"${ROLE_NAME}"' \
     jwt="$(curl -s "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F" -H Metadata:true | jq -r ".access_token")" \
     subscription_id=$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance?api-version=2017-08-01" | jq -r ".compute | .subscriptionId")  \
     resource_group_name=$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance?api-version=2017-08-01" | jq -r ".compute | .resourceGroupName") \
     vm_name=$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance?api-version=2017-08-01" | jq -r ".compute | .name")
'

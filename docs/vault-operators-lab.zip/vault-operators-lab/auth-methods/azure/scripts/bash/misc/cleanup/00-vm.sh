# Remove VM
VM_NAME="hashicorp-vault-dev-azure-auth"
VM="$(az vm list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${VM_NAME}')].name" --output tsv)"
if [[ -n "${VM}" ]]; then
  az vm delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM}" --yes
fi

# clean orphan disks
VM_NAME="hashicorp-vault-dev-azure-auth"
DISK="$(az vm show --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM_NAME}" --query 'storageProfile.osDisk.name' --output tsv 2>/dev/null)"
if [[ -n "${DISK}" ]]; then
  az disk delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${DISK}" --yes
fi
ORPHAN_DISKS=($(az resource list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?type=='Microsoft.Compute/disks'] | [?managedBy==\`null\`].[id]" --output tsv))
for id in ${ORPHAN_DISKS[@]}; do
  az disk delete --ids "${id}" --yes
done
ORPHAN_DISKS=($(az resource list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?type=='Microsoft.Compute/disks'] | [?contains(name,'${VM_NAME}')].[id]" --output tsv))
for id in ${ORPHAN_DISKS[@]}; do
  az disk delete --ids "${id}" --yes
done

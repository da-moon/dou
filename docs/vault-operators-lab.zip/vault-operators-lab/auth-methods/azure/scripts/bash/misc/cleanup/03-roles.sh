# delete role assignments and roles
ROLE_NAME="hashicorp-vault-auth"
ROLE_ASSIGNMENTS=($(az role assignment list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?roleDefinitionName=='${ROLE_NAME}'].id" --output tsv))

for ROLE_ASSIGNMENT in "${ROLE_ASSIGNMENTS[@]}"; do
  az role assignment delete --id "${ROLE_ASSIGNMENT}"
done
ROLE="$(az role definition list --resource-group "${AZURE_RESOURCE_GROUP}" --name "${ROLE_NAME}" --query '[].name' --output tsv)"

if [[ -n "${ROLE}" ]]; then
  az role definition delete --scope "/subscriptions/${AZURE_SUBSCRIPTION_ID}" --name "${ROLE}"
fi

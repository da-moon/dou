# delete Azure AD app
APP_NAME="hashicorp-vault-auth"
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
if [[ -n "${APP_ID}" ]]; then
  az ad app delete --id "${APP_ID}"
fi

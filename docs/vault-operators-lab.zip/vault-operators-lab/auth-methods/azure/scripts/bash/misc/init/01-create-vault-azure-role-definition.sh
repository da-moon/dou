ROLE_NAME="hashicorp-vault-auth"

if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
ROLE_EXISTS="$(az role definition list --resource-group "${AZURE_RESOURCE_GROUP}" --name "${ROLE_NAME}" 1>/dev/null)"
if [[ ${#ROLE_EXISTS} -le 2 ]]; then
  az role definition create --role-definition '{
      "Name": "'${ROLE_NAME}'",
      "Description": "HashiCorp Vault Azure auth method role",
      "Actions": [
            "Microsoft.Compute/virtualMachines/read",
            "Microsoft.Compute/virtualMachineScaleSets/*/read"
      ],
      "DataActions": [],
      "NotDataActions": [],
      "AssignableScopes": [ "/subscriptions/'${AZURE_SUBSCRIPTION_ID}'" ]
  }' | jq -r '.'
fi

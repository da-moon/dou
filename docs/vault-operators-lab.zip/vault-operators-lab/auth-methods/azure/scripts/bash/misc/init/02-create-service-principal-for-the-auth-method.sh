ROLE_NAME="hashicorp-vault-auth"
APP_NAME="hashicorp-vault-auth"

if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
SERVICE_PRINCIPAL="$(az ad sp create-for-rbac \
  --name "${APP_NAME}" \
  --role "${ROLE_NAME}" \
  --scopes "/subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}")"

echo "${SERVICE_PRINCIPAL}" |
  jq \
    --arg subscription_id "${AZURE_SUBSCRIPTION_ID}" \
    '{
    "client_id": .appId, 
    "client_secret": .password, 
    "tenant_id": .tenant, 
    "subscription_id": $subscription_id
  }' | tee "service-principal.json" | jq -r '.'
CLIENT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".appId")
CLIENT_SECRET=$(echo "$SERVICE_PRINCIPAL" | jq -r ".password")
TENANT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".tenant")
echo >&2 "[ NOTE ] Set The following Azure Auth method environment variables in your shell:"
echo >&2 "export TENANT_ID="${TENANT_ID}""
echo >&2 "export CLIENT_ID="${CLIENT_ID}""
echo >&2 "export CLIENT_SECRET="${CLIENT_SECRET}""

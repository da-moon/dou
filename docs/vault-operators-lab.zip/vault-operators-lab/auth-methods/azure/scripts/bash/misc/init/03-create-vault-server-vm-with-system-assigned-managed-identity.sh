VM_NAME="hashicorp-vault-dev-azure-auth"
LOCATION="canadaeast"
# FIXME: it may not be needed
ROLE_NAME="hashicorp-vault-auth"
ADMIN_USERNAME="azureuser"
ADMIN_PASSWORD="$(head '/dev/urandom' | tr -dc 'A-Za-z0-9' | head -c 15)"
IMAGE_NAME="UbuntuLTS"
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
jq -n \
  --arg admin_username "${ADMIN_USERNAME}" \
  --arg admin_password "${ADMIN_PASSWORD}" \
  '{
    "admin_username": $admin_username, 
    "admin_password": $admin_password 
  }' | tee vm.json | jq -r '.'
IP_ADDR="$(az network public-ip create \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}-public-ip" \
  --tags "id=vault-training" \
  --version "IPv4" \
  --location "${LOCATION}" \
  --sku "Standard" \
  --query 'publicIp.ipAddress' \
  --output tsv 2>/dev/null)"
az vm create \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --scope "/subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}" \
  --location "${LOCATION}" \
  --name "${VM_NAME}" \
  --tags "id=vault-training" \
  --image "${IMAGE_NAME}" \
  --size "Standard_B2s" \
  --public-ip-address "${VM_NAME}-public-ip" \
  --admin-username "${ADMIN_USERNAME}" \
  --admin-password "${ADMIN_PASSWORD}" \
  --role "Reader" \
  --assign-identity \
  --ssh-key-values "${HOME}/.ssh/id_rsa.pub" 2>/dev/null
#--role "${ROLE_NAME}" \
# --role "contributor" \

NIC_ID="$(az vm show \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}" \
  --query 'networkProfile.networkInterfaces[0].id' \
  --output tsv)"
NSG_ID="$(az network nic show \
  --ids "${NIC_ID}" \
  --query 'networkSecurityGroup.id' \
  --output tsv)"
if [[ -n "${NSG_ID}" ]]; then
  NSG_NAME="$(basename "${NSG_ID}")"
  az network nsg rule create \
    --resource-group "${AZURE_RESOURCE_GROUP}" \
    --name "${VM_NAME}-open-ports" \
    --nsg-name "${NSG_NAME}" \
    --priority 100 \
    --destination-port-ranges 22 8200 \
    --access Allow \
    --protocol Tcp \
    -o none
fi
az vm list-ip-addresses --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM_NAME}"
az vm run-command invoke \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}" \
  --command-id "RunShellScript" \
  --scripts '
apt-get update && apt-get install -yq sudo jq wget gpg lsb-release;
wget -O- https://apt.releases.hashicorp.com/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg > /dev/null;
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list > /dev/null ;
sudo apt-get update && sudo apt-get install -yq vault ;
sed -i -e "/Condition/d" -e "/Limit/d" -e "/Capabil/d" -e "/yes/d" -e "/Protect/d" -e "/Secure/d" -e "/=vault/d" -e "s/server.*/server -tls-skip-verify -dev -dev-transactional -dev-ha -log-level=debug -dev-listen-address="0.0.0.0:8200" -dev-root-token-id=root/g" /usr/lib/systemd/system/vault.service;
systemctl daemon-reload ;
systemctl enable --now vault ;
'

echo ""
echo >&2 "[ NOTE ] User: ${ADMIN_USERNAME}"
echo >&2 "[ NOTE ] Password: ${ADMIN_PASSWORD}"
echo >&2 "[ NOTE ] Add Vault Address to your shell's environment variables:"
echo >&2 "export VAULT_ADDR="http://${IP_ADDR}:8200""
echo ""
echo >&2 "[ NOTE ] SSH Command"
echo >&2 "ssh -m "hmac-sha2-512" -o "StrictHostKeyChecking=no" -o "CheckHostIP=no" -o "UserKnownHostsFile=/dev/null" ${ADMIN_USERNAME}@${IP_ADDR}"

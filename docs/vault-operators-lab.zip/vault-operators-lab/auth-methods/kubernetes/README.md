# Kubernetes Auth Method
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
  - [Prerequisites](#prerequisites)
- [Create Service Account For Kubernetes Auth Method](#create-service-account-for-kubernetes-auth-method)
- [Create Service Account For Vault Client Pod](#create-service-account-for-vault-client-pod)
- [Create Service Account Token For Kuberenetes Auth Method Service Account](#create-service-account-token-for-kuberenetes-auth-method-service-account)
- [Create Service Account Token For Vault Client Pod](#create-service-account-token-for-vault-client-pod)
- [Create Cluster Role Binding For Kubernetes Auth Method Service Account](#create-cluster-role-binding-for-kubernetes-auth-method-service-account)
  - [Enable Kubernetes Auth Method](#enable-kubernetes-auth-method)
- [Configure Kubernetes Auth Method](#configure-kubernetes-auth-method)
- [Create a Kubernetes Auth method role](#create-a-kubernetes-auth-method-role)
- [Login](#login)
- [misc](#misc)
  - [Start Minikube Cluster](#start-minikube-cluster)
  - [Test Access To External Vault From Inside Minikube Pod](#test-access-to-external-vault-from-inside-minikube-pod)
- [references](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

In this guide , we will configure Kubernetes Auth Method

### Prerequisites

- A kubernetes cluster. We will use `minikube` in this guide
- Vault server is already running outside Kuberentes

## Create Service Account For Kubernetes Auth Method
<!-- AUTO-GENERATED-CONTENT:START (CODE:src=./manifests/service-account/vault-tokenreview.yaml -->
<!-- AUTO-GENERATED-CONTENT:END -->
```bash
kubectl apply -f "manifests/service-account/vault-tokenreview.yaml"
```

## Create Service Account For Vault Client Pod
<!-- AUTO-GENERATED-CONTENT:START (CODE:src=./manifests/service-account/vault-client-auth.yaml -->
<!-- AUTO-GENERATED-CONTENT:END -->
```bash
kubectl apply -f "manifests/service-account/vault-client-auth.yaml"
```

## Create Service Account Token For Kuberenetes Auth Method Service Account

> This is required in Kubernetes 1.24+
<!-- AUTO-GENERATED-CONTENT:START (CODE:src=./manifests/secret/vault-client-auth.yaml -->
<!-- AUTO-GENERATED-CONTENT:END -->
```bash
kubectl apply -f "manifests/secret/vault-client-auth.yaml"
```

## Create Service Account Token For Vault Client Pod

> This is required in Kubernetes 1.24+
<!-- AUTO-GENERATED-CONTENT:START (CODE:src=./manifests/secret/vault-client-auth.yaml -->
<!-- AUTO-GENERATED-CONTENT:END -->
```bash
kubectl apply -f "manifests/secret/vault-client-auth.yaml"
```

## Create Cluster Role Binding For Kubernetes Auth Method Service Account
<!-- AUTO-GENERATED-CONTENT:START (CODE:src=./manifests/cluster-role-binding/vault-tokenreview.yaml -->
<!-- AUTO-GENERATED-CONTENT:END -->
```bash
kubectl apply -f "manifests/cluster-role-binding/vault-tokenreview.yaml"
```

### Enable Kubernetes Auth Method

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Configure Kubernetes Auth Method

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-configure.sh&src=scripts/bash/cli/01-configure.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-configure.sh -->
```bash
# bash scripts/bash/cli/01-configure.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_SA_NAME_PREFIX="vault-tokenreview"
AUTH_MOUNT_PATH="kubernetes"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
if [ -z "${K8S_HOST+x}" ] || [ -z "${K8S_HOST}" ]; then
  K8S_HOST="$(minikube ip)"
fi
# Get the service account token name and save it to SA_NAME
SA_SECRET_NAME="$(kubectl get secrets --output=json \
  | jq -r '.items[].metadata | select(.name|startswith("'${AUTH_SA_NAME_PREFIX}'")).name')"
# Set SA_JWT_TOKEN value to the service account JWT used to access the
# TokenReview API
export SA_JWT_TOKEN=$(kubectl get secret "${SA_SECRET_NAME}" -o jsonpath="{.data.token}" | base64 --decode; echo)
# Set SA_CA_CRT to the PEM encoded CA cert used to talk to Kubernetes API
export SA_CA_CRT=$(kubectl get secret "${SA_SECRET_NAME}" -o jsonpath="{.data['ca\.crt']}" | base64 --decode; echo)
vault write "auth/${AUTH_MOUNT_PATH}/config" \
  token_reviewer_jwt="${SA_JWT_TOKEN}" \
  kubernetes_host="https://${K8S_HOST}:8443" \
  kubernetes_ca_cert="${SA_CA_CRT}" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Create a Kubernetes Auth method role

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-create-role.sh&src=scripts/bash/cli/02-create-role.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-create-role.sh -->
```bash
# bash scripts/bash/cli/02-create-role.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="kubernetes" ;
ROLE_NAME="example" ;
POLICIES="default" ;
BOUND_SERVICE_ACCOUNT_NAMES="vault-client-auth" ;
BOUND_SERVICE_ACCOUNT_NAMESPACES="default" ;
TTL="2h"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault write \
  "auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}" \
  token_policies="${POLICIES}" \
  bound_service_account_names="${BOUND_SERVICE_ACCOUNT_NAMES}" \
  bound_service_account_namespaces="${BOUND_SERVICE_ACCOUNT_NAMESPACES}" \
  ttl="${TTL}" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Login

> The login command is meant to be executed from inside a Kubernetes Pod.
- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-authenticate.sh&src=scripts/bash/cli/03-authenticate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-authenticate.sh -->
```bash
# bash scripts/bash/cli/03-authenticate.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="kubernetes" ;
ROLE_NAME="example" ;
POD_SERVICE_ACCOUNT_NAME="vault-client-auth" ;

#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
kubectl get po vault-client > /dev/null 2>&1 && kubectl delete po vault-client
# NOTE: on Mac/Windows, use 'VAULT_ADDR=http://host.docker.internal:8200'
kubectl run \
  -it \
  --rm=true \
  --env "VAULT_ADDR=http://host.minikube.internal:8200" \
  --image=vault \
  --restart=Never \
  --overrides='{ "apiVersion": "v1", "spec": { "serviceAccountName": "'${POD_SERVICE_ACCOUNT_NAME}'" } }' \
  vault-client \
  --command \
  vault write "auth/${AUTH_MOUNT_PATH}/login" \
  role="${ROLE_NAME}" \
  jwt=@/var/run/secrets/kubernetes.io/serviceaccount/token
```
<!-- AUTO-GENERATED-CONTENT:END -->
## misc

### Start Minikube Cluster
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/00-start-minikube.sh&src=scripts/bash/misc/00-start-minikube.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/00-start-minikube.sh -->
```bash
# bash scripts/bash/misc/00-start-minikube.sh
minikube start --network=host --vm-driver=docker || true ;
kubernetes_host="https://$(minikube ip):8443" ;
echo >&2 "[ NOTE ] minikube host ip address is" ;
echo >&2 "${kubernetes_host}" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Test Access To External Vault From Inside Minikube Pod
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/01-check-external-vault-access.sh&src=scripts/bash/misc/01-check-external-vault-access.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/01-check-external-vault-access.sh -->
```bash
# bash scripts/bash/misc/01-check-external-vault-access.sh
kubectl get po "curl" > /dev/null 2>&1 && kubectl delete po "curl"
# NOTE: on Mac/Windows, use 'VAULT_ADDR=http://host.docker.internal:8200'
kubectl run \
  -i \
  --tty=false \
  --rm=true \
  --env "VAULT_ADDR=http://host.minikube.internal:8200" \
  --image="curlimages/curl" \
  --restart=Never \
  "curl" \
  --command sh << 'EOF' | sed '/curl/d' | jq
  curl --silent "$VAULT_ADDR/v1/sys/seal-status"
EOF
```
<!-- AUTO-GENERATED-CONTENT:END -->
## references

- [Vault Docs: Kubernetes Auth Method](https://developer.hashicorp.com/vault/docs/auth/kubernetes)
- [Vault Tutorials: Bootstrapping Kubernetes Auth Method](https://developer.hashicorp.com/vault/docs/platform/k8s/helm/examples/kubernetes-auth)
- [Vault Tutorials: Integrate a Kubernetes Cluster with an External
Vault](https://developer.hashicorp.com/vault/tutorials/kubernetes/kubernetes-external-vault) 
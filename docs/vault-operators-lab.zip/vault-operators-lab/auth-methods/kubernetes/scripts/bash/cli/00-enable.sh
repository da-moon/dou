#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="kubernetes"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault auth enable \
  -path="${AUTH_MOUNT_PATH}" \
  kubernetes 
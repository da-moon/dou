#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_SA_NAME_PREFIX="vault-tokenreview"
AUTH_MOUNT_PATH="kubernetes"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
if [ -z "${K8S_HOST+x}" ] || [ -z "${K8S_HOST}" ]; then
  K8S_HOST="$(minikube ip)"
fi
# Get the service account token name and save it to SA_NAME
SA_SECRET_NAME="$(kubectl get secrets --output=json \
  | jq -r '.items[].metadata | select(.name|startswith("'${AUTH_SA_NAME_PREFIX}'")).name')"
# Set SA_JWT_TOKEN value to the service account JWT used to access the
# TokenReview API
export SA_JWT_TOKEN=$(kubectl get secret "${SA_SECRET_NAME}" -o jsonpath="{.data.token}" | base64 --decode; echo)
# Set SA_CA_CRT to the PEM encoded CA cert used to talk to Kubernetes API
export SA_CA_CRT=$(kubectl get secret "${SA_SECRET_NAME}" -o jsonpath="{.data['ca\.crt']}" | base64 --decode; echo)
vault write "auth/${AUTH_MOUNT_PATH}/config" \
  token_reviewer_jwt="${SA_JWT_TOKEN}" \
  kubernetes_host="https://${K8S_HOST}:8443" \
  kubernetes_ca_cert="${SA_CA_CRT}" ;
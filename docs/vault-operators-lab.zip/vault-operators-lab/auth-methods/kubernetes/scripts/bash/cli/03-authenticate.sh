#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="kubernetes" ;
ROLE_NAME="example" ;
POD_SERVICE_ACCOUNT_NAME="vault-client-auth" ;

#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
kubectl get po vault-client > /dev/null 2>&1 && kubectl delete po vault-client
# NOTE: on Mac/Windows, use 'VAULT_ADDR=http://host.docker.internal:8200'
kubectl run \
  -it \
  --rm=true \
  --env "VAULT_ADDR=http://host.minikube.internal:8200" \
  --image=vault \
  --restart=Never \
  --overrides='{ "apiVersion": "v1", "spec": { "serviceAccountName": "'${POD_SERVICE_ACCOUNT_NAME}'" } }' \
  vault-client \
  --command \
  vault write "auth/${AUTH_MOUNT_PATH}/login" \
  role="${ROLE_NAME}" \
  jwt=@/var/run/secrets/kubernetes.io/serviceaccount/token

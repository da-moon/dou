minikube start --network=host --vm-driver=docker || true ;
kubernetes_host="https://$(minikube ip):8443" ;
echo >&2 "[ NOTE ] minikube host ip address is" ;
echo >&2 "${kubernetes_host}" ;

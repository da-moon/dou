kubectl get po "curl" > /dev/null 2>&1 && kubectl delete po "curl"
# NOTE: on Mac/Windows, use 'VAULT_ADDR=http://host.docker.internal:8200'
kubectl run \
  -i \
  --tty=false \
  --rm=true \
  --env "VAULT_ADDR=http://host.minikube.internal:8200" \
  --image="curlimages/curl" \
  --restart=Never \
  "curl" \
  --command sh << 'EOF' | sed '/curl/d' | jq
  curl --silent "$VAULT_ADDR/v1/sys/seal-status"
EOF
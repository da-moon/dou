# UserPass auth method
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
  - [Enable the Auth method](#enable-the-auth-method)
  - [Create new users](#create-new-users)
  - [Authenticate](#authenticate)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

`userpass` auth method enables Vault users to authenticate with a `Username`
and `Password`.

This is a human-centric auth method and should be used as a last resort; it's
usually much more manageable to use Auth methods that use an external provider,
such as `Okta` .

### Enable the Auth method

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-enable.sh -->
```bash
# bash scripts/bash/cli/00-enable.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

AUTH_MOUNT_PATH="userpass"

vault auth enable \
  -path="${AUTH_MOUNT_PATH}" \
  userpass
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/00-enable.sh&src=scripts/bash/api/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/00-enable.sh -->
```bash
# bash scripts/bash/api/00-enable.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="userpass"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "userpass"}' \
  "${VAULT_ADDR}/v1/sys/auth/${AUTH_MOUNT_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\00-enable.ps1&src=scripts/powershell/cli/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/00-enable.ps1 -->
```powershell
# scripts\powershell\cli\00-enable.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_ROOT_TOKEN="root";
$Env:VAULT_TOKEN="$VAULT_ROOT_TOKEN";

$AUTH_MOUNT_PATH="userpass"

vault auth enable `
  -path="$AUTH_MOUNT_PATH" `
  userpass ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\00-enable.ps1&src=scripts/powershell/api/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/00-enable.ps1 -->
```powershell
# scripts\powershell\api\00-enable.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="userpass";

$REQUEST_BODY = @{
 "type" = "userpass";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/sys/auth/$AUTH_MOUNT_PATH"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Create new users

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-create-user.sh&src=scripts/bash/cli/01-create-user.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-create-user.sh -->
```bash
# bash scripts/bash/cli/01-create-user.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"
VAULT_TOKEN="${VAULT_ROOT_TOKEN}"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"
POLICIES='["default"]'

vault write \
  "auth/${AUTH_MOUNT_PATH}/users/${USERNAME}" \
  password="${PASSWORD}" \
  policies="${POLICIES}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/01-create-user.sh&src=scripts/bash/api/01-create-user.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/01-create-user.sh -->
```bash
# bash scripts/bash/api/01-create-user.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"
POLICIES='["default"]'
PAYLOAD="$(jq -n \
  --arg password "${PASSWORD}" \
  --argjson policies "${POLICIES}" \
  '{"token_policies":$policies,"password":$password}')"

curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/users/${USERNAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\01-create-user.ps1&src=scripts/powershell/cli/01-create-user.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/01-create-user.ps1 -->
```powershell
# scripts\powershell\cli\01-create-user.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_ROOT_TOKEN="root";
$Env:VAULT_TOKEN="$VAULT_ROOT_TOKEN";

$AUTH_MOUNT_PATH="userpass"
$USERNAME="foo";
$PASSWORD="bar"
$POLICIES='["default"]'
vault write `
  "auth/$AUTH_MOUNT_PATH/users/$USERNAME" `
  password="$PASSWORD" `
  policies="$POLICIES" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\01-create-user.ps1&src=scripts/powershell/api/01-create-user.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/01-create-user.ps1 -->
```powershell
# scripts\powershell\api\01-create-user.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="userpass";
$USERNAME="foo";
$PASSWORD="bar";
$POLICIES=New-Object Collections.Generic.List[String];
$POLICIES.add("default");
$REQUEST_BODY = @{
  "token_policies"=$POLICIES;
  "password"="$PASSWORD";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/users/$USERNAME"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Authenticate

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-authenticate.sh&src=scripts/bash/cli/02-authenticate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-authenticate.sh -->
```bash
# bash scripts/bash/cli/02-authenticate.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"
VAULT_TOKEN="${VAULT_ROOT_TOKEN}"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"

vault login \
  -method=userpass \
  -path="${AUTH_MOUNT_PATH}" \
  username="${USERNAME}" \
  password="${PASSWORD}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/02-authenticate.sh&src=scripts/bash/api/02-authenticate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/02-authenticate.sh -->
```bash
# bash scripts/bash/api/02-authenticate.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"
PAYLOAD="$(jq -n \
  --arg password "${PASSWORD}" \
  '{"password":$password}')"

curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/login/${USERNAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\02-authenticate.ps1&src=scripts/powershell/cli/02-authenticate.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/02-authenticate.ps1 -->
```powershell
# scripts\powershell\cli\02-authenticate.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_ROOT_TOKEN="root";
$Env:VAULT_TOKEN="$VAULT_ROOT_TOKEN";

$AUTH_MOUNT_PATH="userpass"
$USERNAME="foo";
$PASSWORD="bar";
vault login `
  -method=userpass `
  -path="$AUTH_MOUNT_PATH" `
username="$USERNAME" `
password="$PASSWORD" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\02-authenticate.ps1&src=scripts/powershell/api/02-authenticate.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/02-authenticate.ps1 -->
```powershell
# scripts\powershell\api\02-authenticate.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="userpass";
$USERNAME="foo";
$PASSWORD="bar";
$REQUEST_BODY = @{
  "password"="$PASSWORD";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/login/$USERNAME"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $jsonObj.auth.client_token
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

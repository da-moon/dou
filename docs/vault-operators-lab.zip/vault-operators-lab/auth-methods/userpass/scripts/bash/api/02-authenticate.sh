VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"
PAYLOAD="$(jq -n \
  --arg password "${PASSWORD}" \
  '{"password":$password}')"

curl -fSsl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT_PATH}/login/${USERNAME}"

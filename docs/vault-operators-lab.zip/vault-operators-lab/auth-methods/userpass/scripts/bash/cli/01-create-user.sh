VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"
VAULT_TOKEN="${VAULT_ROOT_TOKEN}"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"
POLICIES='["default"]'

vault write \
  "auth/${AUTH_MOUNT_PATH}/users/${USERNAME}" \
  password="${PASSWORD}" \
  policies="${POLICIES}"

VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"
VAULT_TOKEN="${VAULT_ROOT_TOKEN}"

AUTH_MOUNT_PATH="userpass"
USERNAME="foo"
PASSWORD="bar"

vault login \
  -method=userpass \
  -path="${AUTH_MOUNT_PATH}" \
  username="${USERNAME}" \
  password="${PASSWORD}"

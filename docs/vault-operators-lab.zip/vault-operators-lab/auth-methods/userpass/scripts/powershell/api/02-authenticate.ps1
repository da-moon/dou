$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$AUTH_MOUNT_PATH="userpass";
$USERNAME="foo";
$PASSWORD="bar";
$REQUEST_BODY = @{
  "password"="$PASSWORD";
}
$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")

$URI=$VAULT_ADDR+"/v1/auth/$AUTH_MOUNT_PATH/login/$USERNAME"
$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -Headers $HEADERS `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -eq '200') {
  $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
  $jsonObj.auth.client_token
}

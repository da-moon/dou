$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_ROOT_TOKEN="root";
$Env:VAULT_TOKEN="$VAULT_ROOT_TOKEN";

$AUTH_MOUNT_PATH="userpass"

vault auth enable `
  -path="$AUTH_MOUNT_PATH" `
  userpass ;

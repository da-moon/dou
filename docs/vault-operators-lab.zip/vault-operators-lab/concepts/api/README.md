# Vault API
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Vault Control Plane](#vault-control-plane)
- [Vault Data Plane](#vault-data-plane)
  - [Auth Methods](#auth-methods)
  - [Auth Methods : Overview](#auth-methods--overview)
  - [Auth Methods : API request flow](#auth-methods--api-request-flow)
  - [Secret Engines](#secret-engines)
    - [Secret Engine : Overview](#secret-engine--overview)
    - [Secret Engine : API Request Flow](#secret-engine--api-request-flow)
- [Summary](#summary)
  - [Vault Operator Request Flow](#vault-operator-request-flow)
  - [Client Request Flow](#client-request-flow)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

Every aspect of Vault is designed to be managable through it's RESTful API.
Vault followes a Service Mesh Architecture and has a `Data Plane` and a
`Control` Plane.

## Vault Control Plane

Vault's control plane consists of API endpoints under `/sys` URI. the following table consists of some example endpoints

| Path                     | Capablity                                            | Description                                            |
|--------------------------|------------------------------------------------------|--------------------------------------------------------|
| `sys/mounts`             | `read`                                               | List available secrets engines to retrieve accessor ID |
| `sys/mounts/*`           | `create`, `read`, `update`, `delete`                 | enable secrets engines                                 |
| `sys/auth`               | `read` , `list`                                      | Configure auth methods (1)                             |
| `sys/auth/*`             | `create`, `update`, `read`, `delete`, `list`, `sudo` | Configure auth methods (2) ( with UI )                 |
| `sys/policies`           | `read` , `list`                                      | Display the Policies tab in UI                         |
| `sys/policies/acl`       | `read` , `list`                                      | Create and manage policies (1)                         |
| `sys/policies/acl/*`     | `create`, `update`, `read`, `delete`, `list`, `sudo` | Create and manage policies (2) ( with UI )             |

- Keep in mind that Vault Policies fall under `Control Plane` API

## Vault Data Plane

### Auth Methods

### Auth Methods : Overview

- endpoints user authenticate to Vault with.
- The endgoal is for the user to get a `Bearer Token` so that they can interact with Vault's protected API endpoints
- These endpoints are always under `auth/` path; e.g `auth/userpass`
- An Auth method uses `Roles` ; a `Role` is a collection of Vault `Policies`.
- When a user authenticates against a Role, the returned Token includes some
metadata embeded in it; the most important piece is the associated `policies`

### Auth Methods : API request flow

- Users will send a `POST` request to an API endpoint
  - Request URI contains the auth method mount path e.g: `auth/approle/login`
    - `/auth/` and `login` components of the URI are constant
    - `/approle/` is the Auth method mount path
  - Often login parameters and `role name` is part of request body.
- If a request is successful, Vault will return a Token that has the __Role's__ associated policies attached to it
- Users will use that Token in their consequent API calls to Other endpoint in the Data plane or Control Plane

### Secret Engines

#### Secret Engine : Overview

- A Vault secret engine can be treated as a microservice.Secret Engine API
endpoints are what users are actually interested in; they do things such as
generate dynamic credentials
- They are mounted under Vault API's `Root` (`/`) URI; e.g `/kv` or `/azure`
- Most engines have use concept of `roles`. A secret engine role can be seen as
a 'profile'; it's a way to customize behaviour of the Secret engine. For
instance you can have a role that generates dynamic credentials with `TTL` of
`2` hours and another one with `TTL` of `12` hours
- A secret engine Role is not the same as Auth Method Roles.

#### Secret Engine : API Request Flow

- Vault Daemon behaves as an API gateway; intercepting incoming calls
- Vault clients in their API calls to the secret engine, would define the Secret Engine Role associated with the request
- After recieving a request, It will look into `X-Vault-Token` Header. In case the target endpoint of the request is protected, it will :
  - `Authentication` : Make sure the token is valid
  - `Authorization`:  Once a request is recieved, Vault will check associated **policies**
  with the bearer token to ensure:
    - can do the requested operation ( HTTP Verb e.g `GET` ) 
    - against the target Path (URI) and has the approved parameters in the request body
      - `URI` : Target URI is always validated against associated policy. often requested `Role` name is part of the URI path. eg : `azure/creds/example`
        - Mount Path : `azure/`
        - Role Name : `example`
      - `Request Data` : Some secret engine Roles require users to pass in
      extra parameters (besides Role name which is in URI of the request) in request body and fields in request body fields are
      also under control of Vault policies
- In case the associated token passes Authentication and Authorization checks,
the request will be forwarded to target secret engine. There are two types of
Secret Engines:
  - `Built-In` : These are secret engine in which their code is bundled with Vault binary; e.g `Azure` secret engine
  - `Vendored` : These are indipendent programs; RPC servers mainly written in Go. When a request is going to a Vendored secret engine, Vault Daemon will 
    - send the request over RPC to the plugin and wait for it's reply
    - Forwards the engine's reply to user
    - `Oracle Database Secrets Engine` is an example of Vendored Secret engine

## Summary

### Vault Operator Request Flow

- Operator would authenticate against an Auth method with a role that gives them approporiate policies for operation on Control Plane API endpoints
- They would run priviledged operations such as
  - Mounting/Tuning Secret Engine/Auth method
  - Creating New Vault policies
  - Creating/modifying Auth method Roles
  - Creating/modifying Secret Engine Roles
  - Working with Vault token leases ( e.g Revocation )

### Client Request Flow

- A user with send a Login request to an `Auth Method`
- They will get a Token which they will use in they API calls to Secret Engines


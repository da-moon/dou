#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
UNSEAL_KEYS=(
"T97Dtwvqon0+K0By/g74x86bbq7jabL8sb8V2adndi8="
)
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:9200}" ;
VAULT_DR_INIT="$(vault operator generate-root -format=json -dr-token -init)" ;
NONCE="$(echo "${VAULT_DR_INIT}" | jq -r '.nonce')" ;
OTP="$(echo "${VAULT_DR_INIT}" | jq -r '.otp')" ;
VAULT_DR_ENCODED_RESP=""
for key in "${UNSEAL_KEYS[@]}"; do
  VAULT_DR_ENCODED_RESP="$(vault operator generate-root -format=json -dr-token -nonce="${NONCE}" "${key}")" ;
done

DR_ENCODED_TOKEN="$(echo "${VAULT_DR_ENCODED_RESP}" | jq -r '.encoded_token')" ;

DR_OPERATIONS_TOKEN="$(vault operator generate-root -format=json -dr-token -decode="${DR_ENCODED_TOKEN}" -otp="${OTP}" | jq -r '.token')" ;
echo >&2 "[ NOTE ] : DR Operations Token" ;
echo >&2 "${DR_OPERATIONS_TOKEN}" ;

#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
DR_OPERATIONS_TOKEN="hvs.YTpfKQxPcCryJRJJiytXcCLF"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:9200}" ;
#export VAULT_TOKEN="${DR_OPERATIONS_TOKEN}" ; 
vault write -f "sys/replication/dr/secondary/promote" dr_operation_token="${DR_OPERATIONS_TOKEN}" ;
sleep 5 ;
vault read "sys/replication/status" -format=json | jq -r '.data'

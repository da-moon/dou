#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}" ;
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
vault write -f "sys/replication/dr/primary/demote"
sleep 5 ;
vault read "sys/replication/status" -format=json | jq -r '.data' ;
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
UNSEAL_KEYS=(
"T97Dtwvqon0+K0By/g74x86bbq7jabL8sb8V2adndi8="
)
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export DC1_VAULT_ADDR="${DC1_VAULT_ADDR:-http://127.0.0.1:8200}"
export DC1_VAULT_TOKEN="${DC1_VAULT_TOKEN:-root}"
export DC2_VAULT_ADDR="${DC2_VAULT_ADDR:-http://127.0.0.1:9200}"
export DC2_VAULT_TOKEN="${DC2_VAULT_TOKEN:-root}"

export VAULT_ADDR="${DC2_VAULT_ADDR}" ;
export VAULT_TOKEN="${DC2_VAULT_TOKEN}" ;
uuid="$(uuidgen)" ;
uuid="${uuid,,}" ;
WRAPPING_TOKEN="$(vault write -field="wrapping_token" -f  "sys/replication/dr/primary/secondary-token" id="${uuid}")" ;

export VAULT_ADDR="${DC1_VAULT_ADDR}" ;
# export VAULT_TOKEN="${DC1_VAULT_TOKEN}" ;
# vault write -f "sys/replication/dr/primary/demote"
unset VAULT_TOKEN ;

VAULT_DR_INIT="$(vault operator generate-root -format=json -dr-token -init)" ;
NONCE="$(echo "${VAULT_DR_INIT}" | jq -r '.nonce')" ;
OTP="$(echo "${VAULT_DR_INIT}" | jq -r '.otp')" ;
VAULT_DR_ENCODED_RESP=""
for key in "${UNSEAL_KEYS[@]}"; do
  VAULT_DR_ENCODED_RESP="$(vault operator generate-root -format=json -dr-token -nonce="${NONCE}" "${key}")" ;
done

DR_ENCODED_TOKEN="$(echo "${VAULT_DR_ENCODED_RESP}" | jq -r '.encoded_token')" ;

DR_OPERATIONS_TOKEN="$(vault operator generate-root -format=json -dr-token -decode="${DR_ENCODED_TOKEN}" -otp="${OTP}" | jq -r '.token')" ;
export VAULT_ADDR="${DC1_VAULT_ADDR}" ;
vault write "sys/replication/dr/secondary/update-primary" dr_operation_token="${DR_OPERATIONS_TOKEN}" token="${WRAPPING_TOKEN}" ;

sleep 5 ;
vault read "sys/replication/status" -format=json | jq -r '.data'

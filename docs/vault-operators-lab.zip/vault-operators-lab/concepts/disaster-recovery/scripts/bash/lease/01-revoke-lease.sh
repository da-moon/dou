#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
LEASE_PATH="auth/token/create"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
BASE_URI="sys/leases/lookup"
#--------------------------------------------------------------------#
LEASES=( $(vault list -format=json "${BASE_URI}/${LEASE_PATH}" | jq -r '.[]|select( (contains("/") | not ) and ( length > 50))') )
for lease in ${LEASES[@]}; do
  echo >&2 "[ NOTE ] Revoking '${lease}'" ;
  vault lease revoke "${LEASE_PATH}/${lease}" ;
done

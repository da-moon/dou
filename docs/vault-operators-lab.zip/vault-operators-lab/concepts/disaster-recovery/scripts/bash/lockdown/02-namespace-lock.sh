#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
NAMESPACE="cloud-automation"
UNLOCK_KEY="JHGpopcotpNlkVUYo8up6NUu"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
#export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_TOKEN="$(vault token create -field token -policy=admin)"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

vault namespace lock -unlock-key="${UNLOCK_KEY}" -format json "${NAMESPACE}" \
  | jq -r '.data.unlock_key' \
  | tee "ns-unlock-key.txt" ;

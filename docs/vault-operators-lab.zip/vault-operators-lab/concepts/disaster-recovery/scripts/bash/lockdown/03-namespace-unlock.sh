
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
NAMESPACE="cloud-automation"
UNLOCK_KEY="plRIAyHZondW07qSkqZ3eu1U"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="$(vault token create -field token -policy=admin)"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

vault namespace unlock -unlock-key="${UNLOCK_KEY}" "${NAMESPACE}"

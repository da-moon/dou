#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SP_NAME="example-vault-auto-unseal"
KV_NAME="auto-unseal-$(uuidgen | cut -d- -f1)"
LOCATION="canadaeast"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi

SERVICE_PRINCIPAL="$(az ad sp create-for-rbac \
  --name "${SP_NAME}" \
  --role "Key Vault Contributor" \
  --scopes "/subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}")" ;

echo "${SERVICE_PRINCIPAL}" |
  jq \
    --arg subscription_id "${AZURE_SUBSCRIPTION_ID}" \
    '{
    "client_id": .appId, 
    "client_secret": .password, 
    "tenant_id": .tenant, 
    "subscription_id": $subscription_id
  }' | tee "service-principal.json" | jq -r '.'
CLIENT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".appId")
CLIENT_SECRET=$(echo "$SERVICE_PRINCIPAL" | jq -r ".password")
TENANT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".tenant")

az keyvault create \
  --name "${KV_NAME}" \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --location "${LOCATION}" ;

az keyvault set-policy \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${KV_NAME}" \
  --spn "${CLIENT_ID}" \
  --certificate-permissions all \
  --key-permissions all \
  --secret-permissions all \
  --storage-permissions all ;

echo "--------------------------------------------------------------------"
echo >&2 "[ NOTE ] Set The following Azure Auth method environment variables in your shell:"
# echo >&2 "export TENANT_ID="${TENANT_ID}""
echo >&2 "export AZURE_SERVICE_PRINCIPLE_CLIENT_ID="${CLIENT_ID}""
echo >&2 "export AZURE_SERVICE_PRINCIPLE_CLIENT_SECRET="${CLIENT_SECRET}""
echo "--------------------------------------------------------------------"

echo >&2 "Key Vault Name:" ;
echo >&2 "${KV_NAME}" ;

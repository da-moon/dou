#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
TMP_DIR="/tmp/vault-snapshot"
SNAPSHOT_FILE_NAME="manual"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
if [ -z "${TMP_DIR+x}" ] || [ -z "${TMP_DIR}" ]; then
  TMP_DIR="$(mktemp -d)"
fi
[ ! -d "${TMP_DIR}" ] && mkdir -p "${TMP_DIR}" ;
vault operator raft snapshot save "${TMP_DIR}/${SNAPSHOT_FILE_NAME}.snap"
echo >&2 "Snapshot Path" ;
echo >&2 "${TMP_DIR}/${SNAPSHOT_FILE_NAME}.snap" ;

#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
RECOVERY_THRESHOLD="3"
RECOVERY_SHARES="5"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
#          initialize vault and store result in a variable           #
#--------------------------------------------------------------------#
export VAULT_INIT="$(vault operator init -recovery-shares=${RECOVERY_SHARES} -recovery-threshold="${RECOVERY_THRESHOLD}" -format=json)" ;
#--------------------------------------------------------------------#
#           extract generated root token and store it in a           #
#                                file                                #
#--------------------------------------------------------------------#
export INITIAL_ROOT_TOKEN="$(printenv VAULT_INIT | awk '/root_token/ { gsub(/[",]/,"",$2); print $2}')" ;
echo "${INITIAL_ROOT_TOKEN}" >> "initial-root-token.txt"
#--------------------------------------------------------------------#
#         extract recovery key shares and store it in a file         #
#--------------------------------------------------------------------#
export VAULT_RECOVER_KEYS=()
counter=1;
while [ $counter -le $RECOVERY_SHARES ];do
  RECOVERY_KEY_SHARE="$(printenv VAULT_INIT | sed -r '/\[$/ {:a;N;s/\]/&/;Ta;s/\n +//g}' | awk -v FS=':' -v OFS='\n' "/\"recovery_keys_b64\"/ {gsub(/[]\"[[:space:]]/,\"\",\$2);split(\$2,a,/,/);print a[$counter]}")"
  VAULT_RECOVER_KEYS+=("${RECOVERY_KEY_SHARE}")
  echo "${RECOVERY_KEY_SHARE}" >> "recovery-key-shares.txt"
  counter=$((counter+1)) ;
done
#--------------------------------------------------------------------#
#                      create a new root token                       #
#--------------------------------------------------------------------#
VAULT_TOKEN="$(printenv INITIAL_ROOT_TOKEN)" vault token create -id "root" -policy=root

#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
TMP_DIR="/tmp/vault-snapshot"
SNAPSHOT_FILE_NAME="manual"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
vault operator raft snapshot restore -force "${TMP_DIR}/${SNAPSHOT_FILE_NAME}.snap"

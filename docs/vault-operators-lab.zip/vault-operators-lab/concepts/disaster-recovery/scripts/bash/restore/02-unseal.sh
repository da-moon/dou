#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
UNSEAL_KEYS=(
"+Re8e6oEIO5M9tL5LyTOc88kLAWpzVl8BOUsOIzyj4s="
)
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

for key in "${UNSEAL_KEYS[@]}"; do
  echo >&2 "[ NOTE ] Unsealing Vault with Recovery Share/Unseal Key : '${key}'"
  vault operator unseal "${key}" ;
done


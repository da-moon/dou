# lease
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [overview](#overview)
<!-- AUTO-GENERATED-CONTENT:END -->
## overview

- A lease must be renewed before it has expired. Once it has expired, it is
permanently revoked and a new secret must be requested.
- With every `dynamic secret` and `service type token`, Vault creates a lease
  - `secret` : `vault lease [ revoke | renew ]`
  - `token` : `vault token ...`
- `kv` secret engine does not issue leases.
- `increment` This is not an increment at the end of the current TTL; it is an
increment from the current time.
- The requested increment is completely advisory. The backend in charge of the
secret can choose to completely ignore it.
- revoke credential i.e aws dynamic secret `vault lease revoke aws/creds/admin/1234567`
- Lease IDs are structured in a way that their prefix is always the path where
the secret was requested from. This lets you revoke trees of secrets. For
example, to revoke all AWS access keys, you can do `vault lease revoke -prefix
aws/.`
- renew/revoke -> `lease_id` -> When reading a dynamic secret, such as via `vault read`, Vault always returns a
`lease_id`.
- `vault lease revoke -f -prefix <path>` to revoke all leases from a specific
secret engine without caring about existing users in the remote database. 
- `vault list sys/leases/lookup` you are also able to browse existing leases
and see if and where these exist.

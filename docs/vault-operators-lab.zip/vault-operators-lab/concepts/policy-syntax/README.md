# vault-policy-syntax
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [cli](#cli)
- [path](#path)
- [Required Response Wrapping TTLs](#required-response-wrapping-ttls)
- [capabilities](#capabilities)
- [Parameter Constraints](#parameter-constraints)
- [built-in policies](#built-in-policies)
- [capabalities](#capabalities)
- [Root protected API endpoints](#root-protected-api-endpoints)
- [references](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

- Vault architecture is heavily inspired by *nix filesystem. interaction with
Vault backend operations are through an `entity` struct; an entity has a
`path`, optional `data` and capablities.

- Vault entities are
[`logical`](https://github.com/hashicorp/vault/tree/master/sdk/logical) and
[`physical`](https://github.com/hashicorp/vault/tree/master/sdk/physical), just
like Linux file system:
  - `Logical` entities are just like path under `dev/` or `sys/` in linux file
  system, they are 'psuedo-files' used to expose API functionalities and do not
  store any raw data
    - entities that configure secret engines, auth methods and `sys/` in Vault
    are some examples of this entity type.
  - `Physical` entities store data but do not take part in any logical
  operations.
    - `role` entities, or static secrets stored in KV secret engine are some
    examples of this entity type.

- general format:

```hcl
path "path/to/entity" {
  capabilities = ["create, "update", "read", "delete", "list","sudo"]
  
  min_wrapping_ttl = "3s"
  max_wrapping_ttl = "30s"

  required_parameters = ["two"]

  allowed_parameters = {
    "one" = []
    "two" = ["three", "four"]
  }
  denied_parameters = {
    "foo" = []
  }
}
```

## cli

- `vault policy [ write | read | list | fmt | delete ]`
- `vault policy write <policy-name> < path-on-disk | - >`
- `vault policy list` : list all policies
  - `vault read sys/policy`
- `vault policy delete <policy-name>` : removes a policy
  - once the policy is deleted, all tokens associated with the policy are affected immediately
  - it is __not__ possible to delete the `default` or `root` policies.
- `vault policy fmt <path-to-policy-on-disk>` :  formats and overwrites the policy file at the given path.

## path

- Vault path can have two types of special characters used for matching
arbitrary strings
    - `*` : 'globbing' pattern used only at the __end__ of a path, telling
    vault to prefix match (match all keys).
    - `+` : 'wildcard' pattern used only in the middle of a path, telling vault
    to match everything in between.
  - The most specific defined policy is used, either an `exact match` or the
  `longest-prefix glob` match.

## Required Response Wrapping TTLs

- `min_wrapping_ttl` :
  - The minimum allowed TTL that clients can specify for a wrapped response. 
  - setting a minimum TTL of __one second__ effectively makes response wrapping
  mandatory for a particular path. 
  - this can also be used to ensure that the TTL is not too low, leading to end
  targets being unable to unwrap before the token expires.

- `max_wrapping_ttl` :
  - The maximum allowed TTL that clients can specify for a wrapped response.

## capabilities

- `deny` : 
  - default capabilities.
  - Denies all operations
  - takes precedence and 'Vetos' all other capabilities in case there are other
  capabilities applied/inherited.
- `sudo` : 
  - Allows access to paths that are __root-protected__
  - Tokens need to have sudo capability to interact with __root-protected__
  paths
  - you need to specify other capabilities as needed (such as 'create','read').
- `read` 
  - maps to `GET` HTTP requests.
  - `vault read` command needs this capablity
  - allows reading the data at the given path.
- `list` 
  - maps to `LIST` HTTP requests. 
  - `vault list` command needs this capablity
  - lists 'keys' under a given path.
  - not recursive, only returnes direct child entity keys.
  - do not encode sensitive information in key names. 
  - not all backends support listing.
  - Policies with `list` capabilities should end with a trailing slash
- `delete` 
  - maps to `DELETE` HTTP requests. 
  - `vault delete` command needs this capablity
  - Allows deleting entities at the given path.
- `create` 
  - maps to `POST` and `PUT` HTTP requests.
  - `vault write` command needs this capablity
  - Allows creating data at the given path.
- `update`
  - maps to `POST` and `PUT` HTTP requests.
  - `vault write` command needs this capablity
  - Allows changing the data at the given path.
  - In most parts of Vault, this capablitiy implicitly includes the ability to
  create the initial value at the path
  - Very few parts of Vault distinguish between create and update;  most
  operations require both create and update capabilities. 

## Parameter Constraints

- `required_parameters` : A list of parameters that must be specified .
- `allowed_parameters` : 
  - a list of keys and values that are permitted on the given path
  - to allow any value for a specific parameter, use `[]` e.g
  
```hcl
# [ NOTE ] => the path only accepts "some-parameter" as parameter . "some-parameter" can accept any value.
allowed_parameters = {
  "some-parameter" = []
}
```

  - by including `allowed_parameters` stanza, all parameters that are not
  explicitly defined are rejected unless a `*` is included. e.g:

```hcl
# [ NOTE ] => forces the path to only accept "accepted-value" for "some-parameter" parameter and block every other parameter
allowed_parameters = {
  "some-parameter" = ["accepted-value"]
}
#########################
# [ NOTE ] => forces the path to only accept "accepted-value" for "some-parameter" parameter and allow any value for all other parameters
allowed_parameters = {
  # [ NOTE ] => only accept "accepted-value" for "some-parameter" parameter
  "some-parameter" = ["accepted-value"]
  # [ NOTE ] => accept all values for all other parameters
  "*"   = []
}
```

- `denied_parameters` 
  - can be used to block specific parameters or values. e.g
  
```hcl
denied_parameters = {
  # [ NOTE ] =>  this makes sure vault rejects "unacceptable-value" as a value for "some-parameter" parameter 
  "some-parameter" = ["unacceptable-value"]
}
```

  - takes precedence over `allowed_parameters`
  - you can deny a specific parameter by setting it's value to `[]`. e.g

```hcl
denied_parameters = {
  # [ NOTE ] => 'deny-me' parameter is not accepted
  "deny-me" = []
}
```
  - you can block all parameters for a specifc path

```hcl
path "path/without/parameters" {
  capabilities = ["create"]
  denied_parameters = {
    "*" = []
  }
}
```

- parameter values for both `allowed_parameters` and `denied_parameters`
stanzas also support prefix/suffix globbind by prepending or appending or
prepending `*` to a value. e.g

```hcl
allowed_parameters = {
  # [ NOTE ] => as an example , 'my-accepted-value' is an acceptable value for "some-parameter" parameter
  "some-parameter" = ["*-accepted-*"]
}
```

## built-in policies

- `default` : basic functionality such as the ability for the token to look up
data about itself and to use its cubbyhole data. 
  - modifiable
  - attached to all tokens by default. disable attachment with `vault token create -no-default-policy`
- `root` : 'sudo' access
  - immutable
  - recommended to revoke any root tokens before running Vault in production.


## capabalities

| Path                 | Capablity                                            | Description                                |
|----------------------|------------------------------------------------------|--------------------------------------------|
| `sys/policies`       | `read` , `list`                                      | Display the Policies tab in UI             |
| `sys/policies/acl`   | `read` , `list`                                      | Create and manage policies (1)             |
| `sys/policies/acl/*` | `create`, `update`, `read`, `delete`, `list`, `sudo` | Create and manage policies (2) ( with UI ) |

## Root protected API endpoints

| Path                                                  | HTTP verb               | Description                                                                                |
|-------------------------------------------------------|-------------------------|--------------------------------------------------------------------------------------------|
| `auth/token/accessors`                                | `LIST`                  | List token accessor                                                                        |
| `auth/token/create-orphan`                            | `POST`                  | Create an orphan token (the same as `no_parent` option)                                    |
| `auth/token`                                          | `POST`                  | Create a periodic or an orphan token (`period` or `no_parent`) option                      |
| `pki/root`                                            | `DELETE`                | Delete the current CA key (`pki secrets engine`)                                           |
| `pki/root/sign-self-issued`                           | `POST`                  | Use the configured CA certificate to sign a self-issued certificate (`pki secrets engine`) |
| `sys/audit`                                           | `GET`                   | List enabled audit devices                                                                 |
| `sys/audit/:path`                                     | `PUT`, `DELETE`         | Enable or remove an audit device                                                           |
| `sys/auth/:path`                                      | `GET`, `POST`, `DELETE` | Manage the auth methods (enable, read, delete, and tune)                                   |
| `sys/config/auditing/request-headers`                 | `GET`                   | List the request headers that are configured to be audited                                 |
| `sys/config/auditing/request-headers:name`            | `GET`, `PUT`, `DELETE`  | Manage the auditing headers (create, update, read and delete)                              |
| `sys/config/cors`                                     | `GET`, `PUT`, `DELETE`  | Configure CORS setting                                                                     |
| `sys/config-ui`                                       | `GET`                   | Configure the UI settings                                                                  |
| `sys/internal/specs/openapi`                          | `GET`                   | Generate an OpenAPI document of the mounted backends                                       |
| `sys/leases/lookup/:prefix`                           | `LIST`                  | List lease IDs                                                                             |
| `sys/leases/revoke-force/:prefix`                     | `PUT`                   | Revoke all secrets or tokens ignoring backend errors                                       |
| `sys/leases/revoke-prefix/:prefix`                    | `PUT`                   | Revoke all secrets generated under a given prefix                                          |
| `sys/plugins/catalog/:type/:name`                     | `GET`, `PUT`, `DELETE`  | Register a new plugin, or read/remove an existing plugin.                                  |
| `sys/raw`                                             | `LIST`, `GET`           | Returns a list of keys for a given path prefix                                             |
| `sys/replication/reindex`                             | `POST`                  | Reindex the local data storage                                                             |
| `sys/replication/performance/primary/secondary-token` | `POST`                  | Generate a performance secondary activation token                                          |
| `sys/replication/dr/primary/secondary-token`          | `POST`                  | Generate a DR secondary activation token                                                   |
| `sys/rotate`                                          | `PUT`                   | Trigger a rotation of the backend encryption key                                           |
| `sys/seal`                                            | `PUT`                   | Seals the Vault                                                                            |
| `sys/step-down`                                       | `PUT`                   | Forces the node to give up active status                                                   |

## references

- https://www.vaultproject.io/docs/concepts/policies
- [`root` protected api endpoints](https://learn.hashicorp.com/tutorials/vault/policies#root-protected-api-endpoints)
- [Vault source code](https://github.com/hashicorp/vault/tree/master/sdk)
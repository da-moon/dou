# Rekeying And Rotating Vault
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Rekeying Vault](#rekeying-vault)
- [Rotating the encryption key](#rotating-the-encryption-key)
- [References](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

All data stored by Vault is encrypted:

- There is an __encryption key__ that is used for encrypting/decrypting the data
- The __encryption key__ is stored with the data (in the keyring) in an encrypted state
- The Key that encrypts the __encryption key__ is known as __root key__ ( or __master key__ )
- When a Vault server is first initialized, Vault generates the __root key__
and splits it into a series of key shares following Shamir's Secret Sharing
Algorithm
- __Unsealing__ is the process of obtaining the plaintext root key necessary to
read the decryption key to decrypt the data, allowing access to the Vault.

So essentially, there are two encryption keys :

- most Vault data is encrypted using the __encryption key__ in the keyring; 
- the keyring is encrypted by the __root key__
- The __root key__ can be reconstructed with shamir key shares or recovery key shares ( when using auto-unseal )
- Do not confuse this __root key__ with the __root token__ ; they are not the same.

In some cases, you may want to re-generate the root key and its key shares. Here are a few examples:

- Someone joins or leaves the organization
- Security wants to change the number of shares or threshold
- Compliance mandates the keys be rotated at a regular interval

To sum up:

- `rekey` : The process for generating a new root key and applying Shamir's algorithm
- `rotation` : The process for generating a new encryption key for Vault

## Rekeying Vault
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/00-rekey.sh&src=scripts/bash/00-rekey.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/00-rekey.sh -->
```bash
# bash scripts/bash/00-rekey.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
UNSEAL_KEYS=(
"xGUqOFFPj1WuMTdsiprQTwJKrKY8hjSqzWNmTyS6lG8="
)
RECOVERY_THRESHOLD="3"
RECOVERY_SHARES="5"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

REKEY_INIT="$(vault operator rekey -init -key-shares=${RECOVERY_SHARES} -key-threshold="${RECOVERY_THRESHOLD}" -target="recovery" -format JSON)" ;
NONCE="$(echo "${REKEY_INIT}" | jq -r '.nonce')" ;
REKEY_RESP=""
for key in "${UNSEAL_KEYS[@]}"; do
  REKEY_RESP="$(vault operator rekey -target="recovery" -format="json" -nonce="${NONCE}" "${key}")"
done
echo "${REKEY_RESP}" | tee "rekey.json" | jq -r '.'
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Rotating the encryption key
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/01-rotation.sh&src=scripts/bash/01-rotation.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/01-rotation.sh -->
```bash
# bash scripts/bash/01-rotation.sh
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

vault operator rotate

vault read "sys/rotate/config"
```
<!-- AUTO-GENERATED-CONTENT:END -->
## References

- [Vault Tutorials: Rekeying & Rotating Vault](https://developer.hashicorp.com/vault/tutorials/operations/rekeying-and-rotating)
- [Vault Docs: Seal/unseal](https://developer.hashicorp.com/vault/docs/concepts/seal)


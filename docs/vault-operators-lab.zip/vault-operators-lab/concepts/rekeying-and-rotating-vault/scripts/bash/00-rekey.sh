#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
UNSEAL_KEYS=(
"xGUqOFFPj1WuMTdsiprQTwJKrKY8hjSqzWNmTyS6lG8="
)
RECOVERY_THRESHOLD="3"
RECOVERY_SHARES="5"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

REKEY_INIT="$(vault operator rekey -init -key-shares=${RECOVERY_SHARES} -key-threshold="${RECOVERY_THRESHOLD}" -target="recovery" -format JSON)" ;
NONCE="$(echo "${REKEY_INIT}" | jq -r '.nonce')" ;
REKEY_RESP=""
for key in "${UNSEAL_KEYS[@]}"; do
  REKEY_RESP="$(vault operator rekey -target="recovery" -format="json" -nonce="${NONCE}" "${key}")"
done
echo "${REKEY_RESP}" | tee "rekey.json" | jq -r '.'



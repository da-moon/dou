# Vault SDK

## Overview

Hashicorp's Official Vault SDK is written in Go. This document explains the
general steps needed to use the SDK.

## Usage

- Import SDK library


```go
package main

import (
  /// ...
	api "github.com/hashicorp/vault/api"
)
```

- Create a new API client `Config` object

```go
config := api.DefaultConfig()
```

`DefaultConfig` fucntion tries to populate various fields through environement
variables; e.g `VAULT_TOKEN` environment variable is read and is stored in the
struct. More functions are exposed on this object to programmatically customize
API client configuration

- Create a new Vault API client using the `Config` object

```go
client, _ := api.NewClient(config)
```

- Use `client` object's publicly accessible functions to interact with Vault's
API. As an example, the following function call will list Secret engine mounts :

```go
mounts, _ := client.Sys().ListMounts()
```

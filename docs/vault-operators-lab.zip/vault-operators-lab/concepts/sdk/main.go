package main

import (
	"fmt"
	"os"

	api "github.com/hashicorp/vault/api"
	stacktrace "github.com/palantir/stacktrace"
)

func main() {
	/// Add terratest code pieces + Terraform apply
	/// Set VAULT_ADDR and VAULT_TOKEN environment variables before running this code
	config := api.DefaultConfig()
	client, err := api.NewClient(config)
	if err != nil {
		err = stacktrace.Propagate(err, "initialization error. Could not setup client with default config")
		fmt.Println(err)
		os.Exit(1)
	}
	/// Example on using the client - list mounts
	mounts, err := client.Sys().ListMounts()
	if err != nil {
		err = stacktrace.Propagate(err, "Could not list mounts")
		fmt.Println(err)
		os.Exit(1)
	}
	/// ─── NOTE ───────────────────────────────────────────────────────────────────────
	/// Testing Workflow
	/// after applying changes with Terratest:
	/// 1. you would create a Vault Client ( above code until line 22)
	/// 2. Read the configuration of the mount, whether it is an Auth mount or a Secret engine using the client struct you just created
	/// 3. Confirm that the configuration result you got from Vault matches your terraform input file (Tfvars or go code)
	/// ────────────────────────────────────────────────────────────────────────────────
	/// Example on using the client - enabling a mount
	fmt.Printf("Available Mounts : \n%v\n", mounts)

	/// Example on interaction with KV secret engine
	// client.KVv2("secret/").Delete(context.Background(), "foo/bar")
}

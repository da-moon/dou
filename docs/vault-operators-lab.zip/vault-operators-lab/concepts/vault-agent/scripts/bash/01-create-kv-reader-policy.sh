#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="secret"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault policy write "kv-reader" - <<EOT
path "${SECRET_ENGINE_MOUNT_PATH}/*" {
  capabilities = ["read", "list"]
}
EOT

#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="approle" ;
ROLE_NAME="kv-reader" ;
POLICIES="kv-reader" ;
TTL="2h"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault write "/auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}" \
  token_policies="${POLICIES}" \
  token_ttl="${TTL}";



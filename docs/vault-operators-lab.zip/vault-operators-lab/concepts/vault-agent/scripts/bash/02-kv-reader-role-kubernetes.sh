#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="kubernetes" ;
ROLE_NAME="kv-reader" ;
POLICIES="kv-reader" ;
BOUND_SERVICE_ACCOUNT_NAMES="vault-client-auth" ;
BOUND_SERVICE_ACCOUNT_NAMESPACES="default" ;
TTL="2h"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault write \
  "auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}" \
  token_policies="${POLICIES}" \
  bound_service_account_names="${BOUND_SERVICE_ACCOUNT_NAMES}" \
  bound_service_account_namespaces="${BOUND_SERVICE_ACCOUNT_NAMESPACES}" \
  ttl="${TTL}" ;


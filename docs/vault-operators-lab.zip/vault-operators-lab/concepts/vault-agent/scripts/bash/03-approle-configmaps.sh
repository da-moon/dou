#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="approle" ;
ROLE_NAME="kv-reader" ;
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
ROLE_ID="$(vault read \
  -field=role_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/role-id)"
SECRET_ID="$(vault write -f \
  -field=secret_id \
  auth/${AUTH_MOUNT_PATH}/role/${ROLE_NAME}/secret-id)"
kubectl create secret generic approle --from-literal=role_id=${ROLE_ID} --from-literal=secret_id=${SECRET_ID}
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="secret"
KV_ENTRY_PATH="credentials"
USERNAME="foo"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
vault kv put \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    "${KV_ENTRY_PATH}" username="${USERNAME}" password="$(base64 </dev/urandom | head -c 30)"
# azure-secret-engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Configuration](#configuration)
  - [Mount the secret engine](#mount-the-secret-engine)
  - [Configure the secret engine (Service Principle)](#configure-the-secret-engine-service-principle)
  - [Create a Vault role](#create-a-vault-role)
  - [Set Password Policy](#set-password-policy)
  - [Rotate Root](#rotate-root)
- [Consumption](#consumption)
  - [Generate New Service Principle](#generate-new-service-principle)
  - [List Leases](#list-leases)
  - [Revoke Leases](#revoke-leases)
- [Misc](#misc)
  - [Prerequisites](#prerequisites)
    - [Create Vault Server VM](#create-vault-server-vm)
    - [Create a New Azure AD App](#create-a-new-azure-ad-app)
    - [Grant the required Microsoft Graph API permissions](#grant-the-required-microsoft-graph-api-permissions)
    - [Create a Service principle for usage with the secret engine](#create-a-service-principle-for-usage-with-the-secret-engine)
  - [Cleanup](#cleanup)
    - [Delete VM](#delete-vm)
    - [Clean up Orphan Disks](#clean-up-orphan-disks)
    - [Remove Networking related resources](#remove-networking-related-resources)
    - [Remove Role assignment and Role definitions](#remove-role-assignment-and-role-definitions)
    - [Remove Service Principle](#remove-service-principle)
    - [Remove Azure AD Application](#remove-azure-ad-application)
    - [Check resources in your resource group](#check-resources-in-your-resource-group)
- [References](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

Azure secret engine can be used to generate short-lived Service principals on
demand. The generated service principals can be customized with applied RBAC
rules and the secret engine can also add those service principles to different
Azure AD groups

In this guide, the assumption is that :

- You have Azure CLI installed and already authenticated
- A Vault server is running in an Azure VM
- You have already Created an Azure AD app, Granted the required **Microsoft Graph API permissions** and assigned `Owner` RBAC role

| Permission Name                |  Type        |
| -----------------------------  |  ----------- |
| Application.Read.All           |  Application |
| Application.ReadWrite.All      |  Application |
| Application.ReadWrite.OwnedBy  |  Application |
| Directory.Read.All             |  Application |
| Directory.ReadWrite.All        |  Application |
| Group.Read.All                 |  Application |
| Group.ReadWrite.All            |  Application |
| GroupMember.Read.All           |  Application |
| GroupMember.ReadWrite.All      |  Application |
| Application.Read.All           |  Delegated   |
| Application.ReadWrite.All      |  Delegated   |
| Directory.AccessAsUser.All     |  Delegated   |
| Directory.Read.All             |  Delegated   |
| Directory.ReadWrite.All        |  Delegated   |
| Group.Read.All                 |  Delegated   |
| Group.ReadWrite.All            |  Delegated   |
| GroupMember.Read.All           |  Delegated   |
| GroupMember.ReadWrite.All      |  Delegated   |

Set the following environment variables in your shell before getting started:

- `CLIENT_ID`: Client ID of the Service Principle assigned to Vault's Azure Auth
  method (Only when using custom user-assigned SP with the Auth method)
- `CLIENT_SECRET`: Client Secret of the Service Principle assigned to Vault's
  Azure Auth method (Only when using custom user-assigned SP with the Auth method)
- `AZURE_RESOURCE_GROUP`: Azure Resource Group in which The VM running Vault
  server is deployed.
- `AZURE_TENANT_ID` : Azure Tenant ID

## Configuration

### Mount the secret engine

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-enable.sh -->
```bash
# bash scripts/bash/cli/00-enable.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  azure
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Configure the secret engine (Service Principle)

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-configure-the-engine-without-msi.sh&src=scripts/bash/cli/01-configure-the-engine-without-msi.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-configure-the-engine-without-msi.sh -->
```bash
# bash scripts/bash/cli/01-configure-the-engine-without-msi.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROOT_PASSWORD_TTL="48d"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
if [ -z "${AZURE_TENANT_ID+x}" ] || [ -z "${AZURE_TENANT_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_TENANT_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${CLIENT_ID+x}" ] || [ -z "${CLIENT_ID}" ]; then
  echo >&2 "[ ERROR ] 'CLIENT_ID' environment variable is required"
  exit 1
fi
if [ -z "${CLIENT_SECRET+x}" ] || [ -z "${CLIENT_SECRET}" ]; then
  echo >&2 "[ ERROR ] 'CLIENT_SECRET' environment variable is required"
  exit 1
fi
#--------------------------------------------------------------------#
PASSWORD_POLICY_NAME="example-${SECRET_ENGINE_MOUNT_PATH}-password-policy"
vault write "${SECRET_ENGINE_MOUNT_PATH}/config" \
  tenant_id="${AZURE_TENANT_ID}" \
  subscription_id="${AZURE_SUBSCRIPTION_ID}" \
  root_password_ttl="${ROOT_PASSWORD_TTL}" \
  client_id="${CLIENT_ID}" \
  client_secret="${CLIENT_SECRET}" \
  use_microsoft_graph_api=true

# password_policy="${PASSWORD_POLICY_NAME}" \
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Create a Vault role

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-create-a-role.sh&src=scripts/bash/cli/02-create-a-role.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-create-a-role.sh -->
```bash
# bash scripts/bash/cli/02-create-a-role.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
TTL="2m"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
#--------------------------------------------------------------------#
vault write "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" ttl="${TTL}" azure_roles=- <<EOF
    [
      {
        "role_name": "Reader",
        "scope": "/subscriptions/$AZURE_SUBSCRIPTION_ID/resourceGroups/${AZURE_RESOURCE_GROUP}"
      }
    ]
EOF

# <hashicorp role> one -> many (azure_role)
# when generate a spn agains a hashicorp role, you get an azure spn with
# what that Hashicorp role was cofigured
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Set Password Policy

> When tested against Vault 1.12 , it looks like assigning Password policy is
> not customizing generated service principle passwor; e.g the Service
> Principle password is always 41 charcters long no matter what is specified in
> the password policy

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/06-set-password-policy.sh&src=scripts/bash/cli/06-set-password-policy.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/06-set-password-policy.sh -->
```bash
# bash scripts/bash/cli/06-set-password-policy.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
PASSWORD_POLICY_NAME="example-${SECRET_ENGINE_MOUNT_PATH}-password-policy"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

vault write "sys/policies/password/${PASSWORD_POLICY_NAME}" policy=- <<EOF
length=60
rule "charset" {
  charset = "abcdefghijklmnopqrstuvwxyz"
  min-chars = 1
}
rule "charset" {
  charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  min-chars = 1
}
rule "charset" {
  charset = "0123456789"
  min-chars = 1
}
rule "charset" {
  charset = "!@#$%^&*"
  min-chars = 1
}
EOF
vault write "${SECRET_ENGINE_MOUNT_PATH}/config" \
  password_policy="${PASSWORD_POLICY_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Rotate Root

generates a new client secret for the root account defined in the config. The
value generated will only be known by Vault.

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/07-rotate-root.sh&src=scripts/bash/cli/07-rotate-root.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/07-rotate-root.sh -->
```bash
# bash scripts/bash/cli/07-rotate-root.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault write -f "${SECRET_ENGINE_MOUNT_PATH}/rotate-root"
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Consumption

### Generate New Service Principle

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-request-azure-credentials.sh&src=scripts/bash/cli/03-request-azure-credentials.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-request-azure-credentials.sh -->
```bash
# bash scripts/bash/cli/03-request-azure-credentials.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault read "${SECRET_ENGINE_MOUNT_PATH}/creds/${ROLE_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List Leases

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/04-list-leases.sh&src=scripts/bash/cli/04-list-leases.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/04-list-leases.sh -->
```bash
# bash scripts/bash/cli/04-list-leases.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault list "sys/leases/lookup/${SECRET_ENGINE_MOUNT_PATH}/creds/${ROLE_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Revoke Leases

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/05-revoke-leases.sh&src=scripts/bash/cli/05-revoke-leases.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/05-revoke-leases.sh -->
```bash
# bash scripts/bash/cli/05-revoke-leases.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault lease revoke -prefix "${SECRET_ENGINE_MOUNT_PATH}/creds/${ROLE_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Misc

### Prerequisites

#### Create Vault Server VM

Creates a VM with System Assigned managed identity and public IP address.
Vault server in `dev` mode runs on this VM.

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/init/00-create-vault-server-vm-with-system-assigned-managed-identity.sh&src=scripts/bash/misc/init/00-create-vault-server-vm-with-system-assigned-managed-identity.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/init/00-create-vault-server-vm-with-system-assigned-managed-identity.sh -->
```bash
# bash scripts/bash/misc/init/00-create-vault-server-vm-with-system-assigned-managed-identity.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
LOCATION="canadaeast"
ADMIN_USERNAME="azureuser"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
IMAGE_NAME="UbuntuLTS"
#--------------------------------------------------------------------#
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
#--------------------------------------------------------------------#
IP_ADDR="$(az network public-ip create \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}-public-ip" \
  --tags "id=vault-training" \
  --version "IPv4" \
  --location "${LOCATION}" \
  --sku "Standard" \
  --query 'publicIp.ipAddress' \
  --output tsv 2>/dev/null)"
#--------------------------------------------------------------------#
az vm create \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --scope "/subscriptions/${AZURE_SUBSCRIPTION_ID}/resourceGroups/${AZURE_RESOURCE_GROUP}" \
  --location "${LOCATION}" \
  --name "${VM_NAME}" \
  --tags "id=vault-training" \
  --image "${IMAGE_NAME}" \
  --size "Standard_B2s" \
  --public-ip-address "${VM_NAME}-public-ip" \
  --admin-username "${ADMIN_USERNAME}" \
  --assign-identity \
  --role "Reader" \
  --ssh-key-values "${HOME}/.ssh/id_rsa.pub" 2>/dev/null
#--------------------------------------------------------------------#
NIC_ID="$(az vm show \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}" \
  --query 'networkProfile.networkInterfaces[0].id' \
  --output tsv)"
NSG_ID="$(az network nic show \
  --ids "${NIC_ID}" \
  --query 'networkSecurityGroup.id' \
  --output tsv)"
if [[ -n "${NSG_ID}" ]]; then
  NSG_NAME="$(basename "${NSG_ID}")"
  az network nsg rule create \
    --resource-group "${AZURE_RESOURCE_GROUP}" \
    --name "${VM_NAME}-open-ports" \
    --nsg-name "${NSG_NAME}" \
    --priority 100 \
    --destination-port-ranges 22 8200 \
    --access Allow \
    --protocol Tcp \
    -o none
fi
#--------------------------------------------------------------------#
az vm run-command invoke \
  --resource-group "${AZURE_RESOURCE_GROUP}" \
  --name "${VM_NAME}" \
  --command-id "RunShellScript" \
  --scripts '
apt-get update && apt-get install -yq sudo jq wget gpg lsb-release;
wget -O- https://apt.releases.hashicorp.com/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg > /dev/null;
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list > /dev/null ;
sudo apt-get update && sudo apt-get install -yq vault ;
sed -i -e "/Condition/d" -e "/Limit/d" -e "/Capabil/d" -e "/yes/d" -e "/Protect/d" -e "/Secure/d" -e "/=vault/d" -e "s/server.*/server -tls-skip-verify -dev -dev-transactional -dev-ha -log-level=debug -dev-listen-address="0.0.0.0:8200" -dev-root-token-id=root/g" /usr/lib/systemd/system/vault.service;
systemctl daemon-reload ;
systemctl enable --now vault ;
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash ;
'
echo "--------------------------------------------------------------------"
echo >&2 "[ NOTE ] Add Vault Address to your shell's environment variables:"
echo >&2 "export VAULT_ADDR="http://${IP_ADDR}:8200""
echo "--------------------------------------------------------------------"
echo >&2 "[ NOTE ] SSH Command"
echo >&2 "ssh -m "hmac-sha2-512" -o "StrictHostKeyChecking=no" -o "CheckHostIP=no" -o "UserKnownHostsFile=/dev/null" ${ADMIN_USERNAME}@${IP_ADDR}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Create a New Azure AD App

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/init/01-create-a-new-azure-ad-application.sh&src=scripts/bash/misc/init/01-create-a-new-azure-ad-application.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/init/01-create-a-new-azure-ad-application.sh -->
```bash
# bash scripts/bash/misc/init/01-create-a-new-azure-ad-application.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
if [[ -z "${APP_ID}" ]]; then
  APP_ID="$(az ad app create \
    --display-name "${APP_NAME}" \
    --query 'appId' \
    --output tsv)"
fi
echo >&2 "[ NOTE ] APP ID : ${APP_ID}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Grant the required Microsoft Graph API permissions

> Azure AD Admin has to grant admin consent after requesting Graph API permissions as
> the following snippet assumes that the user running it cannot grant admin consent

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/init/02-grant-graph-api-permissions.sh&src=scripts/bash/misc/init/02-grant-graph-api-permissions.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/init/02-grant-graph-api-permissions.sh -->
```bash
# bash scripts/bash/misc/init/02-grant-graph-api-permissions.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
MICROSOF_GRAPH_API="00000003-0000-0000-c000-000000000000"
# SCOPE <-> Delegated
# ROLE <-> Application
az ad app permission add \
  --id ${APP_ID?} \
  --api "${MICROSOF_GRAPH_API}" \
  --api-permissions \
  '5f8c59db-677d-491f-a6b8-5f174b11ec1d=Scope' \
  '4e46008b-f24c-477d-8fff-7bb4ec7aafe0=Scope' \
  '06da0dbc-49e2-44d2-8312-53f166ab848a=Scope' \
  'c5366453-9fb0-48a5-a156-24f0c49a4b84=Scope' \
  '0e263e50-5827-48a4-b97c-d940288653c7=Scope' \
  'c79f8feb-a9db-4090-85f9-90d820caa0eb=Scope' \
  'bdfbf15f-ee85-4955-8675-146e8e5296b5=Scope' \
  'bc024368-1153-4739-b217-4326f2e966d0=Scope' \
  'f81125ac-d3b7-4573-a3b2-7099cc39df9e=Scope' \
  '62a82d76-70ea-41e2-9197-370581804d09=Role' \
  '5b567255-7703-4780-807c-7be8301ae99b=Role' \
  '18a4783c-866b-4cc7-a460-3d5e5662c884=Role' \
  '1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9=Role' \
  '7ab1d382-f21e-4acd-a863-ba3e13f7da61=Role' \
  '19dbc75e-c2e2-444c-a770-ec69d8559fc7=Role' \
  '9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30=Role' \
  '98830695-27a2-44f7-8c18-0c3ebc9698f6=Role' \
  'dbaae8cf-10b5-4b86-a4a1-f871c94c6695=Role'
# NOTE: this command needs a fairly high privilege level
# --scope "Group.Read.All Group.ReadWrite.All Directory.Read.All Directory.ReadWrite.All Directory.AccessAsUser.All Application.Read.All Application.ReadWrite.All GroupMember.Read.All GroupMember.ReadWrite.All"
# az ad app permission admin-consent --id ${APP_ID?};
```
<!-- AUTO-GENERATED-CONTENT:END -->

#### Create a Service principle for usage with the secret engine

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/init/03-create-service-principal.sh&src=scripts/bash/misc/init/03-create-service-principal.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/init/03-create-service-principal.sh -->
```bash
# bash scripts/bash/misc/init/03-create-service-principal.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
SERVICE_PRINCIPAL="$(az ad sp create-for-rbac \
  --name "${APP_NAME}" \
  --role "Owner" \
  --scopes "/subscriptions/${AZURE_SUBSCRIPTION_ID}")"

echo "${SERVICE_PRINCIPAL}" |
  jq \
    --arg subscription_id "${AZURE_SUBSCRIPTION_ID}" \
    '{
    "client_id": .appId, 
    "client_secret": .password, 
    "tenant_id": .tenant, 
    "subscription_id": $subscription_id
  }' | tee "service-principal.json" | jq -r '.'
CLIENT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".appId")
CLIENT_SECRET=$(echo "$SERVICE_PRINCIPAL" | jq -r ".password")
TENANT_ID=$(echo "$SERVICE_PRINCIPAL" | jq -r ".tenant")
echo "--------------------------------------------------------------------"
echo >&2 "[ NOTE ] Set The following Azure Auth method environment variables in your shell:"
# echo >&2 "export TENANT_ID="${TENANT_ID}""
echo >&2 "export CLIENT_ID="${CLIENT_ID}""
echo >&2 "export CLIENT_SECRET="${CLIENT_SECRET}""
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Cleanup

You can use the following snippet to run all cleanup operations instead of
running them step by step

- Bash Shell

```bash
find scripts/bash/misc/cleanup -type f | sort | xargs -r -I {} bash {}
find scripts/ -type f -name '*.json' -delete
```

#### Delete VM

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/00-vm.sh&src=scripts/bash/misc/cleanup/00-vm.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/00-vm.sh -->
```bash
# bash scripts/bash/misc/cleanup/00-vm.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
VM="$(az vm list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${VM_NAME}')].name" --output tsv)"
if [[ -n "${VM}" ]]; then
  az vm delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM}" --yes
fi
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Clean up Orphan Disks

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/01-orphan-disks.sh&src=scripts/bash/misc/cleanup/01-orphan-disks.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/01-orphan-disks.sh -->
```bash
# bash scripts/bash/misc/cleanup/01-orphan-disks.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
DISK="$(az vm show --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM_NAME}" --query 'storageProfile.osDisk.name' --output tsv 2>/dev/null)"
if [[ -n "${DISK}" ]]; then
  az disk delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${DISK}" --yes
fi
ORPHAN_DISKS=($(az resource list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?type=='Microsoft.Compute/disks'] | [?managedBy==\`null\`].[id]" --output tsv))
for id in ${ORPHAN_DISKS[@]}; do
  az disk delete --ids "${id}" --yes
done
ORPHAN_DISKS=($(az resource list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?type=='Microsoft.Compute/disks'] | [?contains(name,'${VM_NAME}')].[id]" --output tsv))
for id in ${ORPHAN_DISKS[@]}; do
  az disk delete --ids "${id}" --yes
done
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Remove Networking related resources

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/02-vm-network.sh&src=scripts/bash/misc/cleanup/02-vm-network.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/02-vm-network.sh -->
```bash
# bash scripts/bash/misc/cleanup/02-vm-network.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
NETWORK_INTERFACE_NAME="$(az network nic list --resource-group "${AZURE_RESOURCE_GROUP}" --query '[].name' --output tsv | grep "${VM_NAME}")"
if [[ -n "${NETWORK_INTERFACE_NAME}" ]]; then
  az network nic delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${NETWORK_INTERFACE_NAME}"
fi
VNET_NAME="$(az network vnet list --resource-group "${AZURE_RESOURCE_GROUP}" --query '[].name' --output tsv | grep "${VM_NAME}")"
if [[ -n "${VNET_NAME}" ]]; then
  az network vnet delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VNET_NAME}"
fi
NSG_NAME="$(az network nsg list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${VM_NAME}')].name" --output tsv)"
if [[ -n "${NSG_NAME}" ]]; then
  az network nsg delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${NSG_NAME}"
fi
PUBLIC_IP="$(az network public-ip list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${IMAGE_NAME}')].name" --output tsv)"
if [[ -n "${PUBLIC_IP}" ]]; then
  az network public-ip delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${PUBLIC_IP}"
fi
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Remove Role assignment and Role definitions

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/03-roles.sh&src=scripts/bash/misc/cleanup/03-roles.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/03-roles.sh -->
```bash
# bash scripts/bash/misc/cleanup/03-roles.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
ROLE_NAME="hashicorp-vault-auth"
# ROLE_NAME="Reader"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
ROLE_ASSIGNMENTS=($(az role assignment list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?roleDefinitionName=='${ROLE_NAME}'].id" --output tsv))
for ROLE_ASSIGNMENT in "${ROLE_ASSIGNMENTS[@]}"; do
  az role assignment delete --id "${ROLE_ASSIGNMENT}"
done
ROLE="$(az role definition list --resource-group "${AZURE_RESOURCE_GROUP}" --name "${ROLE_NAME}" --query '[].name' --output tsv)"

if [[ -n "${ROLE}" ]]; then
  az role definition delete --scope "/subscriptions/${AZURE_SUBSCRIPTION_ID}" --name "${ROLE}"
fi
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Remove Service Principle

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/04-service-principle.sh&src=scripts/bash/misc/cleanup/04-service-principle.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/04-service-principle.sh -->
```bash
# bash scripts/bash/misc/cleanup/04-service-principle.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SERVICE_PRINCIPAL_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
SERVICE_PRINCIPAL_IDS=($(az ad sp list --display-name "${SERVICE_PRINCIPAL_NAME}" --query '[].id' --output tsv))
for SERVICE_PRINCIPAL_ID in "${SERVICE_PRINCIPAL_IDS[@]}"; do
  az ad sp delete --id "${SERVICE_PRINCIPAL_ID}"
done
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Remove Azure AD Application

- Bash Shell 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/misc/cleanup/05-azure-ad-app.sh&src=scripts/bash/misc/cleanup/05-azure-ad-app.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/misc/cleanup/05-azure-ad-app.sh -->
```bash
# bash scripts/bash/misc/cleanup/05-azure-ad-app.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
if [[ -n "${APP_ID}" ]]; then
  az ad app delete --id "${APP_ID}"
fi
```
<!-- AUTO-GENERATED-CONTENT:END -->
#### Check resources in your resource group

- Bash Shell 

```bash
az resource list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[].type"
```

## References

- [Create a client application in the Azure AD](https://learn.microsoft.com/en-us/azure/healthcare-apis/register-application-cli-rest#create-a-client-application)
- [Enable system-assigned managed identity during creation of an Azure VM](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/qs-configure-cli-windows-vm#enable-system-assigned-managed-identity-during-creation-of-an-azure-vm)
- [Create an Azure VM with a static public IP address](https://learn.microsoft.com/en-us/azure/virtual-network/ip-services/virtual-network-deploy-static-pip-arm-cli)
- [Associate a public IP address to an existing Azure VM](https://learn.microsoft.com/en-us/azure/virtual-network/ip-services/associate-public-ip-address-vm)
- [Run scripts in your Azure Linux VM](https://learn.microsoft.com/en-us/azure/virtual-machines/linux/run-command#azure-cli)
- [Vault Azure Secrets plugin Terraform Acceptance Tests](https://github.com/hashicorp/vault-plugin-secrets-azure/blob/main/tests/acceptance/terraform/main.tf)
- [Hashicorp Support - Azure Permissions for Integrations with Vault](https://support.hashicorp.com/hc/en-us/articles/8114483404947-Azure-Permissions-for-Integrations-with-Vault)
- [Mark Heath - Creating a Service Principal with the Azure CLI](https://markheath.net/post/create-service-principal-azure-cli)
- [Vault Docs - Azure Secret Engine](https://developer.hashicorp.com/vault/docs/secrets/azure)
- [Vault API Docs - Azure Secret Engine](https://developer.hashicorp.com/vault/api-docs/secret/azure)
- [Vault Tutorials - User Configurable Password Generation for Secret Engines](https://developer.hashicorp.com/vault/tutorials/policies/password-policies)
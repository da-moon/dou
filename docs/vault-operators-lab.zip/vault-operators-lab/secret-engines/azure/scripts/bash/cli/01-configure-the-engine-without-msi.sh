#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROOT_PASSWORD_TTL="48d"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
if [ -z "${AZURE_TENANT_ID+x}" ] || [ -z "${AZURE_TENANT_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_TENANT_ID' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
if [ -z "${CLIENT_ID+x}" ] || [ -z "${CLIENT_ID}" ]; then
  echo >&2 "[ ERROR ] 'CLIENT_ID' environment variable is required"
  exit 1
fi
if [ -z "${CLIENT_SECRET+x}" ] || [ -z "${CLIENT_SECRET}" ]; then
  echo >&2 "[ ERROR ] 'CLIENT_SECRET' environment variable is required"
  exit 1
fi
#--------------------------------------------------------------------#
PASSWORD_POLICY_NAME="example-${SECRET_ENGINE_MOUNT_PATH}-password-policy"
vault write "${SECRET_ENGINE_MOUNT_PATH}/config" \
  tenant_id="${AZURE_TENANT_ID}" \
  subscription_id="${AZURE_SUBSCRIPTION_ID}" \
  root_password_ttl="${ROOT_PASSWORD_TTL}" \
  client_id="${CLIENT_ID}" \
  client_secret="${CLIENT_SECRET}" \
  use_microsoft_graph_api=true

# password_policy="${PASSWORD_POLICY_NAME}" \

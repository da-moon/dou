#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
TTL="2m"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
if [ -z "${AZURE_RESOURCE_GROUP+x}" ] || [ -z "${AZURE_RESOURCE_GROUP}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_RESOURCE_GROUP' environment variable is required"
  exit 1
fi
if [ -z "${AZURE_SUBSCRIPTION_ID+x}" ] || [ -z "${AZURE_SUBSCRIPTION_ID}" ]; then
  echo >&2 "[ ERROR ] 'AZURE_SUBSCRIPTION_ID' environment variable is required"
  exit 1
fi
#--------------------------------------------------------------------#
vault write "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" ttl="${TTL}" azure_roles=- <<EOF
    [
      {
        "role_name": "Reader",
        "scope": "/subscriptions/$AZURE_SUBSCRIPTION_ID/resourceGroups/${AZURE_RESOURCE_GROUP}"
      }
    ]
EOF

# <hashicorp role> one -> many (azure_role)
# when generate a spn agains a hashicorp role, you get an azure spn with
# what that Hashicorp role was cofigured

#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"
#--------------------------------------------------------------------#
vault lease revoke -prefix "${SECRET_ENGINE_MOUNT_PATH}/creds/${ROLE_NAME}"

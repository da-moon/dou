#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SECRET_ENGINE_MOUNT_PATH="azure"
PASSWORD_POLICY_NAME="example-${SECRET_ENGINE_MOUNT_PATH}-password-policy"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
export VAULT_TOKEN="${VAULT_TOKEN:-root}"
export VAULT_ADDR="${VAULT_ADDR:-http://127.0.0.1:8200}"

vault write "sys/policies/password/${PASSWORD_POLICY_NAME}" policy=- <<EOF
length=60
rule "charset" {
  charset = "abcdefghijklmnopqrstuvwxyz"
  min-chars = 1
}
rule "charset" {
  charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  min-chars = 1
}
rule "charset" {
  charset = "0123456789"
  min-chars = 1
}
rule "charset" {
  charset = "!@#$%^&*"
  min-chars = 1
}
EOF
vault write "${SECRET_ENGINE_MOUNT_PATH}/config" \
  password_policy="${PASSWORD_POLICY_NAME}"

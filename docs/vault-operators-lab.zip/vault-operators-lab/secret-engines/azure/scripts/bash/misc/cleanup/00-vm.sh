#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
VM="$(az vm list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${VM_NAME}')].name" --output tsv)"
if [[ -n "${VM}" ]]; then
  az vm delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VM}" --yes
fi

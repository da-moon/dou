#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
VM_NAME="hashicorp-vault-dev-azure-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
NETWORK_INTERFACE_NAME="$(az network nic list --resource-group "${AZURE_RESOURCE_GROUP}" --query '[].name' --output tsv | grep "${VM_NAME}")"
if [[ -n "${NETWORK_INTERFACE_NAME}" ]]; then
  az network nic delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${NETWORK_INTERFACE_NAME}"
fi
VNET_NAME="$(az network vnet list --resource-group "${AZURE_RESOURCE_GROUP}" --query '[].name' --output tsv | grep "${VM_NAME}")"
if [[ -n "${VNET_NAME}" ]]; then
  az network vnet delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${VNET_NAME}"
fi
NSG_NAME="$(az network nsg list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${VM_NAME}')].name" --output tsv)"
if [[ -n "${NSG_NAME}" ]]; then
  az network nsg delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${NSG_NAME}"
fi
PUBLIC_IP="$(az network public-ip list --resource-group "${AZURE_RESOURCE_GROUP}" --query "[?contains(name,'${IMAGE_NAME}')].name" --output tsv)"
if [[ -n "${PUBLIC_IP}" ]]; then
  az network public-ip delete --resource-group "${AZURE_RESOURCE_GROUP}" --name "${PUBLIC_IP}"
fi

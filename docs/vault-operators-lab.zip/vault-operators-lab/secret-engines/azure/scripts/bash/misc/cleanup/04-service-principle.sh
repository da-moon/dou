#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
SERVICE_PRINCIPAL_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
SERVICE_PRINCIPAL_IDS=($(az ad sp list --display-name "${SERVICE_PRINCIPAL_NAME}" --query '[].id' --output tsv))
for SERVICE_PRINCIPAL_ID in "${SERVICE_PRINCIPAL_IDS[@]}"; do
  az ad sp delete --id "${SERVICE_PRINCIPAL_ID}"
done

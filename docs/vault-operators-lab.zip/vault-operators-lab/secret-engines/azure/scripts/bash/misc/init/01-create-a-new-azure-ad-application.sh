#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
if [[ -z "${APP_ID}" ]]; then
  APP_ID="$(az ad app create \
    --display-name "${APP_NAME}" \
    --query 'appId' \
    --output tsv)"
fi
echo >&2 "[ NOTE ] APP ID : ${APP_ID}"

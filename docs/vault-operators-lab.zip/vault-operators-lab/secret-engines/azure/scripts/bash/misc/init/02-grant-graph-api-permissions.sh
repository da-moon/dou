#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
APP_NAME="hashicorp-vault-secret-engine"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
APP_ID="$(az ad app list --display-name "${APP_NAME}" --query '[].appId' --output tsv)"
MICROSOF_GRAPH_API="00000003-0000-0000-c000-000000000000"
# SCOPE <-> Delegated
# ROLE <-> Application
az ad app permission add \
  --id ${APP_ID?} \
  --api "${MICROSOF_GRAPH_API}" \
  --api-permissions \
  '5f8c59db-677d-491f-a6b8-5f174b11ec1d=Scope' \
  '4e46008b-f24c-477d-8fff-7bb4ec7aafe0=Scope' \
  '06da0dbc-49e2-44d2-8312-53f166ab848a=Scope' \
  'c5366453-9fb0-48a5-a156-24f0c49a4b84=Scope' \
  '0e263e50-5827-48a4-b97c-d940288653c7=Scope' \
  'c79f8feb-a9db-4090-85f9-90d820caa0eb=Scope' \
  'bdfbf15f-ee85-4955-8675-146e8e5296b5=Scope' \
  'bc024368-1153-4739-b217-4326f2e966d0=Scope' \
  'f81125ac-d3b7-4573-a3b2-7099cc39df9e=Scope' \
  '62a82d76-70ea-41e2-9197-370581804d09=Role' \
  '5b567255-7703-4780-807c-7be8301ae99b=Role' \
  '18a4783c-866b-4cc7-a460-3d5e5662c884=Role' \
  '1bfefb4e-e0b5-418b-a88f-73c46d2cc8e9=Role' \
  '7ab1d382-f21e-4acd-a863-ba3e13f7da61=Role' \
  '19dbc75e-c2e2-444c-a770-ec69d8559fc7=Role' \
  '9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30=Role' \
  '98830695-27a2-44f7-8c18-0c3ebc9698f6=Role' \
  'dbaae8cf-10b5-4b86-a4a1-f871c94c6695=Role'
# NOTE: this command needs a fairly high privilege level
# --scope "Group.Read.All Group.ReadWrite.All Directory.Read.All Directory.ReadWrite.All Directory.AccessAsUser.All Application.Read.All Application.ReadWrite.All GroupMember.Read.All GroupMember.ReadWrite.All"
# az ad app permission admin-consent --id ${APP_ID?};

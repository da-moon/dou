# cubbyhole secret engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [overview](#overview)
- [cubbyhole response wrapping](#cubbyhole-response-wrapping)
  - [cubbyhole response wrapping - overview:](#cubbyhole-response-wrapping---overview)
  - [Benefits of using the response wrapping](#benefits-of-using-the-response-wrapping)
  - [sharing response-wrapped tokens](#sharing-response-wrapped-tokens)
  - [Sharing a secret](#sharing-a-secret)
- [references](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## overview

- enabled by default and cannot be disabled, moved, or enabled multiple times.
- is used to store arbitrary secrets within the configured physical storage for
Vault namespaced to a token
  - paths are scoped per token
  - no token can access another token's cubbyhole.
  - when the token expires, its cubbyhole is destroyed
- there is no concepts of a TTL or refresh interval ( unlike `kv`).
- writing to a key in the cubbyhole secrets engine will completely replace the
old value
  - `vault write cubbyhole/<key-path> <key>=<value>`
- `vault read cubbyhole/<key-path>` : read data

## cubbyhole response wrapping

### cubbyhole response wrapping - overview:

- When response wrapping is requested, Vault creates a temporary single-use
token (__wrapping token__) 
- the response is inserted into wapping token's cubbyhole with a short TTL
- Only the expecting client who has the wrapping token can unwrap this secret
- Any Vault response can be distributed using the response wrapping
- Unwraping the token is a Vault API call that does not need any Bearer token;
i.e it is send to an endpoint that accepts anonymous payloads

### Benefits of using the response wrapping

- It provides cover by ensuring that the value being transmitted across the
wire is not the actual secret. It's a reference to the secret.
- It provides malfeasance detection by ensuring that only a single party can
ever unwrap the token and see what's inside
- It limits the lifetime of the secret exposure
- The TTL of the response-wrapping token is separate from the wrapped secret's
lease TTL
- A potential use case is sharing secrets over email or any internal messaging
tool a company uses. Instead of sharing Raw secret, you can safely share the
response wrapped value. 

### sharing response-wrapped tokens

- initial step : admin creates and wrap a token with the appropriate policy

```bash
vault token create -policy=<policy> -wrap-ttl=120
```

- client receives the token and uses it to unwrap the secret 

```bash
VAULT_TOKEN="<wrapped-token>" vault unwrap
```


- login with the unwrapped token and try to access values.

### Sharing a secret

- Put a secret value in KV engine 

```bash
vault kv put secret/foo baz=bar
```

- Ask Vault to return the secret in Response Wrapped form

```bash
vault kv get -wrap-ttl=120 secret/foo
```

- Share the response-wrapped value with target audience and have them unwrap it
  with `vault unwrap <wrapped-token>`

## references

- https://www.vaultproject.io/docs/secrets/cubbyhole
- https://www.vaultproject.io/api/secret/cubbyhole
- https://learn.hashicorp.com/tutorials/vault/cubbyhole-response-wrapping
- https://learn.hashicorp.com/tutorials/vault/tokens?in=vault/tokens
- https://www.vaultproject.io/docs/concepts/response-wrapping
- https://www.hashicorp.com/blog/cubbyhole-authentication-principles
# Identity Secret Engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [overview](#overview)
- [entity](#entity)
- [groups](#groups)
  - [internal group](#internal-group)
  - [external group](#external-group)
- [available Templating Parameters](#available-templating-parameters)
- [references](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## overview

- path : `/identity`
- enabled by default
- `identity` engine allows operators to manage the `entities` in Vault
  - Vault clients can be mapped as `entities`
  - a client (`entity`) corresponding accounts with authentication providers
  (`auth` backend ) can be mapped as `aliases`.
  - each `entity` is made up of zero or more `aliases`.
- capabilities granted to tokens via the entities are an __addition__ to the
existing capabilities of the token and they are __dynamically__ computed at
request time.
- Entities in Vault do not automatically pull identity information from
anywhere.
  - It needs to be __explicitly__ managed by operators
  - Vault serves as a __cache__ of identities and not as a __source__ of
  identities.
- `token` authentication backend will not have an associated identity
information.
- `implicit entities` : if an entity for a user is not created by the operator,
upon a successful user login , Vault will create a new entity and assign an
alias against the login that was successful
- `identity auditing` : in case the token used to make API calls have an
associated entity identifier, it will be audit logged as well
- [`identity tokens`][identity-tokens] : Identity information can be exported
as JWT token for usage in external applications.
- limits
  - Number of key-value pairs in metadata	: `64`
  - Metadata key size	: `128` bytes
  - Metadata value size	: `512` bytes
  
## entity

- `vault read identity/entity/id/<entity_id>` : get entity details
- `vault write identity/entity name="<name>" policies="<policy>" [metadata=<key>=<value>]` :
  - Create an entity
  - `entity_id` : take note of returned `id` field
- `vault write identity/entity-alias name="<name>" canonical_id=<entity_id> mount_accessor=<mount_accessor>` :
  - creates an alias
  - repeat for as many auth backends as needed
  - `entity_id` is unique, alias `name` is not.
  - `mount_accessor` : take note of Accessor field for the target mount `vault auth list -detailed` 

## groups

- a `group` can have `subgroup` and at the lowest level, consists of `entities`
and policies set on the group is granted to all members of the group in a
`hierarchical` fashion.

### internal group

- By default, the groups created in identity store are called the internal groups.
- membership management of these groups should be carried out manually

- `vault write identity/group name="<name>" policies="<policy>" member_entity_ids=<entity_id> [metadata=<key>=<value>]`:
  - Create an internal group
  - When you create an internal group, you specify the __group members__ rather than __group alias__
  - `member_entity_ids` or `member_group_ids` are used to specify children.
- no need for group alias

### external group

- `external group` : is a group in which entity membership in it is managed
semi-automatically
- they serves as a mapping to a group that is outside of the identity store
- External groups can have one (and only one) alias which maps to a notion of
group that is outside of the identity store, e.g Github team
- external groups work with some `auth` methods such as `Okta`, `Github` and `LDAP`. 
- `vault write identity/group name="<name>" policies="<policy>" type="external" metadata=<key>=<value>`
  - Create an external group.
  - `group_id` : take note of returned `id` field
- `vault write identity/group-alias name="<name>" mount_accessor=<mount_accessor> canonical_id="<group_id>"`
  - `mount_accessor` : take note of Accessor field for the target mount `vault auth list -detailed` 
  - make sure corresponding `auth` method is enabled and configured.

## available Templating Parameters

The following templating parameters can be used inside Vault policy syntax:

|                                    Name                                |                                    Description                               |
| :--------------------------------------------------------------------- | :--------------------------------------------------------------------------- |
| `identity.entity.id`                                                   | The entity's ID                                                              |
| `identity.entity.name`                                                 | The entity's name                                                            |
| `identity.entity.metadata.<<metadata key>>`                            | Metadata associated with the entity for the given key                        |
| `identity.entity.aliases.<<mount accessor>>.id`                        | Entity alias ID for the given mount                                          |
| `identity.entity.aliases.<<mount accessor>>.name`                      | Entity alias name for the given mount                                        |
| `identity.entity.aliases.<<mount accessor>>.metadata.<<metadata key>>` | Metadata associated with the alias for the given mount and metadata key      |
| `identity.groups.ids.<<group id>>.name`                                | The group name for the given group ID                                        |
| `identity.groups.names.<<group name>>.id`                              | The group ID for the given group name                                        |
| `identity.groups.names.<<group id>>.metadata.<<metadata key>>`         | Metadata associated with the group for the given key                         |
| `identity.groups.names.<<group name>>.metadata.<<metadata key>>`       | Metadata associated with the group for the given key                         |

## references

- https://www.vaultproject.io/docs/internals/limits#entity-and-group-limits
- https://www.vaultproject.io/docs/secrets/identity
- https://learn.hashicorp.com/tutorials/vault/identity

[identity-tokens]: https://www.vaultproject.io/docs/secrets/identity#identity-tokens

# KV-V1 Secret Engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Configuration](#configuration)
  - [Enable the Secret engine](#enable-the-secret-engine)
- [Consumption](#consumption)
  - [Store Data in KV-V1 engine](#store-data-in-kv-v1-engine)
  - [Read entity data From KV-V1 engine](#read-entity-data-from-kv-v1-engine)
  - [List entities under specific path](#list-entities-under-specific-path)
  - [Delete entity(s)](#delete-entitys)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

Vault KV-V1 secret engine is a generic 'static' data blob store. Every value stored has
a `path` and a `value`. 
Often, it is recommended to store `json` values as you can use field such as
`allowed_parameters` in Vault policies to fine-tune what is allowed to be
stored

## Configuration

### Enable the Secret engine 

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-enable.sh -->
```bash
# bash scripts/bash/cli/00-enable.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -version="1" \
  kv
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/00-enable.sh&src=scripts/bash/api/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/00-enable.sh -->
```bash
# bash scripts/bash/api/00-enable.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "kv","options":{"version":"1"}}' \
  "${VAULT_ADDR}/v1/sys/mounts/${SECRET_ENGINE_MOUNT_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\00-enable.ps1&src=scripts/powershell/cli/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/00-enable.ps1 -->
```powershell
# scripts\powershell\cli\00-enable.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";

$SECRET_ENGINE_MOUNT_PATH="kv"

vault secrets enable `
  -path="$SECRET_ENGINE_MOUNT_PATH" `
  -version="1" `
  kv ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\00-enable.ps1&src=scripts/powershell/api/00-enable.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/00-enable.ps1 -->
```powershell
# scripts\powershell\api\00-enable.ps1
$VAULT_ADDR="http://127.0.0.1:8200";
$VAULT_ROOT_TOKEN="root";

$SECRET_ENGINE_MOUNT_PATH="kv";

$REQEUST_OPTIONS_KEY=[pscustomobject]@{
  version = "1"
}
$REQUEST_BODY = [pscustomobject]@{
    options = $REQEUST_OPTIONS_KEY
    type="kv" ;
}

$HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$HEADERS.Add("X-Vault-Token", "$VAULT_ROOT_TOKEN")
$URI=$VAULT_ADDR+"/v1/sys/mounts/$SECRET_ENGINE_MOUNT_PATH"

$response = Invoke-WebRequest `
  -Uri $URI `
  -Method POST `
  -Headers $HEADERS `
  -Body ($REQUEST_BODY|ConvertTo-Json) `
  -ContentType "application/json" `
  -UseBasicParsing
if ($response.statuscode -ne '204') {
  Write-Host 'Failed!'
  exit 1
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

## Consumption

### Store Data in KV-V1 engine

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-put.sh&src=scripts/bash/cli/01-put.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-put.sh -->
```bash
# bash scripts/bash/cli/01-put.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv put \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    foo/bar/{} random="$(base64 </dev/urandom | head -c 30)"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/01-put.sh&src=scripts/bash/api/01-put.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/01-put.sh -->
```bash
# bash scripts/bash/api/01-put.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
while read counter; do
  PAYLOAD="$(jq -n --arg random "$(base64 </dev/urandom | head -c 30)" '{"random": $random}')"
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request POST \
    --data "${PAYLOAD}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/foo/bar/${counter}"
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\01-put.ps1&src=scripts/powershell/cli/01-put.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/01-put.ps1 -->
```powershell
# scripts\powershell\cli\01-put.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $RANDOM=-Join ((33..126) | Get-Random -Count 30 | % {[char]$_})
  vault kv put -mount="$SECRET_ENGINE_MOUNT_PATH" "foo/bar/$_" random="$RANDOM"
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\01-put.ps1&src=scripts/powershell/api/01-put.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/01-put.ps1 -->
```powershell
# scripts\powershell\api\01-put.ps1
$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $REQUEST_BODY = [pscustomobject]@{
      random = -Join ((33..126) | Get-Random -Count 30 | % {[char]$_}) ;
  }

  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar/$_"
  $response = Invoke-WebRequest `
    -Uri $URI `
    -Method POST `
    -Headers $HEADERS `
    -Body ($REQUEST_BODY|ConvertTo-Json) `
    -ContentType "application/json" `
    -UseBasicParsing ;
  if ($response.statuscode -ne '204') {
    Write-Host "Failed : $SECRET_ENGINE_MOUNT_PATH/foo/bar/$_" 
  }
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read entity data From KV-V1 engine

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-get.sh&src=scripts/bash/cli/02-get.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-get.sh -->
```bash
# bash scripts/bash/cli/02-get.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv get \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    foo/bar/{}
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/02-get.sh&src=scripts/bash/api/02-get.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/02-get.sh -->
```bash
# bash scripts/bash/api/02-get.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
while read counter; do
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request GET \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/foo/bar/${counter}" |
    jq -r '.data'
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\02-get.ps1&src=scripts/powershell/cli/02-get.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/02-get.ps1 -->
```powershell
# scripts\powershell\cli\02-get.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  Write-Host "" ;
  Write-Host "Entry Path:";
  Write-Host -f green "foo/bar/$_";
  Write-Host "" ;
  vault kv get -mount="$SECRET_ENGINE_MOUNT_PATH" "foo/bar/$_"
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\02-get.ps1&src=scripts/powershell/api/02-get.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/02-get.ps1 -->
```powershell
# scripts\powershell\api\02-get.ps1
$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar/$_"

$response = Invoke-WebRequest `
    -Uri $URI `
    -Method GET `
    -Headers $HEADERS `
    -ContentType "application/json" `
    -UseBasicParsing ;
  if ($response.statuscode -eq '200') {
    $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
    $jsonObj.data | ConvertTo-Json
  }
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List entities under specific path 

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-list.sh&src=scripts/bash/cli/03-list.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-list.sh -->
```bash
# bash scripts/bash/cli/03-list.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

vault kv list "${SECRET_ENGINE_MOUNT_PATH}/foo/bar/"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/03-list.sh&src=scripts/bash/api/03-list.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/03-list.sh -->
```bash
# bash scripts/bash/api/03-list.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request LIST \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/foo/bar" |
  jq -r '.data.keys'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\03-list.ps1&src=scripts/powershell/cli/03-list.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/03-list.ps1 -->
```powershell
# scripts\powershell\cli\03-list.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"

vault kv list "$SECRET_ENGINE_MOUNT_PATH/foo/bar/"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\03-list.ps1&src=scripts/powershell/api/03-list.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/03-list.ps1 -->
```powershell
# scripts\powershell\api\03-list.ps1
$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  $PARAMS = @{
      list = "true"
  } 
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar?list=true"
  $response = Invoke-WebRequest `
    -Uri $URI `
    -Method GET `
    -Headers $HEADERS `
    -Body $PARAMS `
    -ContentType "application/json" `
    -UseBasicParsing ;
 if ($response.statuscode -eq '200') {
   $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
   $jsonObj.data.keys | ConvertTo-Json
 }
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Delete entity(s) 

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/04-delete.sh&src=scripts/bash/cli/04-delete.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/04-delete.sh -->
```bash
# bash scripts/bash/cli/04-delete.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv delete \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    foo/bar/{}
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/04-delete.sh&src=scripts/bash/api/04-delete.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/04-delete.sh -->
```bash
# bash scripts/bash/api/04-delete.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
while read counter; do
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request DELETE \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/foo/bar/${counter}"
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\cli\04-delete.ps1&src=scripts/powershell/cli/04-delete.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/cli/04-delete.ps1 -->
```powershell
# scripts\powershell\cli\04-delete.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  Write-Host "" ;
  Write-Host "Entry Path:";
  Write-Host -f green "foo/bar/$_";
  Write-Host "" ;
  vault kv delete -mount="$SECRET_ENGINE_MOUNT_PATH" "foo/bar/$_"
}
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Powershell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# scripts\powershell\api\04-delete.ps1&src=scripts/powershell/api/04-delete.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/api/04-delete.ps1 -->
```powershell
# scripts\powershell\api\04-delete.ps1
$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar/$_"

$response = Invoke-WebRequest `
    -Uri $URI `
    -Method DELETE `
    -Headers $HEADERS `
    -ContentType "application/json" `
    -UseBasicParsing ;
  if ($response.statuscode -eq '200') {
    $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
    $jsonObj.data | ConvertTo-Json
  }
}
```
<!-- AUTO-GENERATED-CONTENT:END -->

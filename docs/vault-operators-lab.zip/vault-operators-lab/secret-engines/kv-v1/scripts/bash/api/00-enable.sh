VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "kv","options":{"version":"1"}}' \
  "${VAULT_ADDR}/v1/sys/mounts/${SECRET_ENGINE_MOUNT_PATH}"

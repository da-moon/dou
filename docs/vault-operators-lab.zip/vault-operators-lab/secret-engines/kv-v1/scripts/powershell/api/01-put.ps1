$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $REQUEST_BODY = [pscustomobject]@{
      random = -Join ((33..126) | Get-Random -Count 30 | % {[char]$_}) ;
  }

  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar/$_"
  $response = Invoke-WebRequest `
    -Uri $URI `
    -Method POST `
    -Headers $HEADERS `
    -Body ($REQUEST_BODY|ConvertTo-Json) `
    -ContentType "application/json" `
    -UseBasicParsing ;
  if ($response.statuscode -ne '204') {
    Write-Host "Failed : $SECRET_ENGINE_MOUNT_PATH/foo/bar/$_" 
  }
}


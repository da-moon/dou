$VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $HEADERS = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
  $HEADERS.Add("X-Vault-Token", "$(vault print token)")
  
  $URI=$VAULT_ADDR+"/v1/$SECRET_ENGINE_MOUNT_PATH/foo/bar/$_"

$response = Invoke-WebRequest `
    -Uri $URI `
    -Method GET `
    -Headers $HEADERS `
    -ContentType "application/json" `
    -UseBasicParsing ;
  if ($response.statuscode -eq '200') {
    $jsonObj = ConvertFrom-Json $([String]::new($response.Content))
    $jsonObj.data | ConvertTo-Json
  }
}

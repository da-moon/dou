$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  $RANDOM=-Join ((33..126) | Get-Random -Count 30 | % {[char]$_})
  vault kv put -mount="$SECRET_ENGINE_MOUNT_PATH" "foo/bar/$_" random="$RANDOM"
}

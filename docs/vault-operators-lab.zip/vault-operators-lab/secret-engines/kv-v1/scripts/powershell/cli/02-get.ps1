$Env:VAULT_ADDR="http://127.0.0.1:8200";

$SECRET_ENGINE_MOUNT_PATH="kv"
1..4 | ForEach {
  Write-Host "" ;
  Write-Host "Entry Path:";
  Write-Host -f green "foo/bar/$_";
  Write-Host "" ;
  vault kv get -mount="$SECRET_ENGINE_MOUNT_PATH" "foo/bar/$_"
}

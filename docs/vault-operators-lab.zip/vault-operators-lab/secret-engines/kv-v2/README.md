# KV-V1 Secret Engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [v1 to v2 upgrade](#v1-to-v2-upgrade)
- [capablities](#capablities)
- [Configuration](#configuration)
  - [Enable the Secret engine](#enable-the-secret-engine)
- [Consumption](#consumption)
  - [Store Data Multiple Time In A Single Entity To Create Multiple Versions](#store-data-multiple-time-in-a-single-entity-to-create-multiple-versions)
  - [Read Different Versions Of Data In An Entity](#read-different-versions-of-data-in-an-entity)
  - [Read an entity's Metadata](#read-an-entitys-metadata)
  - [List Entities Under Specific Path](#list-entities-under-specific-path)
  - [Delete Different Versions Of Data In An Entity](#delete-different-versions-of-data-in-an-entity)
  - [Restore Deleted Versions Of Data In An Entity](#restore-deleted-versions-of-data-in-an-entity)
  - [Destroy Different Version Of Data In An Entity](#destroy-different-version-of-data-in-an-entity)
  - [Completely Remove An Entity](#completely-remove-an-entity)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

KV-V2 secret engine is a generic 'static' data blob store that allows __versioning__ and
__rollback__ of values. The major difference of V2 and V1 is that:

- V1 does not support Versioning/Rollbacks
- V2 can not effectively leverage fine-tuning parameters in Vault policy syntax
(e.g `allowed_parameters` ) for it's enteries

## v1 to v2 upgrade

- Before upgrading from a version 1 kv the ACL rules should be changed.
- The mount will be inaccessible during the process.
- Once upgraded to version 2, the former paths at which the data was accessible
will no longer suffice. You will need to adjust user policies to add access to
the version 2 paths 
- In V2 `writing` and `reading` versions are prefixed with the `data` path. e.g:
  - V1 : `<mount-path>/<key-path>/*`
  - V2 : `<mount-path>/data/dev/<key-path>/*`
- When you access a KV v2 secrets engine using the `vault kv` CLI commands, you
can omit `/data` in the secret path.

## capablities

| Path                                 | Capablity          | Description                                                             |
|--------------------------------------|--------------------|-------------------------------------------------------------------------|
| `<mount-path>/data/*`                | `create`, `update` | `kv-v2`: allow Writing secrets                                          |
| `<mount-path>/data/<key-path>/*`     | `delete`           | `kv-v2`: allow 'deleting' only the `latest version` of a key            |
| `<mount-path>/metadata/<key-path>/*` | `list`             | `kv-v2`: allow listing keys                                             |
| `<mount-path>/metadata/<key-path>/*` | `read`             | `kv-v2`: allow viewing metadata for each version                        |
| `<mount-path>/metadata/<key-path>/*` | `delete`           | `kv-v2`: allow permanently removing all versions and metadata for a key |
| `<mount-path>/destroy/<key-path>/*`  | `update`           | `kv-v2`: allow permanent removal (`destroy`) of any key version         |
| `<mount-path>/delete/<key-path>/*`   | `update`           | `kv-v2`: allow 'deleting' any version of a key                          |
| `<mount-path>/undelete/<key-path>/*` | `update`           | `kv-v2`: allow undeleting any version of a key                          |

## Configuration

### Enable the Secret engine 

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-enable.sh&src=scripts/bash/cli/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-enable.sh -->
```bash
# bash scripts/bash/cli/00-enable.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -version="2" \
  kv
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/00-enable.sh&src=scripts/bash/api/00-enable.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/00-enable.sh -->
```bash
# bash scripts/bash/api/00-enable.sh
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_ROOT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

curl \
  --header "X-Vault-Token: ${VAULT_ROOT_TOKEN}" \
  --request POST \
  --data '{"type": "kv","options":{"version":"2"}}' \
  "${VAULT_ADDR}/v1/sys/mounts/${SECRET_ENGINE_MOUNT_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Consumption

### Store Data Multiple Time In A Single Entity To Create Multiple Versions

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-put.sh&src=scripts/bash/cli/01-put.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-put.sh -->
```bash
# bash scripts/bash/cli/01-put.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

while read count;do
  vault kv put \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" foo/bar \
    random="$(echo $(head -c 30 </dev/urandom)$(date +%s%N) | base64 -w0)"; 
  sleep 1;
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/01-put.sh&src=scripts/bash/api/01-put.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/01-put.sh -->
```bash
# bash scripts/bash/api/01-put.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"
SECRET_VERSION=0
while read counter; do
  PAYLOAD="$(jq -n \
    --arg random "$(base64 </dev/urandom | head -c 30)" \
    --argjson cas "$SECRET_VERSION" \
    '{
      "options":{
        "cas":$cas
      },
      "data": {
        "random": $random
      }
  }')"
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request POST \
    --data "${PAYLOAD}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/data/${ENTRY_PATH}"
  # Increment version
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read Different Versions Of Data In An Entity

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-get.sh&src=scripts/bash/cli/02-get.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-get.sh -->
```bash
# bash scripts/bash/cli/02-get.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
SECRET_VERSION=0
while read counter; do
  vault kv get \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -version="${SECRET_VERSION}" \
    foo/bar
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/02-get.sh&src=scripts/bash/api/02-get.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/02-get.sh -->
```bash
# bash scripts/bash/api/02-get.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"
SECRET_VERSION=0
while read counter; do
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request GET \
    --data "version=${SECRET_VERSION}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/data/${ENTRY_PATH}" |
    jq -r '.data.data'
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read an entity's Metadata

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-read-metadata.sh&src=scripts/bash/cli/03-read-metadata.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-read-metadata.sh -->
```bash
# bash scripts/bash/cli/03-read-metadata.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
  
vault kv metadata get \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    foo/bar
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/03-read-metadata.sh&src=scripts/bash/api/03-read-metadata.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/03-read-metadata.sh -->
```bash
# bash scripts/bash/api/03-read-metadata.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"
SECRET_VERSION=0
while read counter; do
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request GET \
    --data "version=${SECRET_VERSION}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/data/${ENTRY_PATH}" |
    jq -r '.data.metadata'
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List Entities Under Specific Path 

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/04-list.sh&src=scripts/bash/cli/04-list.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/04-list.sh -->
```bash
# bash scripts/bash/cli/04-list.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

vault kv list "${SECRET_ENGINE_MOUNT_PATH}/foo/"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/04-list.sh&src=scripts/bash/api/04-list.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/04-list.sh -->
```bash
# bash scripts/bash/api/04-list.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request LIST \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/metadata/foo" |
  jq -r '.data.keys'
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Delete Different Versions Of Data In An Entity

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/05-delete.sh&src=scripts/bash/cli/05-delete.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/05-delete.sh -->
```bash
# bash scripts/bash/cli/05-delete.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv delete \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -versions={} \
    foo/bar
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/05-delete.sh&src=scripts/bash/api/05-delete.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/05-delete.sh -->
```bash
# bash scripts/bash/api/05-delete.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

VERSIONS_TO_DELETE="$(seq -s, 2)"
PAYLOAD="$(jq -n --argjson versions "[${VERSIONS_TO_DELETE}]" '{"versions":$versions}')"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/delete/${ENTRY_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Restore Deleted Versions Of Data In An Entity

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/06-restore.sh&src=scripts/bash/cli/06-restore.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/06-restore.sh -->
```bash
# bash scripts/bash/cli/06-restore.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv undelete \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -versions={} \
    foo/bar
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/06-restore.sh&src=scripts/bash/api/06-restore.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/06-restore.sh -->
```bash
# bash scripts/bash/api/06-restore.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

VERSIONS_TO_DELETE="$(seq -s, 2)"
PAYLOAD="$(jq -n --argjson versions "[${VERSIONS_TO_DELETE}]" '{"versions":$versions}')"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/undelete/${ENTRY_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Destroy Different Version Of Data In An Entity

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/07-destroy.sh&src=scripts/bash/cli/07-destroy.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/07-destroy.sh -->
```bash
# bash scripts/bash/cli/07-destroy.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv destroy \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -versions={} \
    foo/bar
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/07-destroy.sh&src=scripts/bash/api/07-destroy.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/07-destroy.sh -->
```bash
# bash scripts/bash/api/07-destroy.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

VERSIONS_TO_DELETE="$(seq -s, 2)"
PAYLOAD="$(jq -n --argjson versions "[${VERSIONS_TO_DELETE}]" '{"versions":$versions}')"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/destroy/${ENTRY_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Completely Remove An Entity

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/08-remove.sh&src=scripts/bash/cli/08-remove.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/08-remove.sh -->
```bash
# bash scripts/bash/cli/08-remove.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

vault kv metadata delete \
  -mount="${SECRET_ENGINE_MOUNT_PATH}" \
  foo/bar
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/08-remove.sh&src=scripts/bash/api/08-remove.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/08-remove.sh -->
```bash
# bash scripts/bash/api/08-remove.sh
export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request DELETE \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/metadata/${ENTRY_PATH}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
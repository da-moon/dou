export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"
SECRET_VERSION=0
while read counter; do
  PAYLOAD="$(jq -n \
    --arg random "$(base64 </dev/urandom | head -c 30)" \
    --argjson cas "$SECRET_VERSION" \
    '{
      "options":{
        "cas":$cas
      },
      "data": {
        "random": $random
      }
  }')"
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request POST \
    --data "${PAYLOAD}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/data/${ENTRY_PATH}"
  # Increment version
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)

export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"
SECRET_VERSION=0
while read counter; do
  curl -fSsl \
    --header "X-Vault-Token: $(vault print token)" \
    --request GET \
    --data "version=${SECRET_VERSION}" \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/data/${ENTRY_PATH}" |
    jq -r '.data.metadata'
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)

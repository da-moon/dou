export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request LIST \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/metadata/foo" |
  jq -r '.data.keys'

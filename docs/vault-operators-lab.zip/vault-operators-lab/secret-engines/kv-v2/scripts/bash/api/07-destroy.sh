export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

VERSIONS_TO_DELETE="$(seq -s, 2)"
PAYLOAD="$(jq -n --argjson versions "[${VERSIONS_TO_DELETE}]" '{"versions":$versions}')"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request POST \
  --data "${PAYLOAD}" \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/destroy/${ENTRY_PATH}"

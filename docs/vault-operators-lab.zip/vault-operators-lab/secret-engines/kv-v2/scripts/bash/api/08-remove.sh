export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
ENTRY_PATH="foo/bar"

curl -fSsl \
  --header "X-Vault-Token: $(vault print token)" \
  --request DELETE \
  "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/metadata/${ENTRY_PATH}"

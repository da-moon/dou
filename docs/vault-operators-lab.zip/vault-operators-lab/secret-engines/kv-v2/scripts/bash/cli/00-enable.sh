export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"

SECRET_ENGINE_MOUNT_PATH="kv"

vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -version="2" \
  kv

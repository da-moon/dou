export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

while read count;do
  vault kv put \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" foo/bar \
    random="$(echo $(head -c 30 </dev/urandom)$(date +%s%N) | base64 -w0)"; 
  sleep 1;
done < <(seq 4)

export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"
SECRET_VERSION=0
while read counter; do
  vault kv get \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -version="${SECRET_VERSION}" \
    foo/bar
  SECRET_VERSION=$((SECRET_VERSION + 1))
done < <(seq 4)

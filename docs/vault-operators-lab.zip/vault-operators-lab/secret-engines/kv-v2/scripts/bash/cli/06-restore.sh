export VAULT_ADDR="http://127.0.0.1:8200"

SECRET_ENGINE_MOUNT_PATH="kv"

seq 4 |
  xargs -I {} \
    vault kv undelete \
    -mount="${SECRET_ENGINE_MOUNT_PATH}" \
    -versions={} \
    foo/bar

# PKI Secret Engine
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Configuration](#configuration)
  - [Mount Root PKI Engine](#mount-root-pki-engine)
  - [Generate Self-Signed certificate for Root PKI Engine](#generate-self-signed-certificate-for-root-pki-engine)
  - [Configure Root PKI engine CA and CRL URLs](#configure-root-pki-engine-ca-and-crl-urls)
  - [List Issuers in the root CA for debugging](#list-issuers-in-the-root-ca-for-debugging)
  - [Read Issuer information in the root CA for debugging](#read-issuer-information-in-the-root-ca-for-debugging)
  - [Mount intermediate PKI Engine](#mount-intermediate-pki-engine)
  - [Generate CA certificate for intermediate PKI Engine](#generate-ca-certificate-for-intermediate-pki-engine)
  - [Ask root PKI engine to sign intermediate PKI Engine CA certificate](#ask-root-pki-engine-to-sign-intermediate-pki-engine-ca-certificate)
  - [Configure Intermediate PKI engine CA and CRL URLs](#configure-intermediate-pki-engine-ca-and-crl-urls)
  - [List Issuers in the Intermediate for debugging](#list-issuers-in-the-intermediate-for-debugging)
  - [Read Issuer information in the Intermediate for debugging](#read-issuer-information-in-the-intermediate-for-debugging)
  - [Create a role for certificate generation in the intermediate PKI engine](#create-a-role-for-certificate-generation-in-the-intermediate-pki-engine)
  - [Create certificate admin policy](#create-certificate-admin-policy)
  - [Create a certificate client policy](#create-a-certificate-client-policy)
- [Consumption](#consumption)
  - [Generate a certificate](#generate-a-certificate)
  - [Validate certificate with openssl](#validate-certificate-with-openssl)
  - [List generated self-signed certificates](#list-generated-self-signed-certificates)
  - [Revoke a certificate](#revoke-a-certificate)
  - [Get CRL of default certificate issuer from Vault API](#get-crl-of-default-certificate-issuer-from-vault-api)
  - [Confirm revoked certificate serial number is In Vault CRL](#confirm-revoked-certificate-serial-number-is-in-vault-crl)
  - [Generate a certificate from an externally generated CSR](#generate-a-certificate-from-an-externally-generated-csr)
  - [Rotate intermediate PKI engine CA](#rotate-intermediate-pki-engine-ca)
  - [Cleanup and remove revoked certificates](#cleanup-and-remove-revoked-certificates)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

We start by briefly explaining X.509 certificate lifecycle:

- Every X.509 certificate begins with an **asymmetric** key pair, using an algorithm
like `RSA` or `ECDSA`. 
- This key pair is used to create a Certificate Signing
Request (`CSR`), which contains a set of fields the requester would like in the
final certificate 
  - it is up to the Certificate Authority (CA) to decide what fields to take from the CSR and which to override. 
  - The CSR also contains the public key of the pair, which is signed by the
    private key of the key pair to **prove possession**. 
- Usually, the requester would ask for attributes in the `Subject` field of the
  CSR or in the `Subject Alternative Name` extension CSR to be respected in the
  final certificate. 
  - It is up to the CA if these values are trusted or not. 
- When approved by the issuing authority which may be backed by
this asymmetric key itself in the case of a root self-signed certificate:
  - the authority attaches the Subject of its certificate to the issued certificate in
the Issuer field
  - assigns a unique serial number to the issued certificate
  - signs the set of fields with its private key, thus creating the certificate.

Keep in mind that a set of important restrictions applies to certificates:

- One certificate can only have one Issuer, but this issuer is identified by the Subject on the issuing certificate and its public key.
- One CA key pair can be used for multiple certificates, but one certificate can
  only have one backing issuer CA key material.

The PKI secrets engine generates dynamic `X.509` certificates. With this secrets
engine, services can get certificates without going through the usual manual
process of generating a private key and CSR, submitting to a CA, and waiting for
a verification and signing process to complete. Vault's built-in authentication
and authorization mechanisms provide the verification functionality.

The PKI secret engine allows dynamically generating certificates, which has the following advantages over classic CA scenarios:

- Generating certificates with short TTLs reduces the need for and/or size of CRLs.
- Allows for ephemeral certificates that are generated upon application startup, stored in memory and discarded on shutdown.

![PKI Secret Engine Architecture](https://mktg-content-api-hashicorp.vercel.app/api/assets?product=tutorials&version=main&asset=public%2Fimg%2Fvault%2Fdiagram_pki_scenario-intro.png)

Generally speaking, the following steps are taken for securely mounting PKI
engine:

* Mount a '**root**' PKI engine.
* Prepare a managed key in Azure key vault
* Configure '**root**' PKI engine and have it generate a CA certificate and
  sign it using the Azure Key Vault Managed Key.
* Mount the Client-Facing ('**Intermediary**') PKI engine
* Create a self-signed certificate for the '**Intermediary**' PKI engine through Vault's API
* Sign '*Intermediary*' PKI engine's self-signed certificate with '**root**'
  PKI secret engine's CA certificate update its configuration so that it uses the newly
  signed CA

The following diagram shows the process in more detailed fashion:

<div style="visibility: hidden">\blandscape</div>
![PKI Secret Engine Workflow](./fixtures/diagram.png)
<div style="page-break-after: always; visibility: hidden">\elandscape</div>

In this tutorial, we are assuming:

- Both `root` and `intermediate` PKI engines are mounted in the same namespace.

## Configuration

### Mount Root PKI Engine

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/00-mount-root-pki-engine.sh&src=scripts/bash/cli/00-mount-root-pki-engine.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/00-mount-root-pki-engine.sh -->
```bash
# bash scripts/bash/cli/00-mount-root-pki-engine.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"
# Years * Days * hours
LEASE_TTL="$((10 * 365 * 24))h"
vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -default-lease-ttl="${LEASE_TTL}" \
  -max-lease-ttl="${LEASE_TTL}" \
  pki
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Generate Self-Signed certificate for Root PKI Engine

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/01-generate-self-signed-certificate-for-root-pki-engine.sh&src=scripts/bash/cli/01-generate-self-signed-certificate-for-root-pki-engine.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/01-generate-self-signed-certificate-for-root-pki-engine.sh -->
```bash
# bash scripts/bash/cli/01-generate-self-signed-certificate-for-root-pki-engine.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"
# Years * Days * hours
TTL="$((10 * 365 * 24))h"
COMMON_NAME="acme.com"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/root/generate/internal" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  issuer_name="vault-root-pki-engine" \
  ttl="${TTL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Configure Root PKI engine CA and CRL URLs

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/02-configure-root-pki-engine-ca-and-crl-urls.sh&src=scripts/bash/cli/02-configure-root-pki-engine-ca-and-crl-urls.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/02-configure-root-pki-engine-ca-and-crl-urls.sh -->
```bash
# bash scripts/bash/cli/02-configure-root-pki-engine-ca-and-crl-urls.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/config/urls" \
  issuing_certificates="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/ca" \
  crl_distribution_points="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/crl"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List Issuers in the root CA for debugging

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/03-list-issuers-in-the-root-ca-for-debugging.sh&src=scripts/bash/cli/03-list-issuers-in-the-root-ca-for-debugging.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/03-list-issuers-in-the-root-ca-for-debugging.sh -->
```bash
# bash scripts/bash/cli/03-list-issuers-in-the-root-ca-for-debugging.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"

vault list -detailed \
  "${SECRET_ENGINE_MOUNT_PATH}/issuers"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read Issuer information in the root CA for debugging

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/04-read-issuer-information-in-the-root-ca-for-debugging.sh&src=scripts/bash/cli/04-read-issuer-information-in-the-root-ca-for-debugging.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/04-read-issuer-information-in-the-root-ca-for-debugging.sh -->
```bash
# bash scripts/bash/cli/04-read-issuer-information-in-the-root-ca-for-debugging.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"

ISSUER_SERIAL="$(vault list -detailed -format json "${SECRET_ENGINE_MOUNT_PATH}/issuers" |
  jq -r '
.data.key_info | 
to_entries[] | 
select(.value.is_default == true).key')"
vault read \
  "${SECRET_ENGINE_MOUNT_PATH}/issuer/${ISSUER_SERIAL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Mount intermediate PKI Engine

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/05-mount-intermediate-pki-engine.sh&src=scripts/bash/cli/05-mount-intermediate-pki-engine.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/05-mount-intermediate-pki-engine.sh -->
```bash
# bash scripts/bash/cli/05-mount-intermediate-pki-engine.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
# Years * Days * hours
LEASE_TTL="$((30 * 24))h"
MAX_LEASE_TTL="$((5 * 365 * 24))h"
vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -default-lease-ttl="${LEASE_TTL}" \
  -max-lease-ttl="${MAX_LEASE_TTL}" \
  pki
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Generate CA certificate for intermediate PKI Engine

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/06-generate-a-ca-certificate-for-intermediate-pki-engine.sh&src=scripts/bash/cli/06-generate-a-ca-certificate-for-intermediate-pki-engine.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/06-generate-a-ca-certificate-for-intermediate-pki-engine.sh -->
```bash
# bash scripts/bash/cli/06-generate-a-ca-certificate-for-intermediate-pki-engine.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
COMMON_NAME="example.acme.com"
# Years * Days * hours
TTL="$((5 * 365 * 24))h"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/generate/internal" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  ttl="${TTL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Ask root PKI engine to sign intermediate PKI Engine CA certificate

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/07-ask-root-pki-engine-to-sign-intermediate-pki-engine-ca-certificate.sh&src=scripts/bash/cli/07-ask-root-pki-engine-to-sign-intermediate-pki-engine-ca-certificate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/07-ask-root-pki-engine-to-sign-intermediate-pki-engine-ca-certificate.sh -->
```bash
# bash scripts/bash/cli/07-ask-root-pki-engine-to-sign-intermediate-pki-engine-ca-certificate.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROOT_SECRET_ENGINE_MOUNT_PATH="root-pki"
COMMON_NAME="example.acme.com"
# Years * Days * hours
TTL="$((5 * 365 * 24))h"

CSR="$(vault write \
  -field=csr \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/generate/internal" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  ttl="${TTL}")"
SIGNED_CERTIFICATE="$(vault write \
  -field certificate \
  "${ROOT_SECRET_ENGINE_MOUNT_PATH}/root/sign-intermediate" \
  issuer_ref="vault-root-pki-engine" \
  csr="${CSR}" \
  format=pem_bundle \
  ttl="${TTL}")"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/set-signed" \
  certificate="${SIGNED_CERTIFICATE}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Configure Intermediate PKI engine CA and CRL URLs

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/08-configure-intermediate-pki-engine-ca-and-crl-urls.sh&src=scripts/bash/cli/08-configure-intermediate-pki-engine-ca-and-crl-urls.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/08-configure-intermediate-pki-engine-ca-and-crl-urls.sh -->
```bash
# bash scripts/bash/cli/08-configure-intermediate-pki-engine-ca-and-crl-urls.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/config/urls" \
  issuing_certificates="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/ca" \
  crl_distribution_points="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/crl"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List Issuers in the Intermediate for debugging

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/09-list-issuers-in-the-intermediate-for-debugging.sh&src=scripts/bash/cli/09-list-issuers-in-the-intermediate-for-debugging.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/09-list-issuers-in-the-intermediate-for-debugging.sh -->
```bash
# bash scripts/bash/cli/09-list-issuers-in-the-intermediate-for-debugging.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

vault list -detailed \
  "${SECRET_ENGINE_MOUNT_PATH}/issuers"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read Issuer information in the Intermediate for debugging

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/10-read-issuer-information-in-the-intermediate-for-debugging.sh&src=scripts/bash/cli/10-read-issuer-information-in-the-intermediate-for-debugging.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/10-read-issuer-information-in-the-intermediate-for-debugging.sh -->
```bash
# bash scripts/bash/cli/10-read-issuer-information-in-the-intermediate-for-debugging.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

ISSUER_SERIAL="$(vault list -detailed -format json "${SECRET_ENGINE_MOUNT_PATH}/issuers" |
  jq -r '
.data.key_info | 
to_entries[] | 
select(.value.is_default == true).key')"
vault read \
  "${SECRET_ENGINE_MOUNT_PATH}/issuer/${ISSUER_SERIAL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Create a role for certificate generation in the intermediate PKI engine

| Param              | Description                                                                                                                                                        |
| ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| allowed_domains    | Specifies the domains of the role (used with `allow_bare_domains` and `allow_subdomains` options)                                                                      |
| allow_bare_domains | Specifies if clients can request certificates matching the value of the actual domains themselves                                                                  |
| allow_subdomains   | Specifies if clients can request certificates with CNs that are subdomains of the CNs allowed by the other role options (NOTE: This includes wildcard subdomains.) |
| allow_glob_domains | Allows names specified in `allowed_domains` to contain glob patterns (e.g. ftp\*.example.com)                                                                        |

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/11-create-a-role-for-certificate-generation-in-the-intermediate-pki-engine.sh&src=scripts/bash/cli/11-create-a-role-for-certificate-generation-in-the-intermediate-pki-engine.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/11-create-a-role-for-certificate-generation-in-the-intermediate-pki-engine.sh -->
```bash
# bash scripts/bash/cli/11-create-a-role-for-certificate-generation-in-the-intermediate-pki-engine.sh
# export VAULT_ADDR="http://127.0.0.1:8200";
# export VAULT_TOKEN="root";
# SECRET_ENGINE_MOUNT_PATH="pki"
# ROLE_NAME="example"

# vault write \
#   "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" \
#   allowed_domains="acme.com,example.acme.com" \
#   allow_subdomains=true \
#   max_ttl="72h"
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="outlook"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" \
  allowed_domains="acme.com,mail.acme.com" \
  email_protection_flag=true \
  allow_localhost=false \
  client_flag=true \
  server_flag=true \
  key_usage="DigitalSignature,KeyAgreement,KeyEncipherment,EmailProtection,ClientAuth,ServerAuth" \
  allow_subdomains=true \
  max_ttl="72h"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Create certificate admin policy

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/12-create-certificate-admin-policy.sh&src=scripts/bash/cli/12-create-certificate-admin-policy.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/12-create-certificate-admin-policy.sh -->
```bash
# bash scripts/bash/cli/12-create-certificate-admin-policy.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"

vault policy write "pki-admin-policy" - <<EOT
path "${SECRET_ENGINE_MOUNT_PATH}/sign/*" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/issue/*" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/certs" {
  capabilities = ["list"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/revoke" {
  capabilities = ["create", "update"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/tidy" {
  capabilities = ["create", "update"]
}
EOT
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Create a certificate client policy

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/13-create-a-certificate-client-policy.sh&src=scripts/bash/cli/13-create-a-certificate-client-policy.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/13-create-a-certificate-client-policy.sh -->
```bash
# bash scripts/bash/cli/13-create-a-certificate-client-policy.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
# ROLE_NAME="example"
ROLE_NAME="outlook"
vault policy write "pki-${ROLE_NAME}-client-policy" - <<EOT
path "${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME}" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/issue/${ROLE_NAME}" {
  capabilities = ["read", "update", "list", "delete"]
}
EOT
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Consumption

### Generate a certificate

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/14-generate-a-certificate.sh&src=scripts/bash/cli/14-generate-a-certificate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/14-generate-a-certificate.sh -->
```bash
# bash scripts/bash/cli/14-generate-a-certificate.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
# ROLE_NAME="outlook"
COMMON_NAME="us-east-1.example.acme.com"
# COMMON_NAME="mail.acme.com"

VAULT_TOKEN="$(vault token create -field token -policy "pki-${ROLE_NAME}-client-policy")" \
  vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/issue/${ROLE_NAME}" \
  common_name="${COMMON_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Validate certificate with openssl

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/15-validate-certificate-with-openssl.sh&src=scripts/bash/cli/15-validate-certificate-with-openssl.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/15-validate-certificate-with-openssl.sh -->
```bash
# bash scripts/bash/cli/15-validate-certificate-with-openssl.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROOT_SECRET_ENGINE_MOUNT_PATH="root-pki"
CA_BUNDLE="$(vault read -field certificate ${ROOT_SECRET_ENGINE_MOUNT_PATH}/cert/ca | openssl x509 -in -)"
CA_BUNDLE="$(printf "%s\n%s" "${CA_BUNDLE}" "$(vault read -field certificate ${SECRET_ENGINE_MOUNT_PATH}/cert/ca | openssl x509 -in -)")"
CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
CERTIFICATE="$(vault read -field certificate "${SECRET_ENGINE_MOUNT_PATH}/cert/${CERTIFICATE_SERIAL}")"
# echo "${CA_BUNDLE}" > ca.pem;
# echo "${CERTIFICATE}" > cert.pem;
openssl verify -CAfile <(echo "${CA_BUNDLE}") <(echo "${CERTIFICATE}")
```
<!-- AUTO-GENERATED-CONTENT:END -->
### List generated self-signed certificates

- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/16-list-generated-self-signed-certificates.sh&src=scripts/bash/cli/16-list-generated-self-signed-certificates.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/16-list-generated-self-signed-certificates.sh -->
```bash
# bash scripts/bash/cli/16-list-generated-self-signed-certificates.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

vault list "${SECRET_ENGINE_MOUNT_PATH}/certs"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Revoke a certificate

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/17-revoke-a-certificate.sh&src=scripts/bash/cli/17-revoke-a-certificate.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/17-revoke-a-certificate.sh -->
```bash
# bash scripts/bash/cli/17-revoke-a-certificate.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/revoke" \
  serial_number="${CERTIFICATE_SERIAL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Get CRL of default certificate issuer from Vault API

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/18-get-crl-of-default-certificate-issuer-from-vault-api.sh&src=scripts/bash/cli/18-get-crl-of-default-certificate-issuer-from-vault-api.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/18-get-crl-of-default-certificate-issuer-from-vault-api.sh -->
```bash
# bash scripts/bash/cli/18-get-crl-of-default-certificate-issuer-from-vault-api.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

# Getting name of the default certificate issuer
ISSUER="$(vault list -detailed -format json "${SECRET_ENGINE_MOUNT_PATH}/issuers" |
  jq -r '
.data.key_info | 
to_entries[] | 
select(.value.is_default == true).key')"
# getting default issuers CRL
vault read \
  -field crl \
  ${SECRET_ENGINE_MOUNT_PATH}/issuer/${ISSUER}/crl |
  openssl crl -inform pem -noout -text
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Confirm revoked certificate serial number is In Vault CRL

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/19-confirm-revoked-certificate-serial-number-is-in-vault-crl.sh&src=scripts/bash/cli/19-confirm-revoked-certificate-serial-number-is-in-vault-crl.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/19-confirm-revoked-certificate-serial-number-is-in-vault-crl.sh -->
```bash
# bash scripts/bash/cli/19-confirm-revoked-certificate-serial-number-is-in-vault-crl.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

# Getting generated Certificate Sertial number.
CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
# Getting generated Certificate
CERTIFICATE="$(vault read -field certificate "${SECRET_ENGINE_MOUNT_PATH}/cert/${CERTIFICATE_SERIAL}")"
# [ NOTE ] =>  this command converts certificate serial number returned from
# Vault API to match openssl output
#
# echo "${CERTIFICATE_SERIAL}" | sed -e 's/://g' -e 's/\(.*\)/\U\1/'
#
SERIAL="$(echo "${CERTIFICATE}" |
  openssl x509 -in - -noout -serial |
  cut -d= -f2)"

# getting CRL directly from Engine's configured URL
CRL_DISTRIBUTION_POINT="$(vault read \
  -format=json \
  -field crl_distribution_points \
  "${SECRET_ENGINE_MOUNT_PATH}/config/urls" |
  jq -r '. | first')"
curl -fsSlo - "${CRL_DISTRIBUTION_POINT}" |
  openssl crl -inform DER -text -noout -in - |
  grep "${SERIAL}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Generate a certificate from an externally generated CSR

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/20-generate-a-certificate-from-an-externally-generated-csr.sh&src=scripts/bash/cli/20-generate-a-certificate-from-an-externally-generated-csr.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/20-generate-a-certificate-from-an-externally-generated-csr.sh -->
```bash
# bash scripts/bash/cli/20-generate-a-certificate-from-an-externally-generated-csr.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
COMMON_NAME="external-with-openssl.example.acme.com"

# generate a key pair and CSR locally
openssl req \
  -nodes \
  -newkey rsa:4096 \
  -subj "/CN=${COMMON_NAME}/O=acme/OU=example" \
  -keyout example.key \
  -out example.csr

vault write \
  ${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME} \
  common_name="${COMMON_NAME}" \
  csr="$(cat example.csr)"
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Bash Shell Vault API
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/api/20-generate-a-certificate-from-an-externally-generated-csr.sh&src=scripts/bash/api/20-generate-a-certificate-from-an-externally-generated-csr.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/api/20-generate-a-certificate-from-an-externally-generated-csr.sh -->
```bash
# bash scripts/bash/api/20-generate-a-certificate-from-an-externally-generated-csr.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
COMMON_NAME="external-with-openssl.example.acme.com"

# generate a key pair and CSR locally
openssl req \
  -nodes \
  -newkey rsa:4096 \
  -subj "/CN=${COMMON_NAME}/O=acme/OU=example" \
  -keyout example.key \
  -out example.csr

jq -n \
  --arg common_name "${COMMON_NAME}" \
  --arg csr "$(cat example.csr)" \
  '{"common_name":$common_name,"csr":$csr}' |
  curl \
    --insecure \
    --request POST \
    --header "X-Vault-Token: ${VAULT_TOKEN}" \
    --data @- \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME}" |
  jq
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Rotate intermediate PKI engine CA

Rotating intermediate certificate in Vault is a three-step process:

- Use the `/issuers/generate/intermediate/existing` endpoint to generate a new CSR with the existing key material with the `key_ref` request parameter.
- Sign this CSR via the same signing process under the same issuer. We use Root
  PKI engine for signing the CSR, just like initial CA setup.
- use the `/intermediate/set-signed` endpoint (Just like initial CA setup) to
  import the signed certificate from previous step.


- Bash Shell Vault CLI 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/21-rotate-intermediate-pki-engine-ca.sh&src=scripts/bash/cli/21-rotate-intermediate-pki-engine-ca.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/21-rotate-intermediate-pki-engine-ca.sh -->
```bash
# bash scripts/bash/cli/21-rotate-intermediate-pki-engine-ca.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROOT_SECRET_ENGINE_MOUNT_PATH="root-pki"
COMMON_NAME="example.acme.com"
# Years * Days * hours
TTL="$((5 * 365 * 24))h"
# First Step
CSR="$(vault write \
  -field=csr \
  "${SECRET_ENGINE_MOUNT_PATH}/issuers/generate/intermediate/existing" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  ttl="${TTL}")"
# Second Step
SIGNED_CERTIFICATE="$(vault write \
  -field certificate \
  "${ROOT_SECRET_ENGINE_MOUNT_PATH}/root/sign-intermediate" \
  issuer_ref="vault-root-pki-engine" \
  csr="${CSR}" \
  format=pem_bundle \
  ttl="${TTL}")"
# third step
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/set-signed" \
  certificate="${SIGNED_CERTIFICATE}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Cleanup and remove revoked certificates

- Bash Shell Vault CLI
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/cli/22-cleanup-and-remove-revoked-certificates.sh&src=scripts/bash/cli/22-cleanup-and-remove-revoked-certificates.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/cli/22-cleanup-and-remove-revoked-certificates.sh -->
```bash
# bash scripts/bash/cli/22-cleanup-and-remove-revoked-certificates.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/tidy" \
  tidy_cert_store="true" \
  tidy_revoked_certs="true"
```
<!-- AUTO-GENERATED-CONTENT:END -->
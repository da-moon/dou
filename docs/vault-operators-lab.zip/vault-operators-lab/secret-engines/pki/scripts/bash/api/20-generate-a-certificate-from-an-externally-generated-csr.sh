export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
COMMON_NAME="external-with-openssl.example.acme.com"

# generate a key pair and CSR locally
openssl req \
  -nodes \
  -newkey rsa:4096 \
  -subj "/CN=${COMMON_NAME}/O=acme/OU=example" \
  -keyout example.key \
  -out example.csr

jq -n \
  --arg common_name "${COMMON_NAME}" \
  --arg csr "$(cat example.csr)" \
  '{"common_name":$common_name,"csr":$csr}' |
  curl \
    --insecure \
    --request POST \
    --header "X-Vault-Token: ${VAULT_TOKEN}" \
    --data @- \
    "${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME}" |
  jq

export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"
# Years * Days * hours
TTL="$((10 * 365 * 24))h"
COMMON_NAME="acme.com"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/root/generate/internal" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  issuer_name="vault-root-pki-engine" \
  ttl="${TTL}"

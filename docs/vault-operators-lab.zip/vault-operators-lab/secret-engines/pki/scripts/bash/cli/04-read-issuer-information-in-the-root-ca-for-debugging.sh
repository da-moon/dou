export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="root-pki"

ISSUER_SERIAL="$(vault list -detailed -format json "${SECRET_ENGINE_MOUNT_PATH}/issuers" |
  jq -r '
.data.key_info | 
to_entries[] | 
select(.value.is_default == true).key')"
vault read \
  "${SECRET_ENGINE_MOUNT_PATH}/issuer/${ISSUER_SERIAL}"

export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
# Years * Days * hours
LEASE_TTL="$((30 * 24))h"
MAX_LEASE_TTL="$((5 * 365 * 24))h"
vault secrets enable \
  -path="${SECRET_ENGINE_MOUNT_PATH}" \
  -default-lease-ttl="${LEASE_TTL}" \
  -max-lease-ttl="${MAX_LEASE_TTL}" \
  pki

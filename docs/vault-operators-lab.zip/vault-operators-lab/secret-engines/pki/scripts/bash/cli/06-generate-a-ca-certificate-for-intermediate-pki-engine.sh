export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
COMMON_NAME="example.acme.com"
# Years * Days * hours
TTL="$((5 * 365 * 24))h"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/generate/internal" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  ttl="${TTL}"

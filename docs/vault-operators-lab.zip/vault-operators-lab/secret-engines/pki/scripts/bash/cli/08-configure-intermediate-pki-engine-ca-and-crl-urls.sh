export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/config/urls" \
  issuing_certificates="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/ca" \
  crl_distribution_points="${VAULT_ADDR}/v1/${SECRET_ENGINE_MOUNT_PATH}/crl"

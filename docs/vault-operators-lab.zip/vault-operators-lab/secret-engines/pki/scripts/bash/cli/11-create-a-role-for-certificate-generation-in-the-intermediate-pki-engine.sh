# export VAULT_ADDR="http://127.0.0.1:8200";
# export VAULT_TOKEN="root";
# SECRET_ENGINE_MOUNT_PATH="pki"
# ROLE_NAME="example"

# vault write \
#   "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" \
#   allowed_domains="acme.com,example.acme.com" \
#   allow_subdomains=true \
#   max_ttl="72h"
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="outlook"

vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/roles/${ROLE_NAME}" \
  allowed_domains="acme.com,mail.acme.com" \
  email_protection_flag=true \
  allow_localhost=false \
  client_flag=true \
  server_flag=true \
  key_usage="DigitalSignature,KeyAgreement,KeyEncipherment,EmailProtection,ClientAuth,ServerAuth" \
  allow_subdomains=true \
  max_ttl="72h"

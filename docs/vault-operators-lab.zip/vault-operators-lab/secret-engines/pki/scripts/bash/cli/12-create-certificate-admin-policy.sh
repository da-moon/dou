export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"

vault policy write "pki-admin-policy" - <<EOT
path "${SECRET_ENGINE_MOUNT_PATH}/sign/*" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/issue/*" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/certs" {
  capabilities = ["list"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/revoke" {
  capabilities = ["create", "update"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/tidy" {
  capabilities = ["create", "update"]
}
EOT

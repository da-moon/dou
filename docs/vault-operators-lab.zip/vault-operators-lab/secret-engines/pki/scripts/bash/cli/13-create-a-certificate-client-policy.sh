export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
# ROLE_NAME="example"
ROLE_NAME="outlook"
vault policy write "pki-${ROLE_NAME}-client-policy" - <<EOT
path "${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME}" {
  capabilities = ["read", "update", "list", "delete"]
}
path "${SECRET_ENGINE_MOUNT_PATH}/issue/${ROLE_NAME}" {
  capabilities = ["read", "update", "list", "delete"]
}
EOT

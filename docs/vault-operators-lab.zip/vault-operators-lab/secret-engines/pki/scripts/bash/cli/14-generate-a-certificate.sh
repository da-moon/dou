export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
# ROLE_NAME="outlook"
COMMON_NAME="us-east-1.example.acme.com"
# COMMON_NAME="mail.acme.com"

VAULT_TOKEN="$(vault token create -field token -policy "pki-${ROLE_NAME}-client-policy")" \
  vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/issue/${ROLE_NAME}" \
  common_name="${COMMON_NAME}"

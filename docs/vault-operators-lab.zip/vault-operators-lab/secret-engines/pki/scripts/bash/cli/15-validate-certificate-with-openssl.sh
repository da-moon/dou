export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROOT_SECRET_ENGINE_MOUNT_PATH="root-pki"
CA_BUNDLE="$(vault read -field certificate ${ROOT_SECRET_ENGINE_MOUNT_PATH}/cert/ca | openssl x509 -in -)"
CA_BUNDLE="$(printf "%s\n%s" "${CA_BUNDLE}" "$(vault read -field certificate ${SECRET_ENGINE_MOUNT_PATH}/cert/ca | openssl x509 -in -)")"
CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
CERTIFICATE="$(vault read -field certificate "${SECRET_ENGINE_MOUNT_PATH}/cert/${CERTIFICATE_SERIAL}")"
# echo "${CA_BUNDLE}" > ca.pem;
# echo "${CERTIFICATE}" > cert.pem;
openssl verify -CAfile <(echo "${CA_BUNDLE}") <(echo "${CERTIFICATE}")

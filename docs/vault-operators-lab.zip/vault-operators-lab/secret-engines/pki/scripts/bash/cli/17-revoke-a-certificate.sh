export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/revoke" \
  serial_number="${CERTIFICATE_SERIAL}"

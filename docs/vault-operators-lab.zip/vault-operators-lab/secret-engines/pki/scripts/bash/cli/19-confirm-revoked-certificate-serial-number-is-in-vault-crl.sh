export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"

# Getting generated Certificate Sertial number.
CERTIFICATE_SERIAL="$(vault list -format json "${SECRET_ENGINE_MOUNT_PATH}/certs" | jq -r '. | first')"
# Getting generated Certificate
CERTIFICATE="$(vault read -field certificate "${SECRET_ENGINE_MOUNT_PATH}/cert/${CERTIFICATE_SERIAL}")"
# [ NOTE ] =>  this command converts certificate serial number returned from
# Vault API to match openssl output
#
# echo "${CERTIFICATE_SERIAL}" | sed -e 's/://g' -e 's/\(.*\)/\U\1/'
#
SERIAL="$(echo "${CERTIFICATE}" |
  openssl x509 -in - -noout -serial |
  cut -d= -f2)"

# getting CRL directly from Engine's configured URL
CRL_DISTRIBUTION_POINT="$(vault read \
  -format=json \
  -field crl_distribution_points \
  "${SECRET_ENGINE_MOUNT_PATH}/config/urls" |
  jq -r '. | first')"
curl -fsSlo - "${CRL_DISTRIBUTION_POINT}" |
  openssl crl -inform DER -text -noout -in - |
  grep "${SERIAL}"

export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROLE_NAME="example"
COMMON_NAME="external-with-openssl.example.acme.com"

# generate a key pair and CSR locally
openssl req \
  -nodes \
  -newkey rsa:4096 \
  -subj "/CN=${COMMON_NAME}/O=acme/OU=example" \
  -keyout example.key \
  -out example.csr

vault write \
  ${SECRET_ENGINE_MOUNT_PATH}/sign/${ROLE_NAME} \
  common_name="${COMMON_NAME}" \
  csr="$(cat example.csr)"

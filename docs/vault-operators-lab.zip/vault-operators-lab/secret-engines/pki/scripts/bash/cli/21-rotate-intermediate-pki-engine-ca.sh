export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
SECRET_ENGINE_MOUNT_PATH="pki"
ROOT_SECRET_ENGINE_MOUNT_PATH="root-pki"
COMMON_NAME="example.acme.com"
# Years * Days * hours
TTL="$((5 * 365 * 24))h"
# First Step
CSR="$(vault write \
  -field=csr \
  "${SECRET_ENGINE_MOUNT_PATH}/issuers/generate/intermediate/existing" \
  country="US" \
  province="CA" \
  locality="San Francisco" \
  common_name="${COMMON_NAME}" \
  ttl="${TTL}")"
# Second Step
SIGNED_CERTIFICATE="$(vault write \
  -field certificate \
  "${ROOT_SECRET_ENGINE_MOUNT_PATH}/root/sign-intermediate" \
  issuer_ref="vault-root-pki-engine" \
  csr="${CSR}" \
  format=pem_bundle \
  ttl="${TTL}")"
# third step
vault write \
  "${SECRET_ENGINE_MOUNT_PATH}/intermediate/set-signed" \
  certificate="${SIGNED_CERTIFICATE}"

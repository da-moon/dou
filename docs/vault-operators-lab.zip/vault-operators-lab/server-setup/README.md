# Server Setup
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Bash Shell](#bash-shell)
- [PowerShell](#powershell)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This document contains instructions for starting `Vault` server in dev mode.

## Prerequisites

- `Docker` or `Vault` Binary in opened terminal shell's `PATH`
- `Powershell` or `Bash` shell

## Bash Shell

- If you want to use Docker, use the set `vault` alias to launch dockerized `Vault` binary 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# source scripts/bash/00-alias.sh&src=scripts/bash/00-alias.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/00-alias.sh -->
```bash
# source scripts/bash/00-alias.sh
alias vault='docker run \
--rm \
--publish "8200:8200" \
--name "vault-operators-lab" \
--env-file <(env | grep VAULT) \
"vault"'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- start `Vault` server in `dev` mode.
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/bash/01-start.sh&src=scripts/bash/01-start.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/01-start.sh -->
```bash
# bash scripts/bash/01-start.sh
vault \
  server \
  -tls-skip-verify \
  -dev \
  -dev-transactional \
  -dev-ha \
  -log-level=debug \
  -dev-listen-address='0.0.0.0:8200' \
  -dev-root-token-id=root
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Open a new terminal and set Vault related environment variables
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# source scripts/bash/02-environment-variables.sh&src=scripts/bash/02-environment-variables.sh) -->
<!-- The below code snippet is automatically added from scripts/bash/02-environment-variables.sh -->
```bash
# source scripts/bash/02-environment-variables.sh
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
```
<!-- AUTO-GENERATED-CONTENT:END -->

## PowerShell

- If you want to use Docker, use the set `vault` alias to launch dockerized `Vault` binary 
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# . .\scripts\powershell\00-alias.ps1&src=scripts/powershell/00-alias.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/00-alias.ps1 -->
```powershell
# . .\scripts\powershell\00-alias.ps1
function Dockerized-Vault([Parameter(ValueFromRemainingArguments = $true)]$params) { 
  & docker run `
  --rm `
  --name "vault-operators-lab" `
  --publish "8200:8200" `
  "vault" $params 
}
Set-Alias vault Dockerized-Vault
```
<!-- AUTO-GENERATED-CONTENT:END -->
- start `Vault` server in `dev` mode.
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=powershell&header=# .\scripts\powershell\01-start.ps1&src=scripts/powershell/01-start.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/01-start.ps1 -->
```powershell
# .\scripts\powershell\01-start.ps1
vault `
  server `
  -tls-skip-verify `
  -dev `
  -dev-transactional `
  -dev-ha `
  -log-level=debug `
  -dev-listen-address='0.0.0.0:8200' `
  -dev-root-token-id=root ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Open a new terminal and set Vault related environment variables
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# . .\scripts\powershell\02-environment-variables.ps1&src=scripts/powershell/02-environment-variables.ps1) -->
<!-- The below code snippet is automatically added from scripts/powershell/02-environment-variables.ps1 -->
```bash
# . .\scripts\powershell\02-environment-variables.ps1
$Env:VAULT_ADDR="http://127.0.0.1:8200";
$Env:VAULT_TOKEN="root";
```
<!-- AUTO-GENERATED-CONTENT:END -->

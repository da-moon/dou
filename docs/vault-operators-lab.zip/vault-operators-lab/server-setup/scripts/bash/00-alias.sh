alias vault='docker run \
--rm \
--publish "8200:8200" \
--name "vault-operators-lab" \
--env-file <(env | grep VAULT) \
"vault"'

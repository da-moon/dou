vault \
  server \
  -tls-skip-verify \
  -dev \
  -dev-transactional \
  -dev-ha \
  -log-level=debug \
  -dev-listen-address='0.0.0.0:8200' \
  -dev-root-token-id=root

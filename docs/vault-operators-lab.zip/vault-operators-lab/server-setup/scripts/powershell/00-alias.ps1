function Dockerized-Vault([Parameter(ValueFromRemainingArguments = $true)]$params) { 
  & docker run `
  --rm `
  --name "vault-operators-lab" `
  --publish "8200:8200" `
  "vault" $params 
}
Set-Alias vault Dockerized-Vault

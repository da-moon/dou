curl -fSsl \
--header "X-Vault-Token: ${VAULT_TOKEN}" \
--header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
--request GET \
"${VAULT_ADDR}/v1/pki/roles/${ROLE_NAME}"

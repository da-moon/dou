DIR_ROOT="$('cd' "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)" ;
openssl verify  -CAfile "${DIR_ROOT}/ca_chain.crt"  "${DIR_ROOT}/certificate.crt"  ;

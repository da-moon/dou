# snapshots-azure
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Prerequisites](#prerequisites)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This module enables Vault auto snapshots and stores them in Azure Blob Storage
The following list is the frequency of snapshots:

- Hourly
- daily
- weekly
- monthly

## Prerequisites

Before Running this module, you need to create an Azure blob storage Account and
Container and pass the appropriate value to the module through Terraform
variables.

Assuming you have `Azure CLI` installed, you can use the
following snippets to setup Azure prerequisites:

- The following snippet can be used to login with a service principle

```bash
az login \
  --service-principal \
  --tenant "${AZURE_TENANT_ID}" \
  --username "${AZURE_CLIENT_ID}" \
  --password "${AZURE_CLIENT_SECRET}"  ;
```

- Create a storage account

```bash
export AZURE_STORAGE_ACCOUNT="vault$(base64 < /dev/urandom | head -c 4 | tr '[:upper:]' '[:lower:]' )" ;
az storage account create \
  --name "${AZURE_STORAGE_ACCOUNT}" \
  --resource-group 'gmf-vault-accelerator' \
  --query 'name' \
| sed 's/"//g' ;
export TF_VAR_azure_account_name="${AZURE_STORAGE_ACCOUNT}"
```

- Get Storage Account Key

```bash
export AZURE_STORAGE_KEY="$(az storage account keys list \
  --resource-group  "gmf-vault-accelerator" \
  --account-name "${AZURE_STORAGE_ACCOUNT}" \
  --query "[? permissions=='FULL'] | [0].value" \
| sed 's/"//g')" ;
export TF_VAR_azure_account_key="${AZURE_STORAGE_KEY}"
```

- Create a storage container

```bash
az storage container create \
  --name "snapshots" \
  --account-name "${AZURE_STORAGE_ACCOUNT}"  \
  --account-key "${AZURE_STORAGE_KEY}" ;
```

To cleanup after `destroying` infrastructure, you can use the following commands:

- Remove Storage Container

```bash
az storage container delete \
  --name "snapshots" \
  --account-name "${AZURE_STORAGE_ACCOUNT}"  \
  --account-key "${AZURE_STORAGE_KEY}" ;
```

- Remove Storage Account

```bash
az storage account delete \
  --yes \
  --name "${AZURE_STORAGE_ACCOUNT}" \
  --resource-group 'gmf-vault-accelerator';
```

# root-self-generated-ca
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [validation and sample snippets](#validation-and-sample-snippets)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This module enables Root PKI engine with a self-generated CA

## validation and sample snippets

- Inspect the Root CA certificate with openssl to ensure it has the expected `subject`.
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/validate-ca-cert.sh &src=scripts/validate-ca-cert.sh) -->
<!-- The below code snippet is automatically added from scripts/validate-ca-cert.sh -->
```bash
# bash scripts/validate-ca-cert.sh 
terraform output -raw certificate \
| openssl x509 -noout -in -  -subject -issuer
```
<!-- AUTO-GENERATED-CONTENT:END -->

- Look into details of the certificate for further verifications
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/ca-cert-data.sh &src=scripts/ca-cert-data.sh) -->
<!-- The below code snippet is automatically added from scripts/ca-cert-data.sh -->
```bash
# bash scripts/ca-cert-data.sh 
terraform output -raw certificate \
  | openssl x509 -noout -text -in -
```
<!-- AUTO-GENERATED-CONTENT:END -->

- Read default key information
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-default-key.sh &src=scripts/read-default-key.sh) -->
<!-- The below code snippet is automatically added from scripts/read-default-key.sh -->
```bash
# bash scripts/read-default-key.sh 
curl \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/key/default" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Read engine's id of the default key
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-keys-configuration.sh &src=scripts/read-keys-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-keys-configuration.sh -->
```bash
# bash scripts/read-keys-configuration.sh 
curl \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/keys" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Read URLs to be encoded in generated certificates
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-urls.sh &src=scripts/read-urls.sh) -->
<!-- The below code snippet is automatically added from scripts/read-urls.sh -->
```bash
# bash scripts/read-urls.sh 
curl \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/urls" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Read id of the default issuer
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-issuers-configuration.sh &src=scripts/read-issuers-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-issuers-configuration.sh -->
```bash
# bash scripts/read-issuers-configuration.sh 
curl \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/issuers" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
- Read CRL configuration
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-crl-configuration.sh &src=scripts/read-crl-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-crl-configuration.sh -->
```bash
# bash scripts/read-crl-configuration.sh 
curl \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/crl" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->

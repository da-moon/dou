terraform output -raw certificate \
| openssl x509 -noout -in -  -subject -issuer

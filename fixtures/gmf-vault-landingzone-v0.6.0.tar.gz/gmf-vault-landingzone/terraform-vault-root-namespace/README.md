# terraform-vault-root-namespace
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

Essentially speaking, the first phase of configuring a Vault enterprise
cluster is to configure the `Root` namespace.

Initially in Root Namespace, we would :

- Setup DR Replication
- Configure Vault Auto Snapshot Agent with different time periods and store it
  in a durable storage like Azure blob storage.
- Setup Audit devices
- Create a `failover` token policy so that in case there is a failure in the
  primary cluster, the Vault admin will be able to generate a new token to
  promote the secondary cluster.
- Create an `admin` policy for Root namespace Administrators so that we can
  revoke the initially generated `root` token.
- Mount a Human-Friendly Auth method so that Vault admins can login easily
- Create a `provisioner` policy for use with Terraform which needs to be able
  to have almost full control over `root` namespace and all other namespaces.
- Setup a Machine friendly Auth method with appropriate roles that can be used
  by Terraform in The CI/CD pipeline.

After the initial bootstrapping of the DR Vault cluster, we will onboard teams
to their dedicated namespaces. The process of bootstrapping a new namespace
consists of:

- Creating a new namespace for the team
- Inside the namespace, we will :
  - Setting up a namespace-scoped `admin` policy
  - Mount a Human-Friendly Auth method so that Namespace admins can login
    easily
  - Ensure that all entities with `admin` in the `root` namespace can also
    login to the child namespace with human-friendly auth method.
  - Create a `provisioner` policy for use with Terraform which needs to be able
    to have almost full control over the `team` namespace.
  - Set up a Machine friendly Auth method with appropriate roles that can be
    used by Terraform in The CI/CD pipeline.
  - Ensure that all entities with `provisioner` policy in the `root` namespace
    can also provision resources in this namespace.

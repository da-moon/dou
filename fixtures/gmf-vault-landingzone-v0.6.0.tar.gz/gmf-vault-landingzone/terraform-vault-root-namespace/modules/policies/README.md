# Policies
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This module adds some default policies to the `root` namespace

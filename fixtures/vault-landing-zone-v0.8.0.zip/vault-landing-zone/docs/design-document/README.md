# design-document

- [design-document](#design-document)
  - [Overview](#overview)
  - [Packaging](#packaging)
    - [Packaging : Overview](#packaging--overview)
    - [Packaging : Diagram](#packaging--diagram)
    - [Packaging : Automation and Workflow Development Plan](#packaging--automation-and-workflow-development-plan)
    - [Packaging : implementation details](#packaging--implementation-details)
  - [Provision](#provision)
    - [Provision : Overview](#provision--overview)
    - [Provision : Diagram](#provision--diagram)
    - [Provision : Automation and Workflow Development Plan](#provision--automation-and-workflow-development-plan)
    - [Provision : implementation details](#provision--implementation-details)
  - [Deploy and Configure](#deploy-and-configure)
    - [Deploy and Configure : Overview](#deploy-and-configure--overview)
    - [Auth Methods : Common parameters](#auth-methods--common-parameters)
    - [AppRole Auth Method : Roles](#approle-auth-method--roles)
    - [Azure Auth Method : Configure](#azure-auth-method--configure)
    - [Azure Auth Method : Roles](#azure-auth-method--roles)
    - [Okta Auth Method : Configure](#okta-auth-method--configure)
    - [Secret Engines : Common parameters](#secret-engines--common-parameters)
    - [KV Secret Engine : Config](#kv-secret-engine--config)
    - [Azure Secret Engine : Overview](#azure-secret-engine--overview)
    - [Azure Secret Engine : Config](#azure-secret-engine--config)
    - [Azure Secret Engine : Roles](#azure-secret-engine--roles)
    - [PKI Secret Engine : Overview](#pki-secret-engine--overview)
    - [PKI Secret Engine : Config](#pki-secret-engine--config)
    - [PKI Secret Engine : Roles](#pki-secret-engine--roles)
  - [Test](#test)
    - [Unit Tests](#unit-tests)
  - [Security](#security)
    - [Security : Packaging](#security--packaging)
    - [Security : Provision](#security--provision)
    - [Security : Data Plane](#security--data-plane)
  - [References](#references)

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## Overview

This document aims to expand and describe different stages and tasks in
each step that need to be completed to deploy the Vault cluster
following the SOW presented to GM Financial.

![software delivery lifecycle](./fixtures/mingrammer-diagrams/sldc/diagrams_image.png)

We cover the following stages ( `Epics` ) of the software delivery
lifecycle

-   Packaging: We include all required binaries and configuration
    artifacts in the form of Standard image
-   Provision: The vault cluster requires a running environment and
    infrastructure. This infrastructure runs on Microsoft Azure.
-   Deploy and Configure: Setup and configuration of various Vault auth
    methods and secret engines.
-   Test: Creation of Terraform unit-tests with
    [`terratest`](https://terratest.gruntwork.io) framework

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## Packaging

### Packaging : Overview

In the packaging phase, we use Hashicorp's `Packer` with `Ansible`
provisioner to create a Standard Image based on **hardened** RHEL,
approved by GMF's cybersecurity department. This Standard image Contains:

-   Vault Enterprise with License and associated configuration artifacts
-   Bash scripts that set up DR cluster and render templated Vault
    configuration artifacts.

### Packaging : Diagram

![standard-image](./fixtures/mingrammer-diagrams/golden-image/diagrams_image.png)

### Packaging : Automation and Workflow Development Plan

The following is the workflow details for developing and troubleshooting
**image build** in the **Dev** environment and can be replicated in
other environments:

-   Have the **DevOps** team create an `Azure Compute Gallery Resource`
    in the `deployment` resource group.
-   Have the **DevOps** team create a `Dev Image Gallery Builder`
    Managed Identity.
-   Use a `Dev Image Gallery Builder Managed Identity` for
    troubleshooting builds and deployments into **Dev**
    `Azure Compute Gallery`.
-   `Dev Image Gallery Builder` Managed Identity has minimal required
    access permission level on **Dev** `Azure Compute Gallery` , much
    like the example provided by **DevOps** team.
-   The deployed Vault image needs access to Azure resources (e.g.,
    before `vault` service starts, we would run a script that pulls tls
    key-pair from Azure Key Vault), so we need to have the VM Images
    created with a system assigned or User Assigned Managed Identity and
    secure their runtime access by providing access to the Managed
    Identity(s) to enable this access.

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>


### Packaging : implementation details

We use test-driven development ([`TDD`](tdd)) process, which leverages
`serverspec`. The following are the requirements:

-   Azure CLI must be installed and available in `PATH`.
-   Ensure that Linux firewall (e.g `IPTables` ) allows ingress for the
    following ports:
    -   `8200`: Vault API , Cluster bootstrapping and Vault UI
    -   `8201`: Raft, replication, request forwarding
    -   `22`: SSH connection
-   Vault binary must be in user's `PATH` , under `/usr/local/bin` and
    ensure it is executable.
-   Create `vault` system user and group and ensure it does not have a
    shell so no human entity can login as `vault`
-   Vault Data Directory
    -   Location : `/var/vault/data`
    -   Ownership : `vault` user/group.
    -   Stores Raft HA storage data after Vault starts
-   Static Vault Configuration directory:
    -   Location : `/etc/vault.d`
    -   Ownership : `vault` user/group.
    -   Include any 'static' (not-templated) Vault configuration
        artifacts.
    -   Files:
        -   [`/etc/vault.d/listener.hcl`](https://www.vaultproject.io/docs/configuration/listener/tcp):
            stores configuration for setting up Vault TLS listener.
        -   [`/etc/vault.d/telemetry.hcl`](https://www.vaultproject.io/docs/configuration/telemetry):
            stores configuration that tells Vault to export metrics in
            `Prometheus` format.
        -   [`/etc/vault.d/replication.hcl`](https://www.vaultproject.io/docs/configuration/replication):
            stores configuration parameters for tuning replication
            related values.
-   Templated Vault Configuration Directory :
    -   Location: `/var/vault.d`
    -   Ownership : `vault` user/group.
    -   Include templated configuration artifacts; i.e artifacts that
        require values that are only known after a VM is created based
        off of this standard image, such as Cluster node IP addresses
    -   Templated artifacts have `tmpl` extension; e.g
        `/var/vault.d/foo.hcl.tmpl`
    -   Files:
        -   [`/var/vault.d/seal.hcl.tmpl`](https://www.vaultproject.io/docs/configuration/seal/azurekeyvault):
            Stores templated config for auto unseal with Azure Key Vault
        -   [`/var/vault.d/raft.hcl.tmpl`](https://www.vaultproject.io/docs/configuration/storage/raft):
            Stores templated config file for using built in Raft HA
            storage.
        -   `/var/vault.d/config-root.hcl.tmpl`: Stores configuration
            directives that do not belong to any stanzas such as `ui`
-   Vault Server TLS certificates
    -   Location: `/etc/vault.d/tls`
    -   Ownership : `vault` user/group.
-   Script that renders templated Vault configuration artifacts :
    -   Location: `/usr/local/bin/render-vault-config`
    -   Must be executable
    -   This script would use `envsubst` to render templated
        configuration artifacts under `/var/vault.d` and store the final
        result in `/etc/vault.d/`
    -   After rendering templates, The following must exist in Vault
        config directory
        -   `/etc/vault.d/listener.hcl`
        -   `/etc/vault.d/telemetry.hcl`
        -   `/etc/vault.d/replication.hcl`
        -   `/etc/vault.d/seal.hcl`
        -   `/etc/vault.d/raft.hcl`
        -   `/etc/vault.d/config-root.hcl`
-   Vault Certificate init script
    -   Location: `/usr/local/bin/init-vault-tls`
    -   Must be executable
    -   This script would pull CA and tls key-pair from a trusted source
        and stored them in `/etc/vault.d/certificates`
    -   After pulling the certificates, the following files must be
        created
        -   `/etc/vault.d/tls/ca.pem`
        -   `/etc/vault.d/tls/cert.pem`
        -   `/etc/vault.d/tls/key.pem`
-   Vault DR cluster setup script
    -   Location: `/usr/local/bin/vault-dr-cluster-setup`
    -   Ownership : `vault` user/group.
    -   This script runs after Vault daemon starts and sets up Vault DR
        cluster
-   Use `SystemD` to manage Vault daemon:
    -   Hardened unit file:
        -   Prevent Privilege escalation
        -   Disable swap
    -   Uses `vault` system user/group
    -   Uses `ExecStartPre` directive to run
        `/usr/local/bin/init-vault-tls` before running `vault`
    -   Uses `ExecStartPre` directive to run
        `/usr/local/bin/render-vault-config` before running `vault`
    -   Uses `ExecStartPost` to run
        `/usr/local/bin/vault-dr-cluster-setup` script after starting
        `vault`
    -   Ensure that it is **enabled** ( not **started** )

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## Provision

### Provision : Overview

We use Hashicorp's `Terraform` to automate the acquisition and
management of Azure infrastructure. We are assuming the following:

-   An Azure `Resource Group` has already been created for our team.
-   Vault Server CA and TLS key-pair has been stored in Azure Key Vault. The
    SystemD unit starting Vault process runs `init-vault-tls` script that we
    have already included in the Standard image to pull/update certificates from
    Azure Key Vault before it starts Vault process
-   VNets for **Primary** and **DR** regions
    -   `Central-US`: resources deployed in **Primary** cluster region
    -   `EAST-US-2`: resources deployed in **DR** cluster region

We must also ensure required network security rules are in place:

-   Allow intra-cluster communication on port `8201`
-   Allow incoming requests on port `8200`
-   Ensure all other traffic is blocked

Vault daemon will run on [Linux Virtual Machine Availability
Set](https://docs.microsoft.com/en-us/azure/virtual-machines/availability-set-overview)
with `five` instances. The following is Hashicorp's VM spec [recommendations](https://learn.hashicorp.com/tutorials/vault/raft-reference-architecture?in=vault/day-one-raft#hardware-sizing-for-vault-servers):

  Size    Instance/VM Types                      Disk Volume Specs
  ------- -------------------------------------- -----------------------
  Small   `Standard_D2s_v3`,`Standard_D4s_v3`    1024GB(`Premium_LRS`)
  Large   `Standard_D8s_v3`,`Standard_D16s_v3`   1024GB(`Premium_LRS`)


All incoming traffic from Clients to Vault goes through [`Azure Load
Balancer`](https://azure.microsoft.com/en-us/services/load-balancer)

### Provision : Diagram

![Infrastructure Architecture](./fixtures/mingrammer-diagrams/reference-architecture/diagrams_image.png)

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

### Provision : Automation and Workflow Development Plan

The following is the workflow details for For developing and
troubleshooting resource deployment in the **Dev** environment and can
be replicated in other environments:

-   Have the **DevOps** team create an `Azure Repo`, associated
    `Azure pipeline`, general access `variables group` or
    `variables file`, and `secrets variable group`.
-   Have the **DevOps** team create a `Dev Environment Builder` Managed
    Identity.
-   Use `Dev Environment Builder` Managed Identity for troubleshooting
    build and deployment from Repo deployment files and **Dev**
    `Azure Compute Gallery` into **Dev** `Resource Group`.
-   Ensure `Dev Environment Builder` Managed Identity has **read-only**
    access to the associated **Dev** `Azure Compute Gallery` and
    permissions to create the Azure resource types needed in your
    deployment. Ensure the permissions are scoped only to the dedicated
    resource group.

### Provision : implementation details

We are leveraging Hashicorp's `Terraform` to automate the acquisition and
management of resources. This phase is broken down into multiple loosely
connected terraform submodules. These submodules independently do not
accomplish any business goals; the **root** module composes them to achieve the
overall goal of provisioning the resources.

The following is a list of those submodules:

- `common-tags`: This is an auxiliary module that generates resource tags used
in the other terraform submodules. It enforces a consistent naming convention
for tagging resources.
- `IAM` : All Vault-related IAM resources are managed in this submodule
- `classic-load-balancer`: This submodule creates and manages a Classic load
balancer for the Vault cluster.
- `vm` : This submodule creates and manages availability set nodes that Vault cluster
runs on.

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## Deploy and Configure

### Deploy and Configure : Overview

In this phase, we deploy and configure Vault Authentication methods and secret
Engines.

Vault exposes it's functionalities through various Secret Engine. A Secret
Engine can be viewed as a single microservice that takes care of a specific
task.

To use a Secret Engine, the user has to Authenticate first. Vault uses
role-based access control (RBAC) to enforce access and proper authorization.

Every Authentication method in Vault can have a series of roles to authenticate
against. A single role is a collection of Policy documents. Once a user
authenticates against a specific role of an Auth method, a `Bearer` Token is
returned. This bearer token is used in API calls to Vault secret engines and
Vault rejects/allows the API call based on token policies.

The following diagram shows an example `KV` secret engine usage workflow:

![KV Secret Engine Workflow](./fixtures/mermaid/secret-engine-workflow/diagram.png)

- User Authenticates Against an Auth method
- The returned bearer token is used in `X-Vault-Token` HTTP header when sending
  requests to KV engine mounted under `kv/` paths
- Users that use `admin` ( arbitrary name ) **Role** have full access to the
  KV engine , as it was defined in their token policy documents and users that
  use `reader` ( arbitrary name ) **Role** have only Read access to the KV
  engine and cannot write/update any existing entities

In general, Configuring vault can be broken down into the following Steps

* Enable an Auth methods. As an example, the following can be used for enabling
AppRole `Auth` method:

```bash
vault auth enable approle
```

* Mount a secret engine. As an example, the following will mount `PKI` secret
  engine:

```bash
vault secrets enable -path=example-pki pki;
```

* Configure the secret engine if needed. as an example, the following with
  change maximum lease TTL of the engine mounted under `example-pki` to  `365`
  days and prepares it for generating certificates :

```bash
VAULT_ADDR="http://127.0.0.1:8200"
SECRET_MOUNT="example-pki"
vault secrets tune -max-lease-ttl=8760h "$SECRET_MOUNT";
vault write "$SECRET_MOUNT/root/generate/internal" common_name=example.com ttl=8760h;
vault write "$SECRET_MOUNT/config/urls" issuing_certificates="$VAULT_ADDR/v1/${SECRET_MOUNT}/ca" crl_distribution_points="$VAULT_ADDR/v1/$SECRET_MOUNT/crl";
vault write "$SECRET_MOUNT/roles/example-dot-com" allowed_domains=example.com allow_subdomains=true max_ttl=72h;
vault write "$SECRET_MOUNT/issue/example-dot-com" common_name=www.example.com
```

> Keep in mind that the **Role** here is not the same as **Roles** associated
> with Auth methods.

* Define **Token** policies. These token policies can be shared in **Role**
definition of different Auth methods; These are primarily based on which Secret
Engines a token uses and what level of access is Required. As an example, the
following command defines a token policy that gives full access to PKI engine
mounted under `example-pki/` path:

```bash
SECRET_MOUNT="example-pki"
vault policy write example-policy - << EOF
path "$SECRET_MOUNT/*" {
  capabilities = [ "create", "read", "update", "delete", "list", "sudo" ]
}
EOF
```

* Define and configure Auth method **Roles**. A **Role** can be a single Token
**Policy** or a collection of Token **Policies**. A role is specific to a
single Auth method. As an example, the Following

```bash
AUTH_MOUNT="approle";
ROLE_NAME="example-role";
vault write "/auth/${AUTH_MOUNT}/role/${ROLE_NAME}" \
  token_policies="example-policy" \
  secret_id_ttl=10m \
  token_num_uses=10 \
  token_ttl=20m \
  token_max_ttl=30m \
  secret_id_num_uses=40;
```

* Have the user authenticate against the auth method. In our example, we are
  using AppRole, so we would need a secret ID and Access ID:

```bash
AUTH_MOUNT="approle";
ROLE_NAME="example-role";
ROLE_ID="$(vault read -field=role_id auth/${AUTH_MOUNT}/role/${ROLE_NAME}/role-id)"
SECRET_ID="$(vault write -f -field=secret_id auth/${AUTH_MOUNT}/role/${ROLE_NAME}/secret-id)"
# Authenticate
curl \
  --request POST \
  --data "{\"role_id\": \"${ROLE_ID}\",\"secret_id\":\"${SECRET_ID}\"}" \
"${VAULT_ADDR}/v1/auth/${AUTH_MOUNT}/login"
```

* Use the **Bearer** token in the `X-Vault-Token` HTTP header to access the
  secret engine. As an example, the following command will use the PKI engine,
  mounted under `example-pki/` to generate a new set of TLS certificates:
  cert:

```bash
VAULT_ADDR="http://127.0.0.1:8200"
SECRET_MOUNT="example-pki"
AUTH_MOUNT="approle";
ROLE_NAME="example-role";
ROLE_ID="$(vault read -field=role_id auth/${AUTH_MOUNT}/role/${ROLE_NAME}/role-id)"
SECRET_ID="$(vault write -f -field=secret_id auth/${AUTH_MOUNT}/role/${ROLE_NAME}/secret-id)"
VAULT_TOKEN="$(curl --silent --request POST --data "{\"role_id\": \"${ROLE_ID}\",\"secret_id\":\"${SECRET_ID}\"}" "${VAULT_ADDR}/v1/auth/${AUTH_MOUNT}/login" | jq -r '.auth.client_token')";

curl --header "X-Vault-Token: $VAULT_TOKEN" --request POST --data '{"common_name": "www.example.com"}' "${VAULT_ADDR}/v1/${SECRET_MOUNT}/issue/example-dot-com"
```

We leverage `Terraform` for the configuration of the following Auth Methods Authentication Secret Engines are

-   Auth Methods:
    -   App Role : Authentication method, primarily used by non-human entities.
    -   JWT/OIDC: Enables authentication with JWT or OIDC provider.
    -   Azure: Enables authentication against Vault using Azure Active
        Directory credentials
- Secret Engines:
    -   KV : Generic Key-Value pair storage
    -   Azure : Enables dynamic generation and lifecycle management of Azure
        service principals along with role and group assignments
    -   PKI: Dynamic generation and management of X.509 certificates

### Auth Methods : Common parameters

The following parameters are common across several Authentication method Role
Configuration

* `Token Time To Live` : The incremental lifetime for generated tokens in
number of seconds. Its current value will be referenced at renewal time.
* `Token Max Time To Live` : The maximum lifetime for generated tokens in
number of seconds. Its current value will be referenced at renewal time.
* `Token Period` : If set, indicates that the token generated using this role
should never expire. The token should be renewed within the duration specified
by this value. At each renewal, the token's TTL will be set to the value of
this field. Specified in seconds.
* `Token Policies` : List of policies to encode onto generated tokens.
Depending on the auth method, this list may be supplemented by user/group/other
values.
* `Token Bound CIDRs` : List of CIDR blocks; if set, specifies blocks of IP
addresses which can authenticate successfully, and ties the resulting token to
these blocks as well.
* `Disable Token Default Policy` : If set, the default policy will not be set
on generated tokens; otherwise it will be added to the policies set in
token_policies.
* `Token Number Of Uses` : The [maximum
number](https://www.vaultproject.io/api-docs/auth/approle#token_num_uses) of
times a generated token may be used (within its lifetime); 0 means unlimited. *
`Token Type` : The type of token that should be generated. Can be `service`,
`batch`, or `default` to use the mount's tuned default (which unless changed
will be `service` tokens). For token store roles, there are two additional
possibilities: `default-service` and `default-batch` which specify the type to
return unless the client requests a different type at generation time.

### AppRole Auth Method : Roles

The following is a short description of this Auth method role's parameters:

* `Role Name` : The name of the role.
* `Require Secret ID` : Whether or not to require `secret_id` to be presented
when logging in using this AppRole. Defaults to `true`.
* `Secret ID Bound CIDRs` : If set, specifies blocks of IP addresses which can
perform the login operation.
* `Secret ID Number Of Uses` : The number of times any particular SecretID can
be used to fetch a token from this AppRole, after which the SecretID will
expire. A value of zero will allow unlimited uses.
* `Secret ID Time To Live` : The number of seconds after which any SecretID
expires.

### Azure Auth Method : Configure

The following is a short description of this Auth method configuration
parameters:

* `Tenant ID` : The tenant id for the Azure Active Directory organization.
* `Resource` : The configured URL for the application registered in Azure
Active Directory.
* `Client ID` : The client id for credentials to query the Azure APIs.
Currently read permissions to query compute resources are required.
* `Client Secret` : The client secret for credentials to query the Azure APIs.
* `Environment` : The Azure cloud environment. Valid values: AzurePublicCloud,
AzureUSGovernmentCloud, AzureChinaCloud, AzureGermanCloud.  Defaults to
`AzurePublicCloud`.

### Azure Auth Method : Roles

The following is a short description of this Auth method role's parameters:

* `Bound Service Principal IDs` : If set, defines a constraint on the service
principals that can perform the login operation that they should be possess the
ids specified by this field.
* `Bound Group IDs` : If set, defines a constraint on the groups that can
perform the login operation that they should be using the group ID specified by
this field.
* `Bound Locations` : If set, defines a constraint on the virtual machines that
can perform the login operation that the location in their identity document
must match the one specified by this field.
* `Bound Subscription IDs` : If set, defines a constraint on the subscriptions
that can perform the login operation to ones which matches the value specified
by this field.
* `Bound Resource Groups` : If set, defines a constraint on the virtual
machines that can perform the login operation that they be associated with the
resource group that matches the value specified by this field.
* `Bound Scale Sets` : If set, defines a constraint on the virtual machines
that can perform the login operation that they must match the scale set
specified by this field.

### Okta Auth Method : Configure

* `Description` - (Optional) The description of the auth backend
* `Organization` - (Required) The Okta organization. This will be the first part of the url `https://XXX.okta.com`
* `Token` - (Optional) The Okta API token. This is required to query Okta for user group membership.
If this is not supplied only locally configured groups will be enabled.
* `Base Url` - (Optional) The Okta url. Examples: oktapreview.com, okta.com
* `Bypass Okta MFA` - (Optional) When true, requests by Okta for a MFA check will be bypassed. This also disallows certain status checks on the account, such as whether the password is expired.
* `TTL` - (Optional) Duration after which authentication will be expired.
* `Max TTL` - (Optional) Maximum duration after which authentication will be expired
* `Okta Group Name` - (Required) Name of the group within the Okta
* `Policies` - (Optional) Vault policies to associate with this group

### Secret Engines : Common parameters

The following parameters are common across several Secret Engine Configuration:

* `Path` : Where the secret backend will be mounted
* `Description` : Human-friendly description of the mount
* `Default Lease Time To Live In Seconds` : Default lease duration for tokens and secrets in seconds
* `Max Lease Time To Live In Seconds` : Maximum possible lease duration for tokens and secrets in seconds
* `Audit Non HMAC Response Keys` : Specifies the list of keys that will not be HMAC'd by audit devices in the response data object.
* `Audit Non HMAC Request Keys` : Specifies the list of keys that will not be HMAC'd by audit devices in the request data object.
* `Local` : Boolean flag that can be explicitly set to true to enforce local mount in HA environment
* `Seal Wrap` : Boolean flag that can be explicitly set to true to enable seal wrapping for the mount, causing values stored by the mount to be wrapped by the seal's encryption capability
* `External Entropy Access` : Boolean flag that can be explicitly set to true to enable the secrets engine to access Vault's external entropy source
* `Allowed Managed Keys` : Set of managed key registry entry names that the mount in question is allowed to access

### KV Secret Engine : Config

The following is a short description of this secret engine's configuration parameters:

* `Max Entry Versions` : (**KV-V2** Only) The number of versions to keep per key.
* `CAS Required` : (**KV-V2** Only) If true, all keys will require the cas parameter to be set on all write requests.
* `Delete Entry Version After` : (**KV-V2** Only) If set, specifies the length
  of time before a version is deleted. Accepts duration in integer seconds.

### Azure Secret Engine : Overview

This secret engine dynamically generates Azure service principals and role
assignments. One can use pre-existing Azure Roles or generate them
through Vault.

### Azure Secret Engine : Config

The following is a short description of this secret engine's configuration
parameters:

- `Subscription ID` : The subscription id for the Azure Active Directory.
- `Tenant ID` : The tenant id for the Azure Active Directory.
- `Client ID` : The OAuth2 client id to connect to Azure.
- `Client Secret` : The OAuth2 client secret to connect to Azure.
- `Environment` : The Azure environment.

> This secret engine requires specific Azure permissions to be associated with
> the passed `Client ID` and `Client Secret`.
> Refer to [`Security : Data Plane`](#security--data-plane) section for more details.

### Azure Secret Engine : Roles

The following is a short description of this secret engine's role specific
parameters:

* `Role` : Name of the Azure role
* `Backend` : Path to the mounted Azure auth backend
* `Azure Groups` : List of Azure groups to be assigned to the generated service principal.
* `Azure Roles` : List of Azure roles to be assigned to the generated service
  principal. **Azure** `Role Name` and Role `Scope` are required.
* `Application Object ID` : Application Object ID for an existing service principal that will
   be used instead of creating dynamic service principals. If present, `Azure Roles` will be ignored.
* `Time To Live` : Specifies the default TTL for service principals generated using this role.
   Accepts time suffixed strings ("1h") or an integer number of seconds. Defaults to the system/engine default TTL time.
* `Max Time To Live` : Specifies the maximum TTL for service principals generated using this role. Accepts time
   suffixed strings ("1h") or an integer number of seconds. Defaults to the system/engine max TTL time.

### PKI Secret Engine : Overview

The PKI secrets engine generates dynamic `X.509` certificates. With this secrets engine, services can get certificates without going through the usual manual process of generating a private key and CSR, submitting to a CA, and waiting for a verification and signing process to complete. Vault's built-in authentication and authorization mechanisms provide the verification functionality.

Generally speaking, the following steps are taken for securely mounting PKI
engine:

* Mount a '**root**' PKI engine.
* Prepare a managed key in Azure key vault
* Configure '**root**' PKI engine and have it generate a CA certificate and
  sign it using the Azure Key Vault Managed Key.
* Mount the Client-Facing ('**Intermediary**') PKI engine
* Create a self-signed certificate for the '**Intermediary**' PKI engine through Vault's API
* Sign '*Intermediary*' PKI engine's self-signed certificate with '**root**'
  PKI secret engine's CA certificate update its configuration so that it uses the newly
  signed CA

The following diagram shows the process in more detailed fashion:

<div style="visibility: hidden">\blandscape</div>
![PKI Secret Engine Workflow](./fixtures/mermaid/pki-secret-engine-flow/diagram.png)
<div style="page-break-after: always; visibility: hidden">\elandscape</div>

### PKI Secret Engine : Config

The following is a short description of this secret engine's configuration
parameters:

* `Managed Key ID` : Specifies the ID of Azure Key Vault managed key.
* `Issuing Certificates` : Specifies the URL values for the Issuing Certificate field.
* `CRL Distribution Points` : Specifies the URL values for the CRL Distribution Points field.
* `Common Name` : CN of intermediate to create
* `Alt Names` : List of alternative names
* `IP SANs` : List of alternative IPs
* `URI SANs` : List of alternative URIs
* `Other SANs` : List of other SANs
* `Private Key Format` : The private key format
* `Key Type` : The desired key type
* `Key Bits` : The number of bits to use
* `Exclude CN From SANs` : Flag to exclude CN from SANs
* `Organization Unit` : The organization unit
* `Organization` : The organization
* `Country` : The country
* `Locality` : The locality
* `Province` : The province
* `Street Address` : The street address
* `Postal Code` : The postal code

### PKI Secret Engine : Roles

The following is a short description of this secret engine's role specific
parameters:

* `Name` - (Required) The name to identify this role within the backend. Must be unique within the backend.
* `Certificate TTL` - (Optional, integer) The TTL, in seconds, for any certificate issued against this role.
* `Role Max TTL` - (Optional, integer) The maximum lease TTL, in seconds, for the role.
* `Allow Localhost` - (Optional) Flag to allow certificates for localhost
* `Allowed Domains` - (Optional) List of allowed domains for certificates
* `Allow Bare Domains` - (Optional) Flag to allow certificates matching the actual domain
* `Allow Subdomains` - (Optional) Flag to allow certificates matching subdomains
* `Allow Glob Domains` - (Optional) Flag to allow names containing glob patterns.
* `Allow Any Name` - (Optional) Flag to allow any name
* `Enforce Hostnames` - (Optional) Flag to allow only valid host names
* `Allow IP SANs` - (Optional) Flag to allow IP SANs
* `Allowed URI SANs` - (Optional) Defines allowed URI SANs
* `Allowed Other SANs` - (Optional) Defines allowed custom SANs
* `Server Flag` - (Optional) Flag to specify certificates for server use
* `Client Flag` - (Optional) Flag to specify certificates for client use
* `Code Signing Flag` - (Optional) Flag to specify certificates for code signing use
* `Email Protection Flag` - (Optional) Flag to specify certificates for email protection use
* `Key Type` - (Optional) The generated key type, choices: `rsa`, `ec`, `ed25519`, `any`
  Defaults to `rsa`
* `Key Bits` - (Optional) The number of bits of generated keys
* `Key Usage` - (Optional) Specify the allowed key usage constraint on issued certificates
* `Extended Key Usage` - (Optional) Specify the allowed extended key usage constraint on issued certificates
* `Use CSR Common Name` - (Optional) Flag to use the CN in the CSR
* `Use CSR SANs` - (Optional) Flag to use the SANs in the CSR
* `Organization Unit` : The organization unit
* `Organization` : The organization
* `Country` : The country
* `Locality` : The locality
* `Province` : The province
* `Street Address` : The street address
* `Postal Code` : The postal code
* `Generate Lease` - (Optional) Flag to generate leases with certificates
* `No Store` - (Optional) Flag to not store certificates in the storage backend
* `Require CN` - (Optional) Flag to force CN usage

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## Test

### Unit Tests

Unit tests are defined based on Deployed engines. they also cover
**provisioning** stage **serverspec** runs validation and testing at the end
of the **packaging** phase

## Security

### Security : Packaging

![service principle scope of access rights](./fixtures/mingrammer-diagrams/security_package/diagrams_image.png)

Our Vault image is based on hardened CIS Images.
All packaging operations that interact with cloud resources have to go through
Azure DevOps pipelines.

`Packer` uses `Azure Active Directory Service Principal` with the following
Azure `Actions` permissions on the `distribution resource group` for required
access to cloud resources:

- Permission to customize existing images
  - `Microsoft.Compute/galleries/read`
  - `Microsoft.Compute/galleries/images/read`
  - `Microsoft.Compute/galleries/images/versions/read`
- Allow VM Image Builder to distribute images **within** the **distribution resource group**:
  - `Microsoft.Compute/images/write`
  - `Microsoft.Compute/images/read`
  - `Microsoft.Compute/images/delete`
- Allow distribution to Azure Compute Gallery:
  - `Microsoft.Compute/galleries/images/versions/write`
- Permission to customize images on your virtual networks
  - `Microsoft.Network/virtualNetworks/read`
  - `Microsoft.Network/virtualNetworks/subnets/join/action`

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

### Security : Provision

![service principle scope of access rights](./fixtures/mingrammer-diagrams/security_provision/diagrams_image.png)

All resource provisioning operations that interact with cloud resources have to go through
Azure DevOps pipelines.

`Terraform` uses `Azure Active Directory Service Principal` with the following Azure
`Actions` permissions on the `distribution resource group` for required access to
cloud resources:

- resource group RBAC that allows for the creation of VMs while blocking `VNet` creation

```json
{
  "permissions": [
    {
      "actions": [
        "*",
        "Microsoft.Compute/virtualMachines/*",
        "Microsoft.Compute/virtualMachineScaleSets/*"
      ],
      "dataActions": [],
      "notActions": [
        "Microsoft.Authorization/*/Delete",
        "Microsoft.Authorization/*/Write",
        "Microsoft.Authorization/elevateAccess/Action",
        "Microsoft.Network/dnsZones/write",
        "Microsoft.Network/dnsZones/delete",
        "Microsoft.Network/dnsZones/*/write",
        "Microsoft.Network/dnsZones/*/delete",
        "Microsoft.Network/virtualNetworks/write",
        "Microsoft.Network/virtualNetworks/delete",
        "Microsoft.Network/virtualNetworks/peer/action",
        "Microsoft.Resources/subscriptions/resourceGroups/write",
        "Microsoft.Resources/subscriptions/resourceGroups/delete"
      ],
      "notDataActions": []
    }
  ]
}
```

- The VNet needs to have an RBAC with the following permissions to allow VMs to join

```json
{
  "permissions": [
    {
      "actions": [
        "Microsoft.Network/publicIPAddresses/join/action",
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/write",
        "Microsoft.Network/virtualNetworks/*/join/action",
        "Microsoft.Network/networkSecurityGroups/write",
        "Microsoft.Network/networkSecurityGroups/securityRules/write",
        "Microsoft.Network/networkSecurityGroups/securityRules/delete"
      ],
      "dataActions": [],
      "notActions": [],
      "notDataActions": []
    }
  ]
}
```

### Security : Data Plane

![service principle scope of access rights](./fixtures/mingrammer-diagrams/security_dataplane/diagrams_image.png)

- Hashicorp's `Vault` uses `Azure Active Directory Service Principal` to
  autheticate against `Azure Key Vault`. Azure Key Vault is used for
  - storing Vault Unseal keys and it facilitates Auto Unseal feature.
  - Storing Vault API listener TLS certificate which get's pulled before Vault
    Daemon starts
  - Storing Vault Enterprise license Key which gets pulled before Vault Daemon
    starts

| Built-in role	name        |  Role ID                                |
| ---------------           |  ---------------                        |
| `Key Vault Secrets User`  |  `4633458b-17de-408a-b874-0445c86b69e6` |
| `Key Vault Crypto User`   |  `12338af0-0e69-4776-bea7-57ae8d297424` |

- For `Azure` Secret engine, the user specified via the `Client ID`
and `Client Secret` in the configuration of the secret engine's mount
needs to have `Owner` Role and the following permissions under the `Microsoft Graph API`:

| Permission Name               | Type        |
| ----------------------------- | ----------- |
| Application.Read.All          | Application |
| Application.ReadWrite.All     | Application |
| Application.ReadWrite.OwnedBy | Application |
| Directory.Read.All            | Application |
| Directory.ReadWrite.All       | Application |
| Group.Read.All                | Application |
| Group.ReadWrite.All           | Application |
| GroupMember.Read.All          | Application |
| GroupMember.ReadWrite.All     | Application |
| Application.Read.All       | Delegated |
| Application.ReadWrite.All  | Delegated |
| Directory.AccessAsUser.All | Delegated |
| Directory.Read.All         | Delegated |
| Directory.ReadWrite.All    | Delegated |
| Group.Read.All             | Delegated |
| Group.ReadWrite.All        | Delegated |
| GroupMember.Read.All       | Delegated |
| GroupMember.ReadWrite.All  | Delegated |

<div style="page-break-after: always; visibility: hidden">\pagebreak</div>

## References

- [Packer Authentication for Azure](https://www.packer.io/plugins/builders/azure#authentication-for-azure)
- [Configure Azure VM Image Builder permissions by using the Azure CLI](https://docs.microsoft.com/en-us/azure/virtual-machines/linux/image-builder-permissions-cli)
- [Azure built-in roles](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles)
- [Create an Azure Image Builder template](https://docs.microsoft.com/en-us/azure/virtual-machines/linux/image-builder-json)
- [Azure Image Builder Service Image Creation Role JSON](https://raw.githubusercontent.com/azure/azvmimagebuilder/master/solutions/12_Creating_AIB_Security_Roles/aibRoleImageCreation.json)
[Azure security baseline for Virtual Machine Scale Sets](https://docs.microsoft.com/en-us/security/benchmark/azure/baselines/virtual-machine-scale-sets-security-baseline)
- [Azure built-in roles for Key Vault data plane operations](https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli#azure-built-in-roles-for-key-vault-data-plane-operations)
- [Hashicorp Learn: Auto-unseal using Azure Key Vault](https://learn.hashicorp.com/tutorials/vault/autounseal-azure-keyvault)
- [Vault Concepts: Policies](https://www.vaultproject.io/docs/concepts/policies)
- [Hashicorp Learn: Policies](https://learn.hashicorp.com/tutorials/vault/getting-started-policies)
<!-- https://stackoverflow.com/questions/53012713/what-is-the-difference-in-rbac-for-vms-vs-vm-scale-sets -->
<!-- https://github.com/sarubhai/aws_vault_config/blob/master/secrets/13_pki.tf -->

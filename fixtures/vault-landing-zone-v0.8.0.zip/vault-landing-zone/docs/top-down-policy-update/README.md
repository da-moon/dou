# Top Down Policy Update

## Overview

This document goes over standard operating procedure for creating/changing
Vault policies that get applied to all Vault namespaces

## Procedure

- Create a new Terraform module for your new policy under
`terraform-vault-modules/configuration/policies`. It is best to use an already
existing module as boilerplate, example : `child-namespace-admin`

```bash
cp -r terraform-vault-modules/configuration/policies/child-namespace-admin terraform-vault-modules/configuration/policies/example
```

- Update `data.vault_policy_document.this` with your own policy rules
- Update `name` field in `vault_policy.this` resource with the policy name
- Update `modules/policies/main.tf` file and add the new policy
module. It is easier to use an exisiting module such as `module
"child_admin"` as template

```hcl
module "child_admin" {
  source    = "../../../terraform-vault-modules/configuration/policies/example"
  count     = length(var.namespaces)
  namespace = var.namespaces[count.index]
}
```


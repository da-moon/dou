# Azure Auth Method Validation
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Requirements](#requirements)
- [Validation](#validation)
- [Debugging](#debugging)
  - [Check Engine Config](#check-engine-config)
- [References](#references)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This document goes through the process of validating Azure Auth method after
deployment and covers some potential issues and how to fix them

## Requirements

- A Service Principle To use with the Auth Method. This Service Principle must
have the following Azure RBAC roles:
  - `Microsoft.Compute/virtualMachines/*/read`
  - `Microsoft.Compute/virtualMachineScaleSets/*/read`
- In case you can't create a custom RBAC role for the Service Principle, use
the built-in `Reader` role
- The Service Principle can be assigned two ways
  - Manually generated
  - Use Machine Assigned Identity
- The following software needs to be installed on the VM you are using to login
to Vault cluster with for snippets in this guide to work:
  - `vault`
  - `curl`
  - `jq`

## Validation

After Configuring the secret engine, SSH into a single Azure VM and try to
login with an example role.
  - Before running this script, set `VAULT_ADDR` environment variable. In case it is empty, the script with ask you for an imput.
  - In case you are trying to login from a machine that is part of a scale set,
  you must replace `vm_name="${VM_NAME}"` with `vmss_name=<name>` in the `vault
  write ...` command.

> Keep in mind that this snippet queries Azure Instance Metadata Service. You
> must bypass proxies when querying IMDS

<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/login.sh&src=scripts/login.sh) -->
<!-- The below code snippet is automatically added from scripts/login.sh -->
```bash
# bash scripts/login.sh
#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  while [ -z "${VAULT_ADDR}" ] ; do \
  printf "\n❗ The 'VAULT_ADDR' environment variable is required. Please enter its value.\n" ;
  read -r -s -p "VAULT_ADDR: "  VAULT_ADDR ; \
  done; printf "\nThanks\n" || true ;
fi
IMDS_MANAGED_IDENTITY_ENDPOINT='http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F'
IMDS_INSTANCE_METADATA='http://169.254.169.254/metadata/instance?api-version=2017-08-01'
JWT="$(curl -s "${IMDS_MANAGED_IDENTITY_ENDPOINT}" -H Metadata:true | jq -r ".access_token")" ;
INSTANCE_METADATA="$(curl -s -H Metadata:true "${IMDS_INSTANCE_METADATA}")" ;
SUBSCRIPTION_ID="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.subscriptionId")" ;
RESOURCE_GROUP_NAME="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.resourceGroupName")" ;
VM_NAME="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.name")" ;
vault write "auth/${AUTH_MOUNT_PATH}/login" role="${ROLE_NAME}" \
   jwt="${JWT}" \
   subscription_id="${SUBSCRIPTION_ID}" \
   resource_group_name="${RESOURCE_GROUP_NAME}" \
   vm_name="${VM_NAME}" ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Debugging

### Check Engine Config

A common problem is due to misconfigured engine, namely `resource` value. This
has to match the value in `aud` claim of the JWT returned from Azure Metadata
Service.

You can use the following snippets for grabbing the JWT and unpacking it. After
unpacking it,look into `aud` claim field. it has to be identical to `resource`
parameter in Auth method's config

<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/unpack-jwt.sh&src=scripts/unpack-jwt.sh) -->
<!-- The below code snippet is automatically added from scripts/unpack-jwt.sh -->
```bash
# bash scripts/unpack-jwt.sh
IMDS_MANAGED_IDENTITY_ENDPOINT='http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F'
JWT="$(curl -s "${IMDS_MANAGED_IDENTITY_ENDPOINT}" -H Metadata:true | jq -r ".access_token")" ;
sed 's/\./\n/g' <<< $(cut -d. -f1,2 <<< ${JWT}) | base64 --decode | jq
```
<!-- AUTO-GENERATED-CONTENT:END -->
## References

- [How to use managed identities for Azure resources on an Azure VM to acquire an access token](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/how-to-use-vm-token#get-a-token-using-http)
- [Azure Instance Metadata Service](https://learn.microsoft.com/en-us/azure/virtual-machines/windows/instance-metadata-service?tabs=linux#access-azure-instance-metadata-service)
- [Vault Docs - Azure Auth Method](https://developer.hashicorp.com/vault/docs/auth/azure)
- [Vault API Docs - Azure Auth Method](https://developer.hashicorp.com/vault/api-docs/auth/azure)

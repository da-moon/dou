#--------------------------------------------------------------------#
#                             user input                             #
#--------------------------------------------------------------------#
AUTH_MOUNT_PATH="azure"
ROLE_NAME="example"
#--------------------------------------------------------------------#
#                   do not modify after this line                    #
#--------------------------------------------------------------------#
if [ -z "${VAULT_ADDR+x}" ] || [ -z "${VAULT_ADDR}" ]; then
  while [ -z "${VAULT_ADDR}" ] ; do \
  printf "\n❗ The 'VAULT_ADDR' environment variable is required. Please enter its value.\n" ;
  read -r -s -p "VAULT_ADDR: "  VAULT_ADDR ; \
  done; printf "\nThanks\n" || true ;
fi
IMDS_MANAGED_IDENTITY_ENDPOINT='http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F'
IMDS_INSTANCE_METADATA='http://169.254.169.254/metadata/instance?api-version=2017-08-01'
JWT="$(curl -s "${IMDS_MANAGED_IDENTITY_ENDPOINT}" -H Metadata:true | jq -r ".access_token")" ;
INSTANCE_METADATA="$(curl -s -H Metadata:true "${IMDS_INSTANCE_METADATA}")" ;
SUBSCRIPTION_ID="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.subscriptionId")" ;
RESOURCE_GROUP_NAME="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.resourceGroupName")" ;
VM_NAME="$(echo "${INSTANCE_METADATA}" | jq -r ".compute.name")" ;
vault write "auth/${AUTH_MOUNT_PATH}/login" role="${ROLE_NAME}" \
   jwt="${JWT}" \
   subscription_id="${SUBSCRIPTION_ID}" \
   resource_group_name="${RESOURCE_GROUP_NAME}" \
   vm_name="${VM_NAME}" ;

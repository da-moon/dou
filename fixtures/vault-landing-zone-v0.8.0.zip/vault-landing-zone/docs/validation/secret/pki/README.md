# PKI Secret Engine Verification
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
- [Overview](#overview)
- [Pre-requisites](#pre-requisites)
- [Verification Steps](#verification-steps)
  - [Load root CA certificate](#load-root-ca-certificate)
  - [Generate a certificate against a role](#generate-a-certificate-against-a-role)
  - [Verify the certificate with openssl](#verify-the-certificate-with-openssl)
  - [cleanup](#cleanup)
- [Debugging](#debugging)
  - [Read role information](#read-role-information)
  - [Read default key information](#read-default-key-information)
  - [Read id of the default key](#read-id-of-the-default-key)
  - [Read URLs to be encoded in generated certificates](#read-urls-to-be-encoded-in-generated-certificates)
  - [Read id of the default issuer](#read-id-of-the-default-issuer)
  - [Read CRL configuration](#read-crl-configuration)
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

- First, try to generate a certificate with a role.  If it doesn't have any
  issues, use `openssl` to verify the certificate. If it doesn't have any issues
  then the role is valid and no need to do any further validation.
- In case there are issues with generating a certificate against a role, try to
  read role config and mount config. A common issue is that role's TTL is longer
  than mount's max TTL.
- In case there is an issue with `openssl` verification, look into mount's CA certificate extensions.
  `Certificate Sign`, `CRL Sign` must be included or else verification fails
## Pre-requisites

The following software are required to run the verification script:

- `curl`
- `jq`
- `openssl`

Ensure the following environment variables are set in your shell before running
the snippets

- `VAULT_ADDR` : Vault address
- `VAULT_TOKEN` : Vault token that has admin access to `root` namespace and
  child namespace
- `VAULT_NAMESPACE` : Vault namespace that the intermediate PKI engine is mounted in
- `ROLE_NAME` : Name of the role in intermediate PKI engine which is used for
  certificate generation
- `COMMON_NAME` : common name of the certificate to be generated

You can use the `.env` file in this directory to set the environment variables.
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# source scripts/.env &src=scripts/.env) -->
<!-- The below code snippet is automatically added from scripts/.env -->
```bash
# source scripts/.env 
export VAULT_ADDR="http://127.0.0.1:8200"
export VAULT_TOKEN="root"
export VAULT_NAMESPACE="cloud-automation"
export ROLE_NAME="complete"
export COMMON_NAME="example.cloud-automation.acme.com"
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Verification Steps

### Load root CA certificate

we need to form the CA trust chain to use with `openssl`. First, we need to pull
the root PKI engine's CA certificate
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/load-root-ca-certificate.sh &src=scripts/load-root-ca-certificate.sh) -->
<!-- The below code snippet is automatically added from scripts/load-root-ca-certificate.sh -->
```bash
# bash scripts/load-root-ca-certificate.sh 
curl \
  --silent \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/cert/ca" \
| jq -r '.data.certificate' \
| openssl x509 -in - > ca_chain.crt ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Generate a certificate against a role

Send an API call and generate a certificate. In Vault's response, we have the
signing CA which we will append to our CA trust chain
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/generate-a-certificate-against-a-role.sh &src=scripts/generate-a-certificate-against-a-role.sh) -->
<!-- The below code snippet is automatically added from scripts/generate-a-certificate-against-a-role.sh -->
```bash
# bash scripts/generate-a-certificate-against-a-role.sh 
RESPONSE="$(curl -fSsl \
--header "X-Vault-Token: ${VAULT_TOKEN}" \
--header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
--request POST \
--data "{\"common_name\": \"${COMMON_NAME}\"}" \
"${VAULT_ADDR}/v1/pki/issue/${ROLE_NAME}" | \
jq -r .data)"
echo "${RESPONSE}" | jq -r '.issuing_ca' |  openssl x509 -in - >> ca_chain.crt
echo "${RESPONSE}" | jq -r '.certificate' | openssl x509 -in - > certificate.crt
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Verify the certificate with openssl

In case there are no issues with generating the Certificate, we can use
`openssl` to verify the certificate
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/verify-the-certificate-with-openssl.sh &src=scripts/verify-the-certificate-with-openssl.sh) -->
<!-- The below code snippet is automatically added from scripts/verify-the-certificate-with-openssl.sh -->
```bash
# bash scripts/verify-the-certificate-with-openssl.sh 
DIR_ROOT="$('cd' "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)" ;
openssl verify  -CAfile "${DIR_ROOT}/ca_chain.crt"  "${DIR_ROOT}/certificate.crt"  ;
```
<!-- AUTO-GENERATED-CONTENT:END -->
### cleanup

Do not forget to cleanup after you are done
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/cleanup.sh &src=scripts/cleanup.sh) -->
<!-- The below code snippet is automatically added from scripts/cleanup.sh -->
```bash
# bash scripts/cleanup.sh 
rm *.crt
```
<!-- AUTO-GENERATED-CONTENT:END -->
## Debugging

In case there are any issues with generating the certificate or validating with
`openssl`, we need to look into role and mount configurations.

### Read role information
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-role-information.sh &src=scripts/read-role-information.sh) -->
<!-- The below code snippet is automatically added from scripts/read-role-information.sh -->
```bash
# bash scripts/read-role-information.sh 
curl -fSsl \
--header "X-Vault-Token: ${VAULT_TOKEN}" \
--header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
--request GET \
"${VAULT_ADDR}/v1/pki/roles/${ROLE_NAME}"
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read default key information
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-default-key.sh &src=scripts/read-default-key.sh) -->
<!-- The below code snippet is automatically added from scripts/read-default-key.sh -->
```bash
# bash scripts/read-default-key.sh 
curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/key/default" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read id of the default key
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-keys-configuration.sh &src=scripts/read-keys-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-keys-configuration.sh -->
```bash
# bash scripts/read-keys-configuration.sh 
curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/keys" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read URLs to be encoded in generated certificates
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-urls.sh &src=scripts/read-urls.sh) -->
<!-- The below code snippet is automatically added from scripts/read-urls.sh -->
```bash
# bash scripts/read-urls.sh 
curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/urls" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read id of the default issuer
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-issuers-configuration.sh &src=scripts/read-issuers-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-issuers-configuration.sh -->
```bash
# bash scripts/read-issuers-configuration.sh 
curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/issuers" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->
### Read CRL configuration
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-crl-configuration.sh &src=scripts/read-crl-configuration.sh) -->
<!-- The below code snippet is automatically added from scripts/read-crl-configuration.sh -->
```bash
# bash scripts/read-crl-configuration.sh 
curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/crl" \
| jq -r '.data'
```
<!-- AUTO-GENERATED-CONTENT:END -->

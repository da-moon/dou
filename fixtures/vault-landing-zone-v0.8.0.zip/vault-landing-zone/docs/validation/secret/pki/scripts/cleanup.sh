rm *.crt

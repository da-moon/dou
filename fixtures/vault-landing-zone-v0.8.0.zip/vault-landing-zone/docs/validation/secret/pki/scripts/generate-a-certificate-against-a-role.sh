RESPONSE="$(curl -fSsl \
--header "X-Vault-Token: ${VAULT_TOKEN}" \
--header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
--request POST \
--data "{\"common_name\": \"${COMMON_NAME}\"}" \
"${VAULT_ADDR}/v1/pki/issue/${ROLE_NAME}" | \
jq -r .data)"
echo "${RESPONSE}" | jq -r '.issuing_ca' |  openssl x509 -in - >> ca_chain.crt
echo "${RESPONSE}" | jq -r '.certificate' | openssl x509 -in - > certificate.crt

/*
Test Case:
  - confirm kv engine was mounted
  - confirm the kv version
  - confirm name of policy
  - confirm the path the policy applies to
  - list the policies
  - write, read and delete secret data

Test Type: Unit Test
*/

package test

import (
	"context"
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/hashicorp/vault/api"

	"github.com/palantir/stacktrace"
	"github.com/stretchr/testify/assert"
)

func TestKV(t *testing.T) {

	// Construct the terraform options with default retryable errors to handle the most common
	// retryable errors in terraform testing.
	// terraform.Options is a struct
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{

		// Set the path to the Terraform code that will be tested.
		TerraformDir: "../",
	})

	// Clean up resources with "terraform destroy" at the end of the test.
	defer terraform.Destroy(t, terraformOptions)

	// Run "terraform init" and "terraform apply". Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Run `terraform output` to get the values of output variable
	expectedPolicy := terraform.OutputList(t, terraformOptions, "policy")

	/*
	 in the data structure, all engines in sys/mounts have a "/"
	 for example: kv's mount path is "kv/""
	*/
	expectedMountPath := "kv"
	kvPath := expectedMountPath + "/"

	config := api.DefaultConfig() // returns default configuration of the vault client

	client, err := api.NewClient(config) // create and returns a vault client

	// error handling
	if err != nil {

		err = stacktrace.Propagate(err, "initialization error. Could not setup client with default config")
		fmt.Println(err)
		os.Exit(1)

	}

	/*
		Exexute Test Cases
	*/

	// store mount state and version #
	kvExist, data := isKVMounted(client, kvPath)
	// assert kv engine was mounted
	assert.True(t, kvExist, "kv doesn't exist")
	// confirm the kv version
	for _, kvVersion := range data.Options {

		expectedEngineVersion := "2"

		if kvVersion != expectedEngineVersion {

			t.Errorf("got %v, want %v", kvVersion, expectedEngineVersion)

		}

	}

	// confirm policy exists
	policyExist, kvPolicyName := getKVPolicyName(client, expectedPolicy)
	assert.True(t, policyExist, "\"admin-kv-policy\" doesn't exist")

	// confirm the path the policy applies to and list the policies
	getKVPolicy(t, client, kvPolicyName)

	// write, read and delete secret data
	crudOperation(t, client, expectedMountPath)

}

// function returns the kv version and the boolean state of the kv mount
func isKVMounted(c *api.Client, kvPath string) (bool, *api.MountOutput) {

	var mountData *api.MountOutput // variable for the engine struct

	// returns all enabled or mounted secret engines
	mounts, err := c.Sys().ListMounts()
	if err != nil {

		err = stacktrace.Propagate(err, "Could not list mounts")
		fmt.Println(err)
		os.Exit(1)

	}

	// traverse the returned secret engines
	for engine, mountData := range mounts {

		if engine == kvPath {

			return true, mountData

		}

	}

	return false, mountData

}

// returns true if the policy's name exist in the vault backend
func getKVPolicyName(c *api.Client, expectedPolicy []string) (bool, string) {

	// convert list to string
	kvPolicy := strings.Join(expectedPolicy, "")

	// stores all the policies in the backend
	policies, err := c.Sys().ListPolicies()
	if err != nil {

		err = stacktrace.Propagate(err, "Could not list policies")
		fmt.Println(err)
		os.Exit(1)

	}

	// traverse the returned policies
	for _, policy := range policies {

		// compare actual policy to expected policy
		if policy == kvPolicy {

			return true, kvPolicy

		}

	}

	return false, ""

}

// compare policy construct to the returned policy
func getKVPolicy(t *testing.T, c *api.Client, name string) {

	policyConstruct :=
		`path "kv/data/*" {
			capabilities = ["create", "read", "update", "delete", "list", "sudo"]
		 }`

	policies, err := c.Sys().GetPolicy(name)
	if err != nil {

		err = stacktrace.Propagate(err, "Could not get policy path and capabilities")
		fmt.Println(err)
		os.Exit(1)

	}

	// check if policies is within policyConstruct
	if strings.Contains(policies, policyConstruct) {

		t.Errorf("want %s", policies)

	}

}

// write, read and delete secret data
func crudOperation(t *testing.T, c *api.Client, mountPath string) {

	secretPath := "my-secret-password" // path where the secret would be stored

	// secret data to use to perform crud operation
	secretData := map[string]interface{}{

		"password": "testing123",
	}

	// create context
	ctx := context.Background()

	// write a secret to kv v2 store
	_, err := c.KVv2(mountPath).Put(ctx, secretPath, secretData)
	if err != nil {

		err = stacktrace.Propagate(err, "Could not write secret")
		fmt.Println(err)
		os.Exit(1)

	}

	// read data from store
	expectedSecret, err := c.KVv2(mountPath).Get(ctx, secretPath)
	if err != nil {

		err = stacktrace.Propagate(err, "Could not read secret")
		fmt.Println(err)
		os.Exit(1)

	}
	// compare equality of 2 map secrets
	if !reflect.DeepEqual(secretData, expectedSecret.Data) {

		t.Errorf("got %v\n want %v", secretData, expectedSecret.Data)

	}

	// delete data from store
	err = c.KVv2(mountPath).Delete(ctx, secretPath)
	if err != nil {

		err = stacktrace.Propagate(err, "Could not delete secret")
		fmt.Println(err)
		os.Exit(1)

	}
}

/*
Test Case:
  - confirm pki engine was mounted
  - confirm policies were created
  - generate certificate

Test Type: Functional Test
*/

package test

import (
	"fmt"
	"os"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/hashicorp/vault/api"

	"github.com/palantir/stacktrace"
	"github.com/stretchr/testify/assert"
)

func TestPKI(t *testing.T) {

	// terraform files
	modules := []struct {
		name         string
		terraformDir string
	}{
		{name: "root-premade-ca", terraformDir: "../root-premade-ca"},
		{name: "policies", terraformDir: "../policies"},
	}

	// call terraform
	for _, module := range modules {

		var options *terraform.Options // placeholder for Options struct

		// run subtest per module iteration
		t.Run(module.name, func(t *testing.T) {

			// Construct the terraform options with default retryable errors to handle the most common
			// retryable errors in terraform testing.
			// terraform.Options is a struct
			terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{

				// Set the path to the Terraform code that will be tested.
				TerraformDir: module.terraformDir,
			})

			options = terraformOptions // store struct

			// Run "terraform init" and "terraform apply". Fail the test if there are any errors
			terraform.InitAndApply(t, options)

		})

		// Clean up resources with "terraform destroy" at the end of the test.
		defer terraform.Destroy(t, options)

		// instantiating VAULT CLIENT
		config := api.DefaultConfig()        // returns default configuration of the vault client
		client, err := api.NewClient(config) // create and returns a vault client
		// error handling
		if err != nil {

			err = stacktrace.Propagate(err, "initialization error: Could not setup client")
			fmt.Println(err)
			os.Exit(1)

		}

		/*
			Exexute Test Cases
		*/

		if module.name == "root-premade-ca" {

			/*
			 in the data structure, all engines in sys/mounts have a "/"
			 for example: pki's mount path is "pki/""
			*/
			expectedMountPath := "pki"
			pkiPath := expectedMountPath + "/"

			// store mount state
			pkiExist, _ := isPKIMounted(client, pkiPath)

			// assert pki engine was mounted
			assert.True(t, pkiExist, "pki doesn't exist")

		}

		if module.name == "policies" {

			// returns state of pki policies and asserts pki policies were generated
			policyExists := PKIPoliciesExist(client)
			assert.True(t, policyExists, "pki-complete and pki-controller policies do not exist")

			// generate certifcate
			certificateExists := generateCertificate(t, client)
			assert.True(t, certificateExists, "certificate was not generated")

		}

	}

}

// function returns the boolean state of the pki mount
func isPKIMounted(c *api.Client, pkiPath string) (bool, *api.MountOutput) {

	var mountData *api.MountOutput // variable for the pki engine struct

	// returns all enabled or mounted secret engines
	mounts, err := c.Sys().ListMounts()
	if err != nil {

		err = stacktrace.Propagate(err, "Could not list mounts")
		fmt.Println(err)
		os.Exit(1)

	}

	// traverse the returned secret engines
	for engine, mountData := range mounts {

		if engine == pkiPath {

			return true, mountData

		}

	}

	return false, mountData

}

// confirm policies were created
func PKIPoliciesExist(c *api.Client) bool {

	var controller, complete bool

	// stores all the policies in the backend
	policies, err := c.Sys().ListPolicies()
	if err != nil {

		err = stacktrace.Propagate(err, "Could not list policies")
		fmt.Println(err)
		os.Exit(1)

	}

	for _, policy := range policies {

		if policy == "pki-complete" {

			complete = true

		}

		if policy == "pki-controller" {

			controller = true
		}
	}

	return complete && controller

}

// generate certificate
func generateCertificate(t *testing.T, c *api.Client) bool {

	// data to pass  to pass to the backend
	certificateData := map[string]interface{}{

		"common_name": "foobar.cloud-automation.acme.com",
		"alt_names":   "cloud-automation.acme.com",
	}

	// pki backend path for issuing certificate
	path := "pki/issue/complete"

	certificate, err := c.Logical().Write(path, certificateData)
	if err != nil {

		err = stacktrace.Propagate(err, "no secret")
		fmt.Println(err)
		os.Exit(1)

	}

	// fetch certificate
	for cert, value := range certificate.Data {

		if cert == "certificate" && value.(string) != "" {

			return true

		}

	}

	return false

}

# Azure Auth Method Validation
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This document goes through the process of validating Azure Auth method after
deployment and covers some potential issues and how to fix them

## Requirements

- A Service Principle To use with the Auth Method. This Service Principle must
have the following Azure RBAC roles:
  - `Microsoft.Compute/virtualMachines/*/read`
  - `Microsoft.Compute/virtualMachineScaleSets/*/read`
- In case you can't create a custom RBAC role for the Service Principle, use
the built-in `Reader` role
- The Service Principle can be assigned two ways
  - Manually generated
  - Use Machine Assigned Identity
- The following software needs to be installed on the VM you are using to login
to Vault cluster with for snippets in this guide to work:
  - `vault`
  - `curl`
  - `jq`

## Validation

After Configuring the secret engine, SSH into a single Azure VM and try to
login with an example role.
  - Before running this script, set `VAULT_ADDR` environment variable. In case it is empty, the script with ask you for an imput.
  - In case you are trying to login from a machine that is part of a scale set,
  you must replace `vm_name="${VM_NAME}"` with `vmss_name=<name>` in the `vault
  write ...` command.

> Keep in mind that this snippet queries Azure Instance Metadata Service. You
> must bypass proxies when querying IMDS

<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/login.sh&src=scripts/login.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Debugging

### Check Engine Config

A common problem is due to misconfigured engine, namely `resource` value. This
has to match the value in `aud` claim of the JWT returned from Azure Metadata
Service.

You can use the following snippets for grabbing the JWT and unpacking it. After
unpacking it,look into `aud` claim field. it has to be identical to `resource`
parameter in Auth method's config

<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/unpack-jwt.sh&src=scripts/unpack-jwt.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## References

- [How to use managed identities for Azure resources on an Azure VM to acquire an access token](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/how-to-use-vm-token#get-a-token-using-http)
- [Azure Instance Metadata Service](https://learn.microsoft.com/en-us/azure/virtual-machines/windows/instance-metadata-service?tabs=linux#access-azure-instance-metadata-service)
- [Vault Docs - Azure Auth Method](https://developer.hashicorp.com/vault/docs/auth/azure)
- [Vault API Docs - Azure Auth Method](https://developer.hashicorp.com/vault/api-docs/auth/azure)

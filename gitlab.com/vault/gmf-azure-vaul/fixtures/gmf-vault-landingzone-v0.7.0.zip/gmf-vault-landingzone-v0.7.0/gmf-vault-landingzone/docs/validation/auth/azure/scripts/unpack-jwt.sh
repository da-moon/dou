IMDS_MANAGED_IDENTITY_ENDPOINT='http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F'
JWT="$(curl -s "${IMDS_MANAGED_IDENTITY_ENDPOINT}" -H Metadata:true | jq -r ".access_token")" ;
sed 's/\./\n/g' <<< $(cut -d. -f1,2 <<< ${JWT}) | base64 --decode | jq

# PKI Secret Engine Verification
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

- First, try to generate a certificate with a role.  If it doesn't have any
  issues, use `openssl` to verify the certificate. If it doesn't have any issues
  then the role is valid and no need to do any further validation.
- In case there are issues with generating a certificate against a role, try to
  read role config and mount config. A common issue is that role's TTL is longer
  than mount's max TTL.
- In case there is an issue with `openssl` verification, look into mount's CA certificate extensions.
  `Certificate Sign`, `CRL Sign` must be included or else verification fails
## Pre-requisites

The following software are required to run the verification script:

- `curl`
- `jq`
- `openssl`

Ensure the following environment variables are set in your shell before running
the snippets

- `VAULT_ADDR` : Vault address
- `VAULT_TOKEN` : Vault token that has admin access to `root` namespace and
  child namespace
- `VAULT_NAMESPACE` : Vault namespace that the intermediate PKI engine is mounted in
- `ROLE_NAME` : Name of the role in intermediate PKI engine which is used for
  certificate generation
- `COMMON_NAME` : common name of the certificate to be generated

You can use the `.env` file in this directory to set the environment variables.
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# source scripts/.env &src=scripts/.env) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Verification Steps

### Load root CA certificate

we need to form the CA trust chain to use with `openssl`. First, we need to pull
the root PKI engine's CA certificate
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/load-root-ca-certificate.sh &src=scripts/load-root-ca-certificate.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Generate a certificate against a role

Send an API call and generate a certificate. In Vault's response, we have the
signing CA which we will append to our CA trust chain
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/generate-a-certificate-against-a-role.sh &src=scripts/generate-a-certificate-against-a-role.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Verify the certificate with openssl

In case there are no issues with generating the Certificate, we can use
`openssl` to verify the certificate
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/verify-the-certificate-with-openssl.sh &src=scripts/verify-the-certificate-with-openssl.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### cleanup

Do not forget to cleanup after you are done
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/cleanup.sh &src=scripts/cleanup.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Debugging

In case there are any issues with generating the certificate or validating with
`openssl`, we need to look into role and mount configurations.

### Read role information
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-role-information.sh &src=scripts/read-role-information.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Read default key information
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-default-key.sh &src=scripts/read-default-key.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Read id of the default key
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-keys-configuration.sh &src=scripts/read-keys-configuration.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Read URLs to be encoded in generated certificates
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-urls.sh &src=scripts/read-urls.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Read id of the default issuer
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-issuers-configuration.sh &src=scripts/read-issuers-configuration.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->
### Read CRL configuration
<!-- AUTO-GENERATED-CONTENT:START (CODE:syntax=bash&header=# bash scripts/read-crl-configuration.sh &src=scripts/read-crl-configuration.sh) -->
<!-- AUTO-GENERATED-CONTENT:END -->

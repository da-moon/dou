curl \
  --silent \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/cert/ca" \
| jq -r '.data.certificate' \
| openssl x509 -in - > ca_chain.crt ;

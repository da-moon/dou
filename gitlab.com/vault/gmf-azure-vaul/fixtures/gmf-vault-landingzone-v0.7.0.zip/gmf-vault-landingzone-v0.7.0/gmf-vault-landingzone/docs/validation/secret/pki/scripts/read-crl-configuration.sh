curl \
  --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
  --header "X-Vault-Token: ${VAULT_TOKEN}" \
  "${VAULT_ADDR}/v1/pki/config/crl" \
| jq -r '.data'

# pki
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## overview

This module sets up an Intermediate Vault PKI secret engine. This is the pki
engine used by client to generate certificates

## prerequisites

- running vault server
  - set `VAULT_ADDR` environment variable in your shell
  - set `VAULT_TOKEN` environment variable in your shell
- Mount a root PKI engine. You can use `../root-self-generated-ca/` or `../root-premade-ca/` module

## usage and validation

- initialize terrafrom modules


- analyze a certificate with `openssl`

```bash
cat /path/to/cert | openssl x509 -text
```

### operations

| Description                                        	| Vault CLI Command                                                                 	| Curl Command                                                                                                                                               	|
|----------------------------------------------------	|-----------------------------------------------------------------------------------	|------------------------------------------------------------------------------------------------------------------------------------------------------------	|
| generate a new self-signed certificate             	| `vault write <intermdiate-pki>/issue/<role> common_name=<common-name>`            	| `curl -fSsl -XPOST -H "X-Vault-Token: ${VAULT_TOKEN}"-d '{"common_name": "<common-name>"}' "${VAULT_ADDR}/v1/<intermediate--pki>/issue/<role-name>"`       	|
| list generated self-signed certificates            	| `vault list <intermdiate-pki>/certs`                                              	| `curl -fSsl -XLIST -H "X-Vault-Token: ${VAULT_TOKEN}" "${VAULT_ADDR}/v1/<intermdiate-pki>/certs"`                                                          	|
| revoke a certificate                               	| `vault write <intermdiate-pki>/revoke serial_number=<cert-serial-number>`         	| `curl -fSsl -XPOST -H "X-Vault-Token: ${VAULT_TOKEN}" -d '{"serial_number": "<cert-serial-number>"}' "${VAULT_ADDR}/v1/<intermdiate-pki>/revoke"`          	|
| cleanup pki engine and remove revoked certificates 	| `vault write <intermdiate-pki>/tidy tidy_cert_store=true tidy_revoked_certs=true` 	| `curl -fSsl -XPOST -H "X-Vault-Token: ${VAULT_TOKEN}" -d '{"tidy_cert_store": true,"tidy_revoked_certs":true }' "${VAULT_ADDR}/v1/<intermdiate-pki>/tidy"` 	|

# root-premade-ca
<!-- AUTO-GENERATED-CONTENT:START (TOC) -->
<!-- AUTO-GENERATED-CONTENT:END -->
## Overview

This module mounts Root PKI engine and sets it CA key to a pre-existing one.

## Prerequisites

We need to have a self-signed CA Private/Public key pair in PEM format. The
following snippets help with generating one. Keep in mind that the module only
needs a Private Key but these snippets also generate a public key and show how
to Verify them.

### Prerequisites - OpenSSL

- Generate a key for the subject

```bash
openssl genrsa -out ca.key 2048
```

- Generate a self-signed certificate for the CA

```bash
openssl req \
  -x509 \
  -sha256 \
  -new \
  -nodes \
  -subj "/CN=acme.com/O=acme/OU=example" \
  -days 3650 \
  -key ca.key \
  -out ca.crt ;
```

- Inspect the offline CA certificate with Openssl
to ensure it has the expected subject.

```bash
openssl x509 -in ca.crt -noout  -subject -issuer
```

- Add CA to system trusted certs if you want

```bash
# Debian / Ubuntu
sudo cp ca.crt /usr/local/share/ca-certificates/
sudo update-ca-certificates
# RHEL
sudo cp ca.crt /etc/pki/ca-trust/source/anchors/
sudo update-ca-trust
```

- Form the PEM bundle and encode it as base64

```bash
(
cat ca.key;
cat ca.crt;
) | base64 -w0
```

- Store the base64 encoded string in `pem_bundle` variable in `.auto.tfvars` file

### Prerequisites - Terraform

- An alternative approach is to use
[`auxiliary/selfsigned-tls-cert/self-signed-ca`][auxiliary/selfsigned-tls-cert/self-signed-ca]
terraform module. The variables are in `private_key_pem` and `signed_cert_pem`
output fields. Run the following snippet in `self-signed-ca` directory to get
the base64 encoded pem bundle:

```bash
(
terraform output -raw private_key_pem;
terraform output -raw signed_cert_pem;
) | base64 -w0
```

- Store the base64 encoded string in `pem_bundle` variable in `.auto.tfvars` file

## Validation
[auxiliary/selfsigned-tls-cert/self-signed-ca]: ../../auxiliary/selfsigned-tls-cert/self-signed-ca
